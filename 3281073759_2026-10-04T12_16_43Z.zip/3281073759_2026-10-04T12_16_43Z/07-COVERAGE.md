# 07 - Coverage and limitations

---

- This file lists what the run did NOT observe and what it could
- not observe. Anything absent from the other documents and
- absent from this file should be treated as genuinely unknown.

## Remotes with no observed traffic (22)

| Class | Path | Parent |
| --- | --- | --- |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.choosingWords' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.clear' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.draw' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.drawTools' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.erase' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.gameEnd' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.gameStart' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.guess' | ReplicatedStorage.Remotes |
| 'RemoteFunction' | 'ReplicatedStorage.Remotes.hash' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.isChoosing' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.sendGuess' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.systemChat' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.turn' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.undoRedo' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.voteKick' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.warnPlayer' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.wayPoint' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.word' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'Workspace.Pro Server Portal.TeleportRemote' | Workspace.Pro Server Portal |
| 'BindableFunction' | 'Workspace.jgifhhfyu.Animate.PlayEmote' | Workspace.jgifhhfyu.Animate |
| 'BindableFunction' | 'Workspace.only_schoki.Animate.PlayEmote' | Workspace.only_schoki.Animate |
| 'BindableFunction' | 'Workspace.oreo_152006.Animate.PlayEmote' | Workspace.oreo_152006.Animate |

## Interactable instances

- These exist in the game and respond to player input. A reader
- of this dump cannot know whether they were exercised.

| Class | Count |
| --- | :---: |
| 'ProximityPrompt' | 0 |
| 'ClickDetector' | 0 |
| 'TouchTransmitter' | 1 |

## Sweep activity (1 action(s) attempted)

| Action | Subject | Outcome | Reason it was permitted |
| --- | --- | --- | --- |
| move | 'nil --[[unserialisable vector: 57.821151…' | issued | waypoint sampled from game geometry |


## Capture layers not available

| Capability | Consequence |
| --- | --- |
| 'getcallingline' | call sites are attributed to a script but not to a line number; 05-SCRIPTS.md records the script only |
| 'ReflectionMetadata.xml' | not present on the filesystem; property coverage fell back to probing |
| 'parallel Luau actors' | this build observes only the main client; actor instances and their remotes are not instrumented regardless of executor support |

## Structural limits

| Limit | Configured | This run | State |
| --- | :---: | :---: | --- |
| Instance walk budget | 8000 | 0 | within budget |
| Depth budget | 40 | 40 | within budget |
| Properties per instance | 40 | 40 | cap applied |
| Total property emissions | 60000 | 60000 | cap applied |
| raw/instances.json instances | 20000 | 20000 | cap applied |
| raw/instances.json with properties | 4000 | 4000 | cap applied |

- 02-STRUCTURE.md was truncated at the instance budget budget of 8000.

- Property reads failed 300 time(s) against a budget of 300; reading was then disabled for the rest of the run.

- Most frequent unreadable properties: ExplicitAutoJoints x1, FluidFidelityInternal x1, FluidForces x1, ForceR15 x1, GameAvatarType x1, HistoryId x16, IKControlConstraintSupport x1, ImprovedAnimationConstraint x1, ImprovedPhysicsReplication x1, InertiaMigrated x1, InitialSize x1, IsInSandbox x16.
- These are properties this client is not permitted to
- observe. Each one raises an engine message when read,
- which is why reading stops once the budget is spent.

- Instances listed after that point carry name, class,
- children and attributes, but no property values.

- raw/instances.json lists every instance up to the cap, but properties were read for only the first 4000. The remaining 16000 carry name, class, children and attributes, but no property values.

- Attribute names created after watching began and never changed are only
- discovered at the next export, so a short run can miss them.

## Scripts without usable source (113)

| Script | State | Recorded reason |
| --- | --- | --- |
| 'Players.SeoulKD.PlayerGui.BobuxDonationGui.Donation Script' | bytecode-unsupported | unsupported constant tag 111 |
| 'Players.SeoulKD.PlayerGui.GamepassGui.Gamepass Script' | bytecode-unsupported | unsupported constant tag 164 |
| 'Players.SeoulKD.PlayerScripts.LocalScript' | bytecode-unsupported | unsupported constant tag 111 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule' | bytecode-unsupported | unsupported constant tag 22 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule' | bytecode-unsupported | unsupported constant tag 84 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.BaseCamera' | bytecode-unsupported | unsupported constant tag 101 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.BaseOcclusion' | bytecode-unsupported | unsupported constant tag 25 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraInput' | bytecode-unsupported | unsupported constant tag 103 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraToggleStateController' | bytecode-unsupported | unsupported constant tag 85 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraUI' | bytecode-unsupported | unsupported constant tag 255 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraUtils' | bytecode-unsupported | unsupported constant tag 77 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ClassicCamera' | bytecode-unsupported | unsupported constant tag 97 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.Invisicam' | bytecode-unsupported | unsupported constant tag 101 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.LegacyCamera' | bytecode-unsupported | unsupported constant tag 99 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.MouseLockController' | bytecode-unsupported | unsupported constant tag 99 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.OrbitalCamera' | bytecode-unsupported | unsupported constant tag 16 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.Poppercam' | bytecode-unsupported | unsupported constant tag 116 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.TransparencyController' | bytecode-unsupported | unsupported constant tag 109 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRBaseCamera' | bytecode-unsupported | unsupported constant tag 105 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCamera' | bytecode-unsupported | unsupported constant tag 85 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector' | bytecode-unsupported | unsupported constant tag 24 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec' | bytecode-unsupported | unsupported constant tag 105 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRVehicleCamera' | bytecode-unsupported | unsupported constant tag 101 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera' | bytecode-unsupported | unsupported constant tag 101 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig' | bytecode-unsupported | unsupported constant tag 48 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore' | bytecode-unsupported | unsupported constant tag 109 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ZoomController' | bytecode-unsupported | unsupported constant tag 128 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ZoomController.Popper' | bytecode-unsupported | unsupported constant tag 111 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper' | bytecode-unsupported | unsupported constant tag 249 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec' | bytecode-unsupported | unsupported constant tag 164 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CharacterUtil' | bytecode-unsupported | unsupported constant tag 37 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec' | bytecode-unsupported | unsupported constant tag 110 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule' | bytecode-unsupported | unsupported constant tag 100 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface' | bytecode-unsupported | unsupported constant tag 118 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.BaseCharacterController' | bytecode-unsupported | unsupported constant tag 48 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.ClickToMoveController' | bytecode-unsupported | unsupported constant tag 108 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay' | bytecode-unsupported | unsupported constant tag 100 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.DynamicThumbstick' | bytecode-unsupported | unsupported constant tag 73 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.Gamepad' | bytecode-unsupported | unsupported constant tag 100 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.Keyboard' | bytecode-unsupported | unsupported constant tag 114 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.PathDisplay' | bytecode-unsupported | unsupported constant tag 105 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.TouchJump' | bytecode-unsupported | unsupported constant tag 111 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.TouchThumbstick' | bytecode-unsupported | unsupported constant tag 97 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.VRNavigation' | bytecode-unsupported | unsupported constant tag 115 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.VehicleController' | bytecode-unsupported | unsupported constant tag 111 |
| 'Players.SeoulKD.PlayerScripts.RbxCharacterSounds' | bytecode-unsupported | unsupported constant tag 99 |
| 'Players.SeoulKD.PlayerScripts.RbxCharacterSounds.AtomicBinding' | bytecode-unsupported | unsupported constant tag 114 |
| 'ReplicatedStorage.DrawCamera' | bytecode-unsupported | unsupported constant tag 13 |
| 'ReplicatedStorage.GuiLib.Classes.CheckboxLabel' | bytecode-unsupported | unsupported constant tag 107 |
| 'ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.CONSTANTS' | bytecode-unsupported | unsupported constant tag 137 |
| 'ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.CreateRadial' | bytecode-unsupported | unsupported constant tag 116 |
| 'ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.Triangle' | bytecode-unsupported | unsupported constant tag 82 |
| 'ReplicatedStorage.GuiLib.Classes.Children.TextMask.Vector2' | bytecode-unsupported | unsupported constant tag 198 |
| 'ReplicatedStorage.GuiLib.Classes.Dragger' | bytecode-unsupported | unsupported constant tag 48 |
| 'ReplicatedStorage.GuiLib.Classes.Dropdown' | bytecode-unsupported | unsupported constant tag 71 |
| 'ReplicatedStorage.GuiLib.Classes.RadialMenu' | bytecode-unsupported | unsupported constant tag 108 |
| 'ReplicatedStorage.GuiLib.Classes.RadioButtonGroup' | bytecode-unsupported | unsupported constant tag 37 |
| 'ReplicatedStorage.GuiLib.Classes.RadioButtonLabel' | bytecode-unsupported | unsupported constant tag 158 |
| 'ReplicatedStorage.GuiLib.Classes.Slider' | bytecode-unsupported | unsupported constant tag 99 |
| 'ReplicatedStorage.GuiLib.Classes.TextMask' | bytecode-unsupported | unsupported constant tag 251 |
| 'ReplicatedStorage.GuiLib.Constructors.List' | bytecode-unsupported | unsupported constant tag 251 |
| 'ReplicatedStorage.GuiLib.LazyLoader' | bytecode-unsupported | unsupported constant tag 10 |
| 'ReplicatedStorage.GuiLib.Utilities.Spring' | bytecode-unsupported | string length 1431 exceeds buffer |
| 'StarterGui.BobuxDonationGui.Donation Script' | bytecode-unsupported | unsupported constant tag 111 |
| 'StarterGui.GamepassGui.Gamepass Script' | bytecode-unsupported | unsupported constant tag 164 |
| 'StarterPlayer.StarterPlayerScripts.LocalScript' | bytecode-unsupported | unsupported constant tag 111 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule' | bytecode-unsupported | unsupported constant tag 22 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule' | bytecode-unsupported | unsupported constant tag 84 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.BaseCamera' | bytecode-unsupported | unsupported constant tag 101 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.BaseOcclusion' | bytecode-unsupported | unsupported constant tag 25 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraInput' | bytecode-unsupported | unsupported constant tag 103 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraToggleStateController' | bytecode-unsupported | unsupported constant tag 85 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraUI' | bytecode-unsupported | unsupported constant tag 255 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraUtils' | bytecode-unsupported | unsupported constant tag 77 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ClassicCamera' | bytecode-unsupported | unsupported constant tag 97 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.Invisicam' | bytecode-unsupported | unsupported constant tag 101 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.LegacyCamera' | bytecode-unsupported | unsupported constant tag 99 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.MouseLockController' | bytecode-unsupported | unsupported constant tag 99 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.OrbitalCamera' | bytecode-unsupported | unsupported constant tag 16 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.Poppercam' | bytecode-unsupported | unsupported constant tag 116 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.TransparencyController' | bytecode-unsupported | unsupported constant tag 109 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRBaseCamera' | bytecode-unsupported | unsupported constant tag 105 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCamera' | bytecode-unsupported | unsupported constant tag 85 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector' | bytecode-unsupported | unsupported constant tag 24 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec' | bytecode-unsupported | unsupported constant tag 105 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRVehicleCamera' | bytecode-unsupported | unsupported constant tag 101 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera' | bytecode-unsupported | unsupported constant tag 101 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig' | bytecode-unsupported | unsupported constant tag 48 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore' | bytecode-unsupported | unsupported constant tag 109 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ZoomController' | bytecode-unsupported | unsupported constant tag 128 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ZoomController.Popper' | bytecode-unsupported | unsupported constant tag 111 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CameraWrapper' | bytecode-unsupported | unsupported constant tag 249 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec' | bytecode-unsupported | unsupported constant tag 164 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CharacterUtil' | bytecode-unsupported | unsupported constant tag 37 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec' | bytecode-unsupported | unsupported constant tag 110 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule' | bytecode-unsupported | unsupported constant tag 100 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface' | bytecode-unsupported | unsupported constant tag 118 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.BaseCharacterController' | bytecode-unsupported | unsupported constant tag 48 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.ClickToMoveController' | bytecode-unsupported | unsupported constant tag 108 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay' | bytecode-unsupported | unsupported constant tag 100 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.DynamicThumbstick' | bytecode-unsupported | unsupported constant tag 73 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.Gamepad' | bytecode-unsupported | unsupported constant tag 100 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.Keyboard' | bytecode-unsupported | unsupported constant tag 114 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.PathDisplay' | bytecode-unsupported | unsupported constant tag 105 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.TouchJump' | bytecode-unsupported | unsupported constant tag 111 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.TouchThumbstick' | bytecode-unsupported | unsupported constant tag 97 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.VRNavigation' | bytecode-unsupported | unsupported constant tag 115 |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.VehicleController' | bytecode-unsupported | unsupported constant tag 111 |
| 'StarterPlayer.StarterPlayerScripts.RbxCharacterSounds' | bytecode-unsupported | unsupported constant tag 99 |
| 'StarterPlayer.StarterPlayerScripts.RbxCharacterSounds.AtomicBinding' | bytecode-unsupported | unsupported constant tag 114 |
| 'Workspace.Pro Server Portal.LocalScript' | bytecode-unsupported | unsupported constant tag 25 |
| 'Workspace.jgifhhfyu.Animate' | bytecode-unsupported | unsupported constant tag 73 |
| 'Workspace.oreo_152006.Animate' | bytecode-unsupported | unsupported constant tag 73 |

## Lines withheld by the fact-discipline linter (3)

| Withheld line | Trigger terms |
| --- | --- |
| This remote is probably the currency endpoint. | probably |
| 02-STRUCTURE.md - the full scene, last, because it is large. | because |
| 02-STRUCTURE.md - the full scene, last, because it is large. | because |

