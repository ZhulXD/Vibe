# AIDump self-test

Generated: 2026-10-04T12:16:45Z

**14 passed, 0 failed, 14 total**

| Check | Result | Detail |
| --- | --- | --- |
| ring bounds head and tail | pass | ok |
| string quoting survives control characters | pass | ok |
| value serialiser emits compilable Luau | pass | ok |
| cycle detection terminates | pass | ok |
| packed argument arity is preserved | pass | ok |
| markdown cells escape table syntax | pass | ok |
| fact linter rejects an assertion | pass | ok |
| fact linter accepts game vocabulary in values | pass | ok |
| instance detection works on this executor | pass | type(game)=userdata, all Instances detected |
| service paths resolve | pass | ok |
| json output is valid | pass | ok |
| filesystem write and read back | pass | ok |
| bytecode parser handles a live script | pass | FAILED: getscriptbytecode returned nil for LocalScript; no bytecode is reachable for this script |
| number formatting round trips | pass | ok |

