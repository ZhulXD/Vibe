--[[
	AIDump decompilation output for LocalScript
	Script:      LocalScript
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Legacy
	DebugId:     0_177494
]]
-- failed to get script bytecode