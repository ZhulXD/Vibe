# 02 - Structure

---

Instances walked: 8000 of at most 8000 (budget).
Nil-parented instances included: 0.

- `?` after a property value means no default is known for that
- property, so equality with the default could not be checked.

## Instance tree

```text

```
`- Ugc (DataModel)
      Archivable = true  ?
      Capabilities = nil --[[unserialisable userdata: ]]  ?
      ClassName = "DataModel"  ?
      CreatorId = 38617013  ?
      CreatorType = Enum.CreatorType.User  ?
      DataCost = 221268  ?
      Environment = ""  ?
      GameId = 1182609799  ?
      GearGenreSetting = Enum.GearGenreSetting.AllGenres  ?
      Genre = Enum.Genre.All  ?
      IsPioneerBuild = false  ?
      IsSFFlagsLoaded = true  ?
      JobId = "a6d7f13e-245c-45e2-9c88-59a13796d4de"  ?
      MatchmakingType = Enum.MatchmakingType.Default  ?
      Name = "Ugc"  *
      PioneerSource = Enum.PioneerSource.Roblox  ?
      PlaceId = 3281073759  ?
      PlaceVersion = 169  ?
      RunService = :GetService("Run Service")game  ?
      Sandboxed = false  ?
      SourceAssetId = -1  ?
      UniqueId = "00000000-0000-0000-0000-000000000000"  ?
      VIPServerId = ""  ?
      VIPServerOwnerId = 0  ?
      Workspace = workspace  ?
      archivable = true  ?
      className = "DataModel"  ?
      lighting = :GetService("Lighting")game  ?
      workspace = workspace  ?
  |- Workspace (Workspace)
        AirDensity = 0.0012000000569969416  ?
        AirTurbulenceIntensity = 0  ?
        AllowThirdPartySales = false  ?
        Archivable = true  ?
        AuthorityMode = Enum.AuthorityMode.Automatic  ?
        AutoSimulate = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "Workspace"  ?
        ClientAnimatorThrottling = Enum.ClientAnimatorThrottlingMode.Default  ?
        DataCost = 64522  ?
        DistributedGameTime = 17.445834298618138  ?
        FallHeightEnabled = true  ?
        FallenPartsDestroyHeight = -500  ?
        FilteringEnabled = true  ?
        GlobalWind = nil --[[unserialisable vector: 3, 0, 6]]  ?
        Gravity = 196.1999969482422  *
        GravityDirection = nil --[[unserialisable vector: 0, -1, 0]]  ?
        InsertPoint = nil --[[unserialisable vector: 0, 0, 0]]  ?
        InterpolationThrottling = Enum.InterpolationThrottlingMode.Default  ?
        LevelOfDetail = Enum.ModelLevelOfDetail.Automatic  ?
        LuauTypeCheckMode = Enum.LuauTypeCheckMode.Default  ?
        ModelStreamingMode = Enum.ModelStreamingMode.Default  ?
        Name = "Workspace"
        PhysicsStepTime = 0.0003855859977193177  ?
        Retargeting = Enum.AnimatorRetargetingMode.Default  ?
        Sandboxed = false  ?
        SimulationRate = 1  ?
        SourceAssetId = -1  ?
        StreamingAdaptiveRadius = false  ?
        StreamingEnabled = false  ?
        Terrain = .Terrainworkspace  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        Wind = 0  ?
        WindDirection = nil --[[unserialisable vector: 0, 0, 0]]  ?
        WorldPivot = CFrame.new(0, 0, 0)  ?
        archivable = true  ?
        className = "Workspace"  ?
    |- Camera (Camera)
          Archivable = true  ?
          CFrame = CFrame.new(3.927417755126953, 5.042757987976074, 22.057876586914062) * CFrame.fromEulerAng…  ?
          CameraSubject = .SeoulKD.Humanoidworkspace  ?
          CameraType = Enum.CameraType.Custom  ?
          Capabilities = nil --[[unserialisable userdata: ]]  ?
          ClassName = "Camera"  ?
          CoordinateFrame = CFrame.new(3.927417755126953, 5.042757987976074, 22.057876586914062) * CFrame.fromEulerAng…  ?
          DataCost = 10  ?
          DiagonalFieldOfView = 127.76887512207031  ?
          FieldOfView = 70
          FieldOfViewMode = Enum.FieldOfViewMode.Vertical  ?
          Focus = CFrame.new(3.927417755126953, 1.8075194358825684, 9.983802795410156)  ?
          HeadLocked = true  ?
          HeadScale = 1  ?
          MaxAxisFieldOfView = 102.44786071777344  ?
          Name = "Camera"
          NearPlaneZ = -0.10000000149011612  ?
          Sandboxed = false  ?
          SourceAssetId = -1  ?
          UniqueId = "00000000-0000-0000-0000-000000000000"  ?
          VRTiltAndRollEnabled = false  ?
          ViewportSize = Vector2.new(640, 360)  ?
          archivable = true  ?
          className = "Camera"  ?
          focus = CFrame.new(3.927417755126953, 1.8075194358825684, 9.983802795410156)  ?
    |- Path (Model)
      |- Model (Model)
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -80.18643188476562, -2.57501220703125, -90.03902435302734]]  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[1] --[[Model is 1 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-80.18643188476562, -2.57501220703125, -90.03902435302734) * CFrame.fromEulerAn…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-80.18643188476562, -2.57501220703125, -90.03902435302734) * CFrame.fromEulerAn…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -81.01861572265625, -2.500012159347534, -89.76862335205078]…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[1] --[[Model is 1 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-81.01861572265625, -2.500012159347534, -89.76862335205078) * CFrame.fromEulerA…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-81.01861572265625, -2.500012159347534, -89.76862335205078) * CFrame.fromEulerA…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -87.34417724609375, -2.57501220703125, -105.0456314086914]]  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[2] --[[Model is 2 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-87.34417724609375, -2.57501220703125, -105.0456314086914) * CFrame.fromEulerAn…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-87.34417724609375, -2.57501220703125, -105.0456314086914) * CFrame.fromEulerAn…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -88.07805633544922, -2.500012159347534, -104.56903076171875…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[2] --[[Model is 2 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-88.07805633544922, -2.500012159347534, -104.56903076171875) * CFrame.fromEuler…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-88.07805633544922, -2.500012159347534, -104.56903076171875) * CFrame.fromEuler…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -98.14200592041016, -2.57501220703125, -117.68827056884766]…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[3] --[[Model is 3 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-98.14200592041016, -2.57501220703125, -117.68827056884766) * CFrame.fromEulerA…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-98.14200592041016, -2.57501220703125, -117.68827056884766) * CFrame.fromEulerA…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        `- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -98.72753143310547, -2.500012159347534, -117.03795623779297…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[3] --[[Model is 3 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-98.72753143310547, -2.500012159347534, -117.03795623779297) * CFrame.fromEuler…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-98.72753143310547, -2.500012159347534, -117.03795623779297) * CFrame.fromEuler…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
      |- Model (Model)
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -80.18643188476562, -2.57501220703125, -90.03902435302734]]  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[1] --[[Model is 1 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-80.18643188476562, -2.57501220703125, -90.03902435302734) * CFrame.fromEulerAn…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-80.18643188476562, -2.57501220703125, -90.03902435302734) * CFrame.fromEulerAn…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -81.01861572265625, -2.500012159347534, -89.76862335205078]…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[1] --[[Model is 1 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-81.01861572265625, -2.500012159347534, -89.76862335205078) * CFrame.fromEulerA…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-81.01861572265625, -2.500012159347534, -89.76862335205078) * CFrame.fromEulerA…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -87.34417724609375, -2.57501220703125, -105.0456314086914]]  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[2] --[[Model is 2 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-87.34417724609375, -2.57501220703125, -105.0456314086914) * CFrame.fromEulerAn…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-87.34417724609375, -2.57501220703125, -105.0456314086914) * CFrame.fromEulerAn…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -88.07805633544922, -2.500012159347534, -104.56903076171875…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[2] --[[Model is 2 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-88.07805633544922, -2.500012159347534, -104.56903076171875) * CFrame.fromEuler…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-88.07805633544922, -2.500012159347534, -104.56903076171875) * CFrame.fromEuler…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -98.14200592041016, -2.57501220703125, -117.68827056884766]…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[3] --[[Model is 3 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-98.14200592041016, -2.57501220703125, -117.68827056884766) * CFrame.fromEulerA…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-98.14200592041016, -2.57501220703125, -117.68827056884766) * CFrame.fromEulerA…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        `- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -98.72753143310547, -2.500012159347534, -117.03795623779297…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[3] --[[Model is 3 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-98.72753143310547, -2.500012159347534, -117.03795623779297) * CFrame.fromEuler…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-98.72753143310547, -2.500012159347534, -117.03795623779297) * CFrame.fromEuler…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
      |- Model (Model)
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -80.18643188476562, -2.57501220703125, -90.03902435302734]]  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[1] --[[Model is 1 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-80.18643188476562, -2.57501220703125, -90.03902435302734) * CFrame.fromEulerAn…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-80.18643188476562, -2.57501220703125, -90.03902435302734) * CFrame.fromEulerAn…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -81.01861572265625, -2.500012159347534, -89.76862335205078]…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[1] --[[Model is 1 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-81.01861572265625, -2.500012159347534, -89.76862335205078) * CFrame.fromEulerA…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-81.01861572265625, -2.500012159347534, -89.76862335205078) * CFrame.fromEulerA…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -87.34417724609375, -2.57501220703125, -105.0456314086914]]  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[2] --[[Model is 2 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-87.34417724609375, -2.57501220703125, -105.0456314086914) * CFrame.fromEulerAn…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-87.34417724609375, -2.57501220703125, -105.0456314086914) * CFrame.fromEulerAn…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -88.07805633544922, -2.500012159347534, -104.56903076171875…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[2] --[[Model is 2 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-88.07805633544922, -2.500012159347534, -104.56903076171875) * CFrame.fromEuler…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-88.07805633544922, -2.500012159347534, -104.56903076171875) * CFrame.fromEuler…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -98.14200592041016, -2.57501220703125, -117.68827056884766]…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[3] --[[Model is 3 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-98.14200592041016, -2.57501220703125, -117.68827056884766) * CFrame.fromEulerA…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-98.14200592041016, -2.57501220703125, -117.68827056884766) * CFrame.fromEulerA…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        `- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -98.72753143310547, -2.500012159347534, -117.03795623779297…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[3] --[[Model is 3 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-98.72753143310547, -2.500012159347534, -117.03795623779297) * CFrame.fromEuler…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-98.72753143310547, -2.500012159347534, -117.03795623779297) * CFrame.fromEuler…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
      |- Wedge (WedgePart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: -44.840145111083984, -2.575012445449829, -48.90073394775390…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Path:GetChildren()[1] --[[Wedge is 1 of 80]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark grey")  ?
            CFrame = CFrame.new(-45.19078063964844, -2.57501220703125, -49.628963470458984) * CFrame.fromEulerA…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, -0.25837409496307373, 0.7658352851867676]]  ?
            ClassName = "WedgePart"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(-45.19078063964844, -2.57501220703125, -49.628963470458984) * CFrame.fromEulerA…  ?
            ExtentsSize = nil --[[unserialisable vector: 0.25, 1.5502444505691528, 4.5950117111206055]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            FrontSurfaceInput = Enum.InputType.NoInput  ?
            --[[ 41 more property/properties not shown ]]
      |- Wedge (WedgePart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: -48.405609130859375, -2.5000131130218506, -49.2347335815429…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Path:GetChildren()[2] --[[Wedge is 2 of 80]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Pine Cone")  ?
            CFrame = CFrame.new(-48.37985610961914, -2.500012159347534, -49.313987731933594) * CFrame.fromEuler…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, -0.08230702579021454, 0.013036186806857586]]  ?
            ClassName = "WedgePart"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(-48.37985610961914, -2.500012159347534, -49.313987731933594) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 0.6000000238418579, 0.49384215474128723, 0.0782171189785003…  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            FrontSurfaceInput = Enum.InputType.NoInput  ?
            --[[ 41 more property/properties not shown ]]
      |- Pebble (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Path:GetChildren()[1] --[[Pebble is 1 of 63]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark grey")  ?
            CFrame = CFrame.new(64.99628448486328, -2.6844711303710938, -71.79589080810547) * CFrame.fromEulerA…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Hull  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(64.99628448486328, -2.6844711303710938, -71.79589080810547) * CFrame.fromEulerA…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.7257795333862305, 0.05000000074505806, 2.93221116065979]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            --[[ 52 more property/properties not shown ]]
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      `- Pebble (MeshPart)
    |- normalCanvas (Model)
      |- canvasFrame (Part)
      |- canvasFrame (Part)
      |- canvasFrame (Part)
      `- canvasFrame (Part)
    |- Pro Server Portal (Model)
      |- LocalScript (Script)
      |- Script (Script)
      |- Portal (Model)
        |- Teleport (Part)
          |- ParticleEmitter (ParticleEmitter)
          `- TouchInterest (TouchTransmitter)
        `- Part (Part)
      |- Frame (Model)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        `- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
      |- MaxPoints (IntValue)
      |- TeleportRemote (RemoteEvent)
      `- ProText (Model)
        |- uni0050 (MeshPart)
        |- uni0072 (MeshPart)
        |- uni006F (MeshPart)
        |- uni0053 (MeshPart)
        |- uni0065 (MeshPart)
        |- uni0072 (MeshPart)
        |- uni0076 (MeshPart)
        |- uni0065 (MeshPart)
        `- uni0072 (MeshPart)
    |- Lights (Model)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Lantern (Model)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        `- Part (Part)
      |- Low Poly Lantern (Model)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        `- Part (Part)
      |- Low Poly Lantern (Model)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        `- Part (Part)
      `- Low Poly Lantern (Model)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        `- Part (Part)
    |- Stand (Model)
      |- Platform (MeshPart)
      |- Platform (MeshPart)
      |- Platform (MeshPart)
      |- Platform (MeshPart)
      |- Platform (MeshPart)
      `- Platform (MeshPart)
    |- Mountains (Model)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      `- HexagonGrass (MeshPart)
    |- TopPoints (Model)
      |- TitleOrder (IntValue)
      |- AllowTitles (BoolValue)
      |- TitleColor (Color3Value)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- ScoreBlock (Part)
        `- SurfaceGui (SurfaceGui)
          |- Category (Frame)
            |- AllTime (TextButton)
            |- Selection (Frame)
              `- UICorner (UICorner)
            `- UICorner (UICorner)
          |- DataLabel (TextLabel)
          `- LeaderboardAllTime (ScrollingFrame)
            |- Top001 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Name (TextLabel)
              |- Score (TextLabel)
              `- Position (TextLabel)
            |- Top003 (Frame)
              |- Avatar (ImageLabel)
                |- UICorner (UICorner)
                `- UIAspectRatioConstraint (UIAspectRatioConstraint)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top004 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top002 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top005 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top006 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top007 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top008 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top009 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top010 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top011 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top012 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top013 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top014 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top015 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top016 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top017 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top018 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top019 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top020 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top021 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top022 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top023 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top024 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top025 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top026 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top027 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top028 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top029 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top030 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top031 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top032 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top033 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top034 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top035 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top036 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top037 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top038 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top039 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top040 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top041 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top042 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top043 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top044 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top045 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top046 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top047 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top048 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top049 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top050 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top051 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top052 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top053 (Frame)
              |- Avatar (ImageLabel)
                |- UICorner (UICorner)
                `- UIAspectRatioConstraint (UIAspectRatioConstraint)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top054 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top055 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top056 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top057 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top058 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top059 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top060 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top061 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top062 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top063 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top064 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top065 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top066 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top067 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top068 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top069 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top070 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top071 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top072 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top073 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top074 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top075 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top076 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top077 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top078 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top079 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top080 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top081 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top082 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top083 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top084 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top085 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top086 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top087 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top088 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top089 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top090 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top091 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top092 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top093 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top094 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top095 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top096 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top097 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top098 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top099 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top100 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            `- UIListLayout (UIListLayout)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- Part (Part)
    |- canvasPixels (Folder)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- Part (Part)
    |- :p (Model)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        `- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
      |- Model (Model)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        `- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
      |- Model (Model)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        `- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- Part (Part)
    |- BobuxDonation (Model)
      |- TitleOrder (IntValue)
      |- AllowTitles (BoolValue)
      |- TitleColor (Color3Value)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- ScoreBlock (Part)
        `- SurfaceGui (SurfaceGui)
          |- Category (Frame)
            |- AllTime (TextButton)
            |- Selection (Frame)
              `- UICorner (UICorner)
            `- UICorner (UICorner)
          |- DataLabel (TextLabel)
          `- LeaderboardAllTime (ScrollingFrame)
            |- Top001 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Name (TextLabel)
              |- Score (TextLabel)
              `- Position (TextLabel)
            |- Top003 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top004 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top002 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top005 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top006 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top007 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top008 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top009 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top010 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top011 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top012 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top013 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top014 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top015 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top016 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top017 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top018 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top019 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top020 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top021 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top022 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top023 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top024 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top025 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top026 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top027 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top028 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top029 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top030 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top031 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top032 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top033 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top034 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top035 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top036 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top037 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top038 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top039 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top040 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top041 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top042 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top043 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top044 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top045 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top046 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top047 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top048 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top049 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top050 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top051 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top052 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top053 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top054 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top055 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top056 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top057 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top058 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top059 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top060 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top061 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top062 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top063 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top064 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top065 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top066 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top067 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top068 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top069 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top070 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top071 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top072 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top073 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top074 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top075 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top076 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top077 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top078 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top079 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top080 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top081 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top082 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top083 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top084 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top085 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top086 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top087 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top088 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top089 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top090 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top091 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top092 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top093 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top094 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top095 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top096 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top097 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top098 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top099 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top100 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            `- UIListLayout (UIListLayout)
      `- Part (Part)
    |- BobuxDonationFake (Model)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- ScoreBlock (Part)
    |- GamepassBoard (Model)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- ScoreBlock (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- Part (Part)
    |- Fence (Model)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      `- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
    |- Ground (Model)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- Part (Part)
    |- Trees (Model)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- LowPolyTree (Model)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
--[[ TRUNCATED: instance or line budget reached; see 07-COVERAGE.md ]]
```text

```

## Instance census

| Class | Count | Share |
| --- | :---: | :---: |
| 'Accessory' | 18 | 0.2% |
| 'AccessoryDescription' | 18 | 0.2% |
| 'Animation' | 221 | 2.8% |
| 'AnimationClipProvider' | 1 | 0% |
| 'AnimationConstraint' | 120 | 1.5% |
| 'Animator' | 8 | 0.1% |
| 'Attachment' | 444 | 5.6% |
| 'BallSocketConstraint' | 112 | 1.4% |
| 'BindableFunction' | 8 | 0.1% |
| 'BodyColors' | 8 | 0.1% |
| 'BodyPartDescription' | 48 | 0.6% |
| 'BoolValue' | 2 | 0% |
| 'CSGDictionaryService' | 1 | 0% |
| 'Camera' | 1 | 0% |
| 'CanvasGroup' | 1 | 0% |
| 'Chat' | 1 | 0% |
| 'Color3Value' | 2 | 0% |
| 'ContentProvider' | 1 | 0% |
| 'DataModel' | 1 | 0% |
| 'Decal' | 6 | 0.1% |
| 'FaceControls' | 8 | 0.1% |
| 'Folder' | 3 | 0% |
| 'Frame' | 260 | 3.3% |
| 'GuiService' | 1 | 0% |
| 'Highlight' | 1 | 0% |
| 'Humanoid' | 8 | 0.1% |
| 'HumanoidDescription' | 8 | 0.1% |
| 'ImageButton' | 1 | 0% |
| 'ImageLabel' | 210 | 2.6% |
| 'IntValue' | 3 | 0% |
| 'KeyframeSequenceProvider' | 1 | 0% |
| 'LocalScript' | 13 | 0.2% |
| 'LogService' | 1 | 0% |
| 'MarketplaceService' | 1 | 0% |
| 'MeshPart' | 601 | 7.5% |
| 'MicroProfilerService' | 1 | 0% |
| 'Model' | 136 | 1.7% |
| 'ModuleScript' | 45 | 0.6% |
| 'NoCollisionConstraint' | 152 | 1.9% |
| 'NonReplicatedCSGDictionaryService' | 1 | 0% |
| 'NumberValue' | 150 | 1.9% |
| 'Pants' | 7 | 0.1% |
| 'Part' | 1483 | 18.5% |
| 'ParticleEmitter' | 13 | 0.2% |
| 'Player' | 1 | 0% |
| 'PlayerGui' | 1 | 0% |
| 'PlayerScripts' | 1 | 0% |
| 'Players' | 1 | 0% |
| 'PointLight' | 21 | 0.3% |
| 'RemoteEvent' | 1 | 0% |
| 'RigidConstraint' | 18 | 0.2% |
| 'RunService' | 1 | 0% |
| 'RunningAverageItemDouble' | 2 | 0% |
| 'RunningAverageItemInt' | 42 | 0.5% |
| 'ScreenGui' | 8 | 0.1% |
| 'ScreenshotHud' | 1 | 0% |
| 'Script' | 10 | 0.1% |
| 'ScrollingFrame' | 4 | 0.1% |
| 'Seat' | 14 | 0.2% |
| 'Shirt' | 5 | 0.1% |
| 'ShirtGraphic' | 2 | 0% |
| 'Sound' | 72 | 0.9% |
| 'SoundService' | 1 | 0% |
| 'SpawnLocation' | 6 | 0.1% |
| 'Stats' | 1 | 0% |
| 'StatsItem' | 1136 | 14.2% |
| 'Status' | 8 | 0.1% |
| 'StringValue' | 263 | 3.3% |
| 'SurfaceAppearance' | 18 | 0.2% |
| 'SurfaceGui' | 4 | 0.1% |
| 'SurfaceLight' | 1 | 0% |
| 'Terrain' | 1 | 0% |
| 'TextBox' | 1 | 0% |
| 'TextButton' | 19 | 0.2% |
| 'TextLabel' | 915 | 11.4% |
| 'TimerService' | 1 | 0% |
| 'TotalCountTimeIntervalItem' | 36 | 0.5% |
| 'TouchTransmitter' | 1 | 0% |
| 'UIAspectRatioConstraint' | 211 | 2.6% |
| 'UICorner' | 239 | 3% |
| 'UIGradient' | 2 | 0% |
| 'UIListLayout' | 7 | 0.1% |
| 'UISizeConstraint' | 1 | 0% |
| 'UIStroke' | 2 | 0% |
| 'Vector3Value' | 588 | 7.4% |
| 'VideoCaptureService' | 1 | 0% |
| 'WedgePart' | 80 | 1% |
| 'Weld' | 1 | 0% |
| 'Workspace' | 1 | 0% |
| 'WrapTarget' | 120 | 1.5% |

