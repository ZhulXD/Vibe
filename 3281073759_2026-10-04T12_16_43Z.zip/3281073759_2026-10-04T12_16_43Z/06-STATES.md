# 06 - Observed state

---

| Measure | Count |
| --- | --- |
| Attribute cells tracked | 11 |
| Value objects tracked | 378 |
| Recorded transitions | 50 |
| Traffic events observed | 0 |
| Instances watched | 3793 |

## Attributes

| Instance | Attribute | Type | Observations | Changes | Min | Max | Direction | Last value | Distinct values |
| --- | --- | --- | :---: | :---: | :---: | :---: | --- | --- | :---: |
| 'Workspace.Lights.Low Poly Garden Lantern.Neon.PointLight' | 'ToTurnOn' | boolean | 14 | 13 | — | — | — | true | 14 |
| 'Workspace.Lights.Low Poly Lantern.Meshes/Booth42_Lantern2.PointLight' | 'ToTurnOn' | boolean | 4 | 3 | — | — | — | true | 4 |
| 'Lighting' | 'RBX_LightingTechnologyUnifiedMigration' | boolean | 1 | 0 | — | — | — | true | 1 |
| 'Workspace.jgifhhfyu.MessyHair.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.jgifhhfyu.Scarf.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.only_schoki.Accessory (BLING).Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.2000000… | 1 |
| 'Workspace.only_schoki.Accessory (defaultAccessory).Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.only_schoki.Bling.Handle.FaceFrontAttachment' | 'RBXOriginalAttachmentRotation' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -89.99… | 1 |
| 'Workspace.only_schoki.Bling.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8000000… | 1 |
| 'Workspace.oreo_152006.Accessory (Glitched Monochrome Glowing Stars).Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.oreo_152006.Accessory (Messy Y2K Girl Anime Hair w/ Cap & Headphones).Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |

## Value objects

| Instance | Class | Type | Observations | Changes | Min | Max | Direction | Last value |
| --- | --- | --- | :---: | :---: | :---: | :---: | --- | --- |
| 'Players.RXCKKLXSSS.leaderstats.Guesses' | IntValue | number | 3 | 2 | 75 | 77 | up 2 / down 0 | 77 |
| 'Players.RXCKKLXSSS.leaderstats.Points' | IntValue | number | 3 | 2 | 5808 | 5846 | up 2 / down 0 | 5846 |
| 'Players.jgifhhfyu.leaderstats.Points' | IntValue | number | 3 | 2 | 144 | 251 | up 2 / down 0 | 251 |
| 'Players.oreo_152006.leaderstats.Guesses' | IntValue | number | 3 | 2 | 5104 | 5106 | up 2 / down 0 | 5106 |
| 'Players.oreo_152006.leaderstats.Points' | IntValue | number | 3 | 2 | 465248 | 465329 | up 2 / down 0 | 465329 |
| 'Players.tifeoltYpsTickEHERei.leaderstats.Guesses' | IntValue | number | 3 | 2 | 3122 | 3124 | up 2 / down 0 | 3124 |
| 'Players.tifeoltYpsTickEHERei.leaderstats.Points' | IntValue | number | 3 | 2 | 259473 | 259562 | up 2 / down 0 | 259562 |
| 'ReplicatedStorage.DATA.RXCKKLXSSS.guesses' | NumberValue | number | 3 | 2 | 75 | 77 | up 2 / down 0 | 77 |
| 'ReplicatedStorage.DATA.RXCKKLXSSS.lastUpdate' | NumberValue | number | 3 | 2 | 1788569774 | 1791116299 | up 2 / down 0 | 1791116299 |
| 'ReplicatedStorage.DATA.RXCKKLXSSS.points' | NumberValue | number | 3 | 2 | 5808 | 5846 | up 2 / down 0 | 5846 |
| 'ReplicatedStorage.DATA.jgifhhfyu.lastUpdate' | NumberValue | number | 3 | 2 | 1791115898 | 1791116277 | up 2 / down 0 | 1791116277 |
| 'ReplicatedStorage.DATA.jgifhhfyu.points' | NumberValue | number | 3 | 2 | 144 | 251 | up 2 / down 0 | 251 |
| 'ReplicatedStorage.DATA.oreo_152006.guesses' | NumberValue | number | 3 | 2 | 5104 | 5106 | up 2 / down 0 | 5106 |
| 'ReplicatedStorage.DATA.oreo_152006.lastUpdate' | NumberValue | number | 3 | 2 | 1791116132 | 1791116288 | up 2 / down 0 | 1791116288 |
| 'ReplicatedStorage.DATA.oreo_152006.points' | NumberValue | number | 3 | 2 | 465248 | 465329 | up 2 / down 0 | 465329 |
| 'ReplicatedStorage.DATA.tifeoltYpsTickEHERei.guesses' | NumberValue | number | 3 | 2 | 3122 | 3124 | up 2 / down 0 | 3124 |
| 'ReplicatedStorage.DATA.tifeoltYpsTickEHERei.lastUpdate' | NumberValue | number | 3 | 2 | 1791041128 | 1791116270 | up 2 / down 0 | 1791116270 |
| 'ReplicatedStorage.DATA.tifeoltYpsTickEHERei.points' | NumberValue | number | 3 | 2 | 259473 | 259562 | up 2 / down 0 | 259562 |
| 'Players.SeoulKD.leaderstats.Guesses' | IntValue | number | 2 | 1 | 202 | 203 | up 1 / down 0 | 203 |
| 'Players.SeoulKD.leaderstats.Points' | IntValue | number | 2 | 1 | 25976 | 26024 | up 1 / down 0 | 26024 |
| 'Players.badgirl8799.leaderstats.Guesses' | IntValue | number | 2 | 1 | 2 | 3 | up 1 / down 0 | 3 |
| 'Players.badgirl8799.leaderstats.Points' | IntValue | number | 2 | 1 | 80 | 100 | up 1 / down 0 | 100 |
| 'Players.jgifhhfyu.leaderstats.Guesses' | IntValue | number | 2 | 1 | 3 | 4 | up 1 / down 0 | 4 |
| 'Players.only_schoki.leaderstats.Guesses' | IntValue | number | 2 | 1 | 0 | 19 | up 1 / down 0 | 19 |
| 'Players.only_schoki.leaderstats.Points' | IntValue | number | 2 | 1 | 0 | 1540 | up 1 / down 0 | 1540 |
| 'ReplicatedStorage.DATA.SeoulKD.guesses' | NumberValue | number | 2 | 1 | 202 | 203 | up 1 / down 0 | 203 |
| 'ReplicatedStorage.DATA.SeoulKD.lastUpdate' | NumberValue | number | 2 | 1 | 1791115548 | 1791116283 | up 1 / down 0 | 1791116283 |
| 'ReplicatedStorage.DATA.SeoulKD.points' | NumberValue | number | 2 | 1 | 25976 | 26024 | up 1 / down 0 | 26024 |
| 'ReplicatedStorage.DATA.badgirl8799.guesses' | NumberValue | number | 2 | 1 | 2 | 3 | up 1 / down 0 | 3 |
| 'ReplicatedStorage.DATA.badgirl8799.lastUpdate' | NumberValue | number | 2 | 1 | 1791112920 | 1791116224 | up 1 / down 0 | 1791116224 |
| 'ReplicatedStorage.DATA.badgirl8799.points' | NumberValue | number | 2 | 1 | 80 | 100 | up 1 / down 0 | 100 |
| 'ReplicatedStorage.DATA.jgifhhfyu.guesses' | NumberValue | number | 2 | 1 | 3 | 4 | up 1 / down 0 | 4 |
| 'Players.RXCKKLXSSS.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.MouseLockController.BoundKeys' | StringValue | string | 1 | 0 | — | — | — | "LeftShift,RightShift" |
| 'Players.SeoulKD.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.badgirl8799.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.jgifhhfyu.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.natureisthe_best8.leaderstats.Guesses' | IntValue | number | 1 | 0 | 48 | 48 | — | 48 |
| 'Players.natureisthe_best8.leaderstats.Points' | IntValue | number | 1 | 0 | 3412 | 3412 | — | 3412 |
| 'Players.natureisthe_best8.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.only_schoki.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.oreo_152006.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.tifeoltYpsTickEHERei.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'ReplicatedStorage.DATA.RXCKKLXSSS.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.RXCKKLXSSS.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.RXCKKLXSSS.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.RXCKKLXSSS.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.badgirl8799.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.badgirl8799.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.badgirl8799.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.badgirl8799.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.jgifhhfyu.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.jgifhhfyu.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.jgifhhfyu.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.jgifhhfyu.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.natureisthe_best8.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.natureisthe_best8.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.natureisthe_best8.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.natureisthe_best8.guesses' | NumberValue | number | 1 | 0 | 48 | 48 | — | 48 |
| 'ReplicatedStorage.DATA.natureisthe_best8.lastUpdate' | NumberValue | number | 1 | 0 | 1791116152 | 1791116152 | — | 1791116152 |
| 'ReplicatedStorage.DATA.natureisthe_best8.points' | NumberValue | number | 1 | 0 | 3412 | 3412 | — | 3412 |
| 'ReplicatedStorage.DATA.natureisthe_best8.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.only_schoki.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.only_schoki.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.only_schoki.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.only_schoki.guesses' | NumberValue | number | 1 | 0 | 19 | 19 | — | 19 |
| 'ReplicatedStorage.DATA.only_schoki.lastUpdate' | NumberValue | number | 1 | 0 | 1776707194 | 1776707194 | — | 1776707194 |
| 'ReplicatedStorage.DATA.only_schoki.points' | NumberValue | number | 1 | 0 | 1540 | 1540 | — | 1540 |
| 'ReplicatedStorage.DATA.only_schoki.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.oreo_152006.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.oreo_152006.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.oreo_152006.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.oreo_152006.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.tifeoltYpsTickEHERei.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.tifeoltYpsTickEHERei.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.tifeoltYpsTickEHERei.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.tifeoltYpsTickEHERei.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.getPublicData.DataName' | StringValue | string | 1 | 0 | — | — | — | "DATA" |
| 'Workspace.BobuxDonation.AllowTitles' | BoolValue | boolean | 1 | 0 | — | — | — | true |
| 'Workspace.BobuxDonation.TitleColor' | Color3Value | Color3 | 1 | 0 | — | — | — | Color3.new(0.8274510502815247, 0.5764706… |
| 'Workspace.BobuxDonation.TitleOrder' | IntValue | number | 1 | 0 | -1 | -1 | — | -1 |
| 'Workspace.Pro Server Portal.MaxPoints' | IntValue | number | 1 | 0 | 10000 | 10000 | — | 10000 |
| 'Workspace.TopPoints.AllowTitles' | BoolValue | boolean | 1 | 0 | — | — | — | true |
| 'Workspace.TopPoints.TitleColor' | Color3Value | Color3 | 1 | 0 | — | — | — | Color3.new(0.5372549295425415, 0.7176470… |
| 'Workspace.TopPoints.TitleOrder' | IntValue | number | 1 | 0 | -2 | -2 | — | -2 |
| 'Workspace.jgifhhfyu.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.jgifhhfyu.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.jgifhhfyu.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.jgifhhfyu.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.jgifhhfyu.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.jgifhhfyu.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.jgifhhfyu.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.jgifhhfyu.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.jgifhhfyu.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.jgifhhfyu.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.jgifhhfyu.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.jgifhhfyu.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.jgifhhfyu.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.pose' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.pose.RthroIdlePose.Weight' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.jgifhhfyu.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.jgifhhfyu.MessyHair.Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.6574800… |
| 'Workspace.jgifhhfyu.MessyHair.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3760120… |
| 'Workspace.jgifhhfyu.Scarf.Handle.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.jgifhhfyu.Scarf.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.0313193… |
| 'Workspace.only_schoki.Accessory (BLING).Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.only_schoki.Accessory (BLING).Handle.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.016578… |
| 'Workspace.only_schoki.Accessory (BLING).Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3859024… |
| 'Workspace.only_schoki.Accessory (defaultAccessory).Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.only_schoki.Accessory (defaultAccessory).Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0184879… |
| 'Workspace.only_schoki.Accessory (defaultAccessory).Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.7119929… |
| 'Workspace.only_schoki.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.only_schoki.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.climb.ClimbAnim.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.only_schoki.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.only_schoki.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.only_schoki.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.only_schoki.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.only_schoki.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.only_schoki.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.only_schoki.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.only_schoki.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.only_schoki.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.only_schoki.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.only_schoki.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.only_schoki.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.pose' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.pose.PoseAnim.Weight' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.only_schoki.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.only_schoki.Bling.Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.only_schoki.Bling.Handle.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.029693… |
| 'Workspace.only_schoki.Bling.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1686553… |
| 'Workspace.only_schoki.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.only_schoki.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.0564098… |
| 'Workspace.only_schoki.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.0564098… |
| 'Workspace.only_schoki.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.7911979… |
| 'Workspace.only_schoki.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.7911979… |
| 'Workspace.only_schoki.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.1814571… |
| 'Workspace.only_schoki.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.2305041… |
| 'Workspace.only_schoki.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 0.8799999952316284 | 0.8799999952316284 | — | 0.8799999952316284 |
| 'Workspace.only_schoki.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 0.9599999785423279 | 0.9599999785423279 | — | 0.9599999785423279 |
| 'Workspace.only_schoki.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0.5 | 0.5 | — | 0.5 |
| 'Workspace.only_schoki.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.only_schoki.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 0.7599999904632568 | 0.7599999904632568 | — | 0.7599999904632568 |
| 'Workspace.only_schoki.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 0.9599999785423279 | 0.9599999785423279 | — | 0.9599999785423279 |
| 'Workspace.only_schoki.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.only_schoki.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.only_schoki.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.only_schoki.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.788139… |
| 'Workspace.only_schoki.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0182774… |
| 'Workspace.only_schoki.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.only_schoki.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.only_schoki.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.017243… |
| 'Workspace.only_schoki.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1085174… |
| 'Workspace.only_schoki.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459886… |
| 'Workspace.only_schoki.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.only_schoki.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1874169… |
| 'Workspace.only_schoki.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.174442… |
| 'Workspace.only_schoki.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623244… |
| 'Workspace.only_schoki.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.only_schoki.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9802322… |
| 'Workspace.only_schoki.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.only_schoki.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.only_schoki.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.160127… |
| 'Workspace.only_schoki.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.022783… |
| 'Workspace.only_schoki.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.only_schoki.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.only_schoki.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489318… |
| 'Workspace.only_schoki.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.only_schoki.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.9406967… |
| 'Workspace.only_schoki.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.only_schoki.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.only_schoki.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.349282… |
| 'Workspace.only_schoki.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3261278… |
| 'Workspace.only_schoki.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3492811… |
| 'Workspace.only_schoki.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.only_schoki.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.212736… |
| 'Workspace.only_schoki.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000001… |
| 'Workspace.only_schoki.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.070802… |
| 'Workspace.only_schoki.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.only_schoki.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.only_schoki.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.101… |
| 'Workspace.only_schoki.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.018277… |
| 'Workspace.only_schoki.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.only_schoki.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459872… |
| 'Workspace.only_schoki.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0172429… |
| 'Workspace.only_schoki.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.090098… |
| 'Workspace.only_schoki.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.only_schoki.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623249… |
| 'Workspace.only_schoki.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.187417… |
| 'Workspace.only_schoki.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1928601… |
| 'Workspace.only_schoki.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.only_schoki.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.54… |
| 'Workspace.only_schoki.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.379… |
| 'Workspace.only_schoki.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.only_schoki.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489327… |
| 'Workspace.only_schoki.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1601286… |
| 'Workspace.only_schoki.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0227840… |
| 'Workspace.only_schoki.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.only_schoki.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.only_schoki.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.only_schoki.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.420… |
| 'Workspace.only_schoki.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.40… |
| 'Workspace.only_schoki.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.only_schoki.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.only_schoki.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.only_schoki.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.only_schoki.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.only_schoki.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.only_schoki.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.9644888… |
| 'Workspace.only_schoki.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.only_schoki.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3034231… |
| 'Workspace.only_schoki.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.only_schoki.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.only_schoki.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.only_schoki.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.oreo_152006.Accessory (Glitched Monochrome Glowing Stars).Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.oreo_152006.Accessory (Glitched Monochrome Glowing Stars).Handle.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0579944… |
| 'Workspace.oreo_152006.Accessory (Glitched Monochrome Glowing Stars).Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 6.7456932… |
| 'Workspace.oreo_152006.Accessory (Messy Y2K Girl Anime Hair w/ Cap & Headphones).Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0299999… |
| 'Workspace.oreo_152006.Accessory (Messy Y2K Girl Anime Hair w/ Cap & Headphones).Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3496360… |
| 'Workspace.oreo_152006.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.oreo_152006.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.oreo_152006.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.oreo_152006.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.oreo_152006.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.oreo_152006.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.oreo_152006.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.oreo_152006.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.oreo_152006.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.oreo_152006.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.oreo_152006.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.oreo_152006.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.oreo_152006.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.pose' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.pose.RthroIdlePose.Weight' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.oreo_152006.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.oreo_152006.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.oreo_152006.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9921589… |
| 'Workspace.oreo_152006.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.0895277… |
| 'Workspace.oreo_152006.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.oreo_152006.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.oreo_152006.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3896427… |
| 'Workspace.oreo_152006.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1978399… |
| 'Workspace.oreo_152006.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 0.8500000238418579 | 0.8500000238418579 | — | 0.8500000238418579 |
| 'Workspace.oreo_152006.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 0.8999999761581421 | 0.8999999761581421 | — | 0.8999999761581421 |
| 'Workspace.oreo_152006.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.oreo_152006.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.oreo_152006.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 0.699999988079071 | 0.699999988079071 | — | 0.699999988079071 |
| 'Workspace.oreo_152006.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 0.9700000286102295 | 0.9700000286102295 | — | 0.9700000286102295 |
| 'Workspace.oreo_152006.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.oreo_152006.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.oreo_152006.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.oreo_152006.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.788139… |
| 'Workspace.oreo_152006.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0182774… |
| 'Workspace.oreo_152006.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.oreo_152006.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.oreo_152006.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.017243… |
| 'Workspace.oreo_152006.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1085174… |
| 'Workspace.oreo_152006.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459886… |
| 'Workspace.oreo_152006.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.oreo_152006.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1874169… |
| 'Workspace.oreo_152006.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.174442… |
| 'Workspace.oreo_152006.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623244… |
| 'Workspace.oreo_152006.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.oreo_152006.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9802322… |
| 'Workspace.oreo_152006.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.oreo_152006.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.oreo_152006.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.160127… |
| 'Workspace.oreo_152006.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.022783… |
| 'Workspace.oreo_152006.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.oreo_152006.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.oreo_152006.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489318… |
| 'Workspace.oreo_152006.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.oreo_152006.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.9406967… |
| 'Workspace.oreo_152006.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.oreo_152006.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.oreo_152006.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.349282… |
| 'Workspace.oreo_152006.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3261278… |
| 'Workspace.oreo_152006.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3492811… |
| 'Workspace.oreo_152006.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.oreo_152006.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.212736… |
| 'Workspace.oreo_152006.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000001… |
| 'Workspace.oreo_152006.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.070802… |
| 'Workspace.oreo_152006.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.oreo_152006.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.oreo_152006.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.101… |
| 'Workspace.oreo_152006.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.018277… |
| 'Workspace.oreo_152006.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.oreo_152006.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459872… |
| 'Workspace.oreo_152006.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0172429… |
| 'Workspace.oreo_152006.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.090098… |
| 'Workspace.oreo_152006.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.oreo_152006.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623249… |
| 'Workspace.oreo_152006.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.187417… |
| 'Workspace.oreo_152006.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1928601… |
| 'Workspace.oreo_152006.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.oreo_152006.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.54… |
| 'Workspace.oreo_152006.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.379… |
| 'Workspace.oreo_152006.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.oreo_152006.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489327… |
| 'Workspace.oreo_152006.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1601286… |
| 'Workspace.oreo_152006.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0227840… |
| 'Workspace.oreo_152006.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.oreo_152006.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.oreo_152006.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.oreo_152006.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.420… |
| 'Workspace.oreo_152006.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.40… |
| 'Workspace.oreo_152006.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.oreo_152006.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.oreo_152006.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.oreo_152006.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.oreo_152006.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.oreo_152006.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.oreo_152006.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.9644888… |
| 'Workspace.oreo_152006.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.oreo_152006.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3034231… |
| 'Workspace.oreo_152006.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.oreo_152006.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.oreo_152006.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.oreo_152006.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |

## Numeric argument positions

- Every numeric argument position observed on any remote, with its
- observed range and how often the value moved up or down.

No numeric argument position was observed.

