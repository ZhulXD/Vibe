# 05 - Scripts

---

| Measure | Count |
| --- | --- |
| Script instances found | 132 |
| Authored by the game | 132 |
| of those, readable by the client | 128 |
| Belonging to Roblox's own engine | 0 |
| Readable by the client, all scripts | 128 |
| Not client-side or unreadable | 4 |
| Skipped by the inventory cap | 0 |
| Skipped as duplicates | 0 |
| Had no readable debug id | 0 |

## Decompilation methods

| Method | Scripts |
| --- | :---: |

- `source`: the script's own Source property was readable.
- `executor-decompile`: the executor's decompile() succeeded.
- `bytecode-disassembly`: bytecode parsed and disassembled.
- `bytecode-strings`: the instruction stream was not parsed, but the
- string literals were. The file lists those literals and the raw bytes.
- `bytecode-unsupported`: bytecode was obtained but nothing could be read from it.
- `no-bytecode`: no bytecode available for this script.

## Script inventory and cross-reference

| Script path | Class | RunContext | Disabled | Decompiled by | Outgoing calls observed | Incoming handled | Unavailability reason |
| --- | --- | --- | :---: | --- | --- | --- | --- |
| 'LocalScript' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'LocalScript' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerGui.BobuxDonationGui.Donation Script' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerGui.GamepassGui.Gamepass Script' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.LocalScript' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.BaseCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.BaseOcclusion' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraInput' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraToggleStateController' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraUI' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraUtils' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ClassicCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.Invisicam' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.LegacyCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.MouseLockController' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.OrbitalCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.Poppercam' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.TransparencyController' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRBaseCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRVehicleCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ZoomController' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ZoomController.Popper' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CharacterUtil' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.FlagUtil' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.BaseCharacterController' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.ClickToMoveController' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.DynamicThumbstick' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.Gamepad' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.Keyboard' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.PathDisplay' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.TouchJump' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.TouchThumbstick' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.VRNavigation' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.VehicleController' | ModuleScript | — | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerScriptsLoader' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.RbxCharacterSounds' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'Players.SeoulKD.PlayerScripts.RbxCharacterSounds.AtomicBinding' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.DrawCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.CheckboxLabel' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.CONSTANTS' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.CreateRadial' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.Triangle' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.TextMask.Integer' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.TextMask.Number' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.TextMask.String' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.TextMask.Vector2' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.TextMask.Vector3' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Dragger' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Dropdown' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.RadialMenu' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.RadioButtonGroup' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.RadioButtonLabel' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Slider' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.TextMask' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Constructors.List' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.LazyLoader' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Utilities.Maid' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.GuiLib.Utilities.Spring' | ModuleScript | — | no | not attempted | — | — | — |
| 'ReplicatedStorage.getPublicData' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterGui.BobuxDonationGui.Donation Script' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'StarterGui.GamepassGui.Gamepass Script' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.LocalScript' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.BaseCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.BaseOcclusion' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraInput' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraToggleStateController' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraUI' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraUtils' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ClassicCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.Invisicam' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.LegacyCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.MouseLockController' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.OrbitalCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.Poppercam' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.TransparencyController' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRBaseCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRVehicleCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ZoomController' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ZoomController.Popper' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CameraWrapper' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CharacterUtil' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.ConnectionUtil' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.FlagUtil' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.BaseCharacterController' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.ClickToMoveController' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.DynamicThumbstick' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.Gamepad' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.Keyboard' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.PathDisplay' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.TouchJump' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.TouchThumbstick' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.VRNavigation' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.VehicleController' | ModuleScript | — | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerScriptsLoader' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.RbxCharacterSounds' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.RbxCharacterSounds.AtomicBinding' | ModuleScript | — | no | not attempted | — | — | — |
| 'Workspace.BruhVaria611Alt.Animate' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'Workspace.BruhVaria611Alt.Health' | Script | Enum.RunContext.Legacy | no | not attempted | — | — | RunContext is not client |
| 'Workspace.Pro Server Portal.LocalScript' | Script | Enum.RunContext.Client | no | not attempted | — | — | — |
| 'Workspace.Pro Server Portal.Script' | Script | Enum.RunContext.Legacy | no | not attempted | — | — | RunContext is not client |
| 'Workspace.lhabebemoako.Animate' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'Workspace.lhabebemoako.Health' | Script | Enum.RunContext.Legacy | no | not attempted | — | — | RunContext is not client |
| 'Workspace.nota0ki.Animate' | LocalScript | Enum.RunContext.Legacy | no | not attempted | — | — | — |
| 'Workspace.nota0ki.Health' | Script | Enum.RunContext.Legacy | no | not attempted | — | — | RunContext is not client |

## Scripts with no observed traffic involvement (132)

- `LocalScript`
- `LocalScript`
- `Players.SeoulKD.PlayerGui.BobuxDonationGui.Donation Script`
- `Players.SeoulKD.PlayerGui.GamepassGui.Gamepass Script`
- `Players.SeoulKD.PlayerScripts.LocalScript`
- `Players.SeoulKD.PlayerScripts.PlayerModule`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.BaseCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.BaseOcclusion`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraInput`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraToggleStateController`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraUI`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraUtils`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ClassicCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.Invisicam`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.LegacyCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.MouseLockController`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.OrbitalCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.Poppercam`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.TransparencyController`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRBaseCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRVehicleCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ZoomController`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ZoomController.Popper`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CharacterUtil`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.FlagUtil`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.BaseCharacterController`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.ClickToMoveController`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.DynamicThumbstick`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.Gamepad`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.Keyboard`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.PathDisplay`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.TouchJump`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.TouchThumbstick`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.VRNavigation`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.VehicleController`
- `Players.SeoulKD.PlayerScripts.PlayerScriptsLoader`
- `Players.SeoulKD.PlayerScripts.RbxCharacterSounds`
- `Players.SeoulKD.PlayerScripts.RbxCharacterSounds.AtomicBinding`
- `ReplicatedStorage.DrawCamera`
- `ReplicatedStorage.GuiLib.Classes.CheckboxLabel`
- `ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.CONSTANTS`
- `ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.CreateRadial`
- `ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.Triangle`
- `ReplicatedStorage.GuiLib.Classes.Children.TextMask.Integer`
- `ReplicatedStorage.GuiLib.Classes.Children.TextMask.Number`
- `ReplicatedStorage.GuiLib.Classes.Children.TextMask.String`
- `ReplicatedStorage.GuiLib.Classes.Children.TextMask.Vector2`
- `ReplicatedStorage.GuiLib.Classes.Children.TextMask.Vector3`
- `ReplicatedStorage.GuiLib.Classes.Dragger`
- `ReplicatedStorage.GuiLib.Classes.Dropdown`
- `ReplicatedStorage.GuiLib.Classes.RadialMenu`
- `ReplicatedStorage.GuiLib.Classes.RadioButtonGroup`
- `ReplicatedStorage.GuiLib.Classes.RadioButtonLabel`
- `ReplicatedStorage.GuiLib.Classes.Slider`
- `ReplicatedStorage.GuiLib.Classes.TextMask`
- `ReplicatedStorage.GuiLib.Constructors.List`
- `ReplicatedStorage.GuiLib.LazyLoader`
- `ReplicatedStorage.GuiLib.Utilities.Maid`
- `ReplicatedStorage.GuiLib.Utilities.Spring`
- `ReplicatedStorage.getPublicData`
- `StarterGui.BobuxDonationGui.Donation Script`
- `StarterGui.GamepassGui.Gamepass Script`
- `StarterPlayer.StarterPlayerScripts.LocalScript`
- `StarterPlayer.StarterPlayerScripts.PlayerModule`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.BaseCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.BaseOcclusion`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraInput`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraToggleStateController`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraUI`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraUtils`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ClassicCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.Invisicam`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.LegacyCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.MouseLockController`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.OrbitalCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.Poppercam`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.TransparencyController`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRBaseCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRVehicleCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ZoomController`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ZoomController.Popper`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CameraWrapper`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CharacterUtil`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.ConnectionUtil`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.FlagUtil`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.BaseCharacterController`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.ClickToMoveController`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.DynamicThumbstick`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.Gamepad`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.Keyboard`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.PathDisplay`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.TouchJump`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.TouchThumbstick`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.VRNavigation`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.VehicleController`
- `StarterPlayer.StarterPlayerScripts.PlayerScriptsLoader`
- `StarterPlayer.StarterPlayerScripts.RbxCharacterSounds`
- `StarterPlayer.StarterPlayerScripts.RbxCharacterSounds.AtomicBinding`
- `Workspace.BruhVaria611Alt.Animate`
- `Workspace.BruhVaria611Alt.Health`
- `Workspace.Pro Server Portal.LocalScript`
- `Workspace.Pro Server Portal.Script`
- `Workspace.lhabebemoako.Animate`
- `Workspace.lhabebemoako.Health`
- `Workspace.nota0ki.Animate`
- `Workspace.nota0ki.Health`

