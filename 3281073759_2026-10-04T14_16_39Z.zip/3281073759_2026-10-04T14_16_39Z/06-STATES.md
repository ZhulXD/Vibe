# 06 - Observed state

---

| Measure | Count |
| --- | --- |
| Attribute cells tracked | 4 |
| Value objects tracked | 331 |
| Recorded transitions | 0 |
| Traffic events observed | 0 |
| Instances watched | 1839 |

## Attributes

| Instance | Attribute | Type | Observations | Changes | Min | Max | Direction | Last value | Distinct values |
| --- | --- | --- | :---: | :---: | :---: | :---: | --- | --- | :---: |
| 'Workspace.Lights.Low Poly Garden Lantern.Neon.PointLight' | 'ToTurnOn' | boolean | 14 | 13 | — | — | — | true | 14 |
| 'Workspace.Lights.Low Poly Lantern.Meshes/Booth42_Lantern2.PointLight' | 'ToTurnOn' | boolean | 4 | 3 | — | — | — | true | 4 |
| 'Lighting' | 'RBX_LightingTechnologyUnifiedMigration' | boolean | 1 | 0 | — | — | — | true | 1 |
| 'Workspace.BruhVaria611Alt.Accessory (Meshes/4Accessory).Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |

## Value objects

| Instance | Class | Type | Observations | Changes | Min | Max | Direction | Last value |
| --- | --- | --- | :---: | :---: | :---: | :---: | --- | --- |
| 'Players.Aljun_45677.leaderstats.Guesses' | IntValue | number | 1 | 0 | 12 | 12 | — | 12 |
| 'Players.Aljun_45677.leaderstats.Points' | IntValue | number | 1 | 0 | 928 | 928 | — | 928 |
| 'Players.Aljun_45677.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.BruhVaria611Alt.leaderstats.Guesses' | IntValue | number | 1 | 0 | 185 | 185 | — | 185 |
| 'Players.BruhVaria611Alt.leaderstats.Points' | IntValue | number | 1 | 0 | 12806 | 12806 | — | 12806 |
| 'Players.BruhVaria611Alt.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.MouseLockController.BoundKeys' | StringValue | string | 1 | 0 | — | — | — | "LeftShift,RightShift" |
| 'Players.SeoulKD.leaderstats.Guesses' | IntValue | number | 1 | 0 | 208 | 208 | — | 208 |
| 'Players.SeoulKD.leaderstats.Points' | IntValue | number | 1 | 0 | 26402 | 26402 | — | 26402 |
| 'Players.SeoulKD.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.hi_probacoa.leaderstats.Guesses' | IntValue | number | 1 | 0 | 119 | 119 | — | 119 |
| 'Players.hi_probacoa.leaderstats.Points' | IntValue | number | 1 | 0 | 6388 | 6388 | — | 6388 |
| 'Players.hi_probacoa.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.ixxudos.leaderstats.Guesses' | IntValue | number | 1 | 0 | 429 | 429 | — | 429 |
| 'Players.ixxudos.leaderstats.Points' | IntValue | number | 1 | 0 | 31414 | 31414 | — | 31414 |
| 'Players.ixxudos.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.lhabebemoako.leaderstats.Guesses' | IntValue | number | 1 | 0 | 13 | 13 | — | 13 |
| 'Players.lhabebemoako.leaderstats.Points' | IntValue | number | 1 | 0 | 1001 | 1001 | — | 1001 |
| 'Players.lhabebemoako.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.nota0ki.leaderstats.Guesses' | IntValue | number | 1 | 0 | 8 | 8 | — | 8 |
| 'Players.nota0ki.leaderstats.Points' | IntValue | number | 1 | 0 | 568 | 568 | — | 568 |
| 'Players.nota0ki.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.systemsystemra.leaderstats.Guesses' | IntValue | number | 1 | 0 | 170 | 170 | — | 170 |
| 'Players.systemsystemra.leaderstats.Points' | IntValue | number | 1 | 0 | 14389 | 14389 | — | 14389 |
| 'Players.systemsystemra.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'ReplicatedStorage.DATA.Aljun_45677.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Aljun_45677.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Aljun_45677.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Aljun_45677.guesses' | NumberValue | number | 1 | 0 | 12 | 12 | — | 12 |
| 'ReplicatedStorage.DATA.Aljun_45677.lastUpdate' | NumberValue | number | 1 | 0 | 1791123372 | 1791123372 | — | 1791123372 |
| 'ReplicatedStorage.DATA.Aljun_45677.points' | NumberValue | number | 1 | 0 | 928 | 928 | — | 928 |
| 'ReplicatedStorage.DATA.Aljun_45677.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.BruhVaria611Alt.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.BruhVaria611Alt.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.BruhVaria611Alt.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.BruhVaria611Alt.guesses' | NumberValue | number | 1 | 0 | 185 | 185 | — | 185 |
| 'ReplicatedStorage.DATA.BruhVaria611Alt.lastUpdate' | NumberValue | number | 1 | 0 | 1791123375 | 1791123375 | — | 1791123375 |
| 'ReplicatedStorage.DATA.BruhVaria611Alt.points' | NumberValue | number | 1 | 0 | 12806 | 12806 | — | 12806 |
| 'ReplicatedStorage.DATA.BruhVaria611Alt.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.guesses' | NumberValue | number | 1 | 0 | 208 | 208 | — | 208 |
| 'ReplicatedStorage.DATA.SeoulKD.lastUpdate' | NumberValue | number | 1 | 0 | 1791121322 | 1791121322 | — | 1791121322 |
| 'ReplicatedStorage.DATA.SeoulKD.points' | NumberValue | number | 1 | 0 | 26402 | 26402 | — | 26402 |
| 'ReplicatedStorage.DATA.SeoulKD.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.hi_probacoa.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.hi_probacoa.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.hi_probacoa.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.hi_probacoa.guesses' | NumberValue | number | 1 | 0 | 119 | 119 | — | 119 |
| 'ReplicatedStorage.DATA.hi_probacoa.lastUpdate' | NumberValue | number | 1 | 0 | 1791123374 | 1791123374 | — | 1791123374 |
| 'ReplicatedStorage.DATA.hi_probacoa.points' | NumberValue | number | 1 | 0 | 6388 | 6388 | — | 6388 |
| 'ReplicatedStorage.DATA.hi_probacoa.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.ixxudos.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.ixxudos.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.ixxudos.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.ixxudos.guesses' | NumberValue | number | 1 | 0 | 429 | 429 | — | 429 |
| 'ReplicatedStorage.DATA.ixxudos.lastUpdate' | NumberValue | number | 1 | 0 | 1791123370 | 1791123370 | — | 1791123370 |
| 'ReplicatedStorage.DATA.ixxudos.points' | NumberValue | number | 1 | 0 | 31414 | 31414 | — | 31414 |
| 'ReplicatedStorage.DATA.ixxudos.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.lhabebemoako.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.lhabebemoako.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.lhabebemoako.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.lhabebemoako.guesses' | NumberValue | number | 1 | 0 | 13 | 13 | — | 13 |
| 'ReplicatedStorage.DATA.lhabebemoako.lastUpdate' | NumberValue | number | 1 | 0 | 1791123296 | 1791123296 | — | 1791123296 |
| 'ReplicatedStorage.DATA.lhabebemoako.points' | NumberValue | number | 1 | 0 | 1001 | 1001 | — | 1001 |
| 'ReplicatedStorage.DATA.lhabebemoako.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.nota0ki.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.nota0ki.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.nota0ki.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.nota0ki.guesses' | NumberValue | number | 1 | 0 | 8 | 8 | — | 8 |
| 'ReplicatedStorage.DATA.nota0ki.lastUpdate' | NumberValue | number | 1 | 0 | 1723815187 | 1723815187 | — | 1723815187 |
| 'ReplicatedStorage.DATA.nota0ki.points' | NumberValue | number | 1 | 0 | 568 | 568 | — | 568 |
| 'ReplicatedStorage.DATA.nota0ki.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.systemsystemra.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.systemsystemra.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.systemsystemra.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.systemsystemra.guesses' | NumberValue | number | 1 | 0 | 170 | 170 | — | 170 |
| 'ReplicatedStorage.DATA.systemsystemra.lastUpdate' | NumberValue | number | 1 | 0 | 1791123369 | 1791123369 | — | 1791123369 |
| 'ReplicatedStorage.DATA.systemsystemra.points' | NumberValue | number | 1 | 0 | 14389 | 14389 | — | 14389 |
| 'ReplicatedStorage.DATA.systemsystemra.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.getPublicData.DataName' | StringValue | string | 1 | 0 | — | — | — | "DATA" |
| 'Workspace.BobuxDonation.AllowTitles' | BoolValue | boolean | 1 | 0 | — | — | — | true |
| 'Workspace.BobuxDonation.TitleColor' | Color3Value | Color3 | 1 | 0 | — | — | — | Color3.new(0.8274510502815247, 0.5764706… |
| 'Workspace.BobuxDonation.TitleOrder' | IntValue | number | 1 | 0 | -1 | -1 | — | -1 |
| 'Workspace.BruhVaria611Alt.Accessory (Meshes/4Accessory).Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.BruhVaria611Alt.Accessory (Meshes/4Accessory).Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0513229… |
| 'Workspace.BruhVaria611Alt.Accessory (Meshes/4Accessory).Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.5764279… |
| 'Workspace.BruhVaria611Alt.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.BruhVaria611Alt.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.climb.ClimbAnim.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.BruhVaria611Alt.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.BruhVaria611Alt.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.BruhVaria611Alt.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.BruhVaria611Alt.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.BruhVaria611Alt.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.BruhVaria611Alt.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.BruhVaria611Alt.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.BruhVaria611Alt.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.BruhVaria611Alt.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.BruhVaria611Alt.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.fall.fall.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.BruhVaria611Alt.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.BruhVaria611Alt.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.BruhVaria611Alt.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.jump.jump.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.BruhVaria611Alt.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.pose' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.pose.RthroIdlePose.Weight' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.BruhVaria611Alt.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.run.run.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.BruhVaria611Alt.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Animate.walk.walk.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.BruhVaria611Alt.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.BruhVaria611Alt.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.BruhVaria611Alt.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0.0149… |
| 'Workspace.BruhVaria611Alt.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.026… |
| 'Workspace.BruhVaria611Alt.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0002131… |
| 'Workspace.BruhVaria611Alt.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0002131… |
| 'Workspace.BruhVaria611Alt.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0002131… |
| 'Workspace.BruhVaria611Alt.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1979999… |
| 'Workspace.BruhVaria611Alt.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 0.9100000262260437 | 0.9100000262260437 | — | 0.9100000262260437 |
| 'Workspace.BruhVaria611Alt.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 1.0499999523162842 | 1.0499999523162842 | — | 1.0499999523162842 |
| 'Workspace.BruhVaria611Alt.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0.5 | 0.5 | — | 0.5 |
| 'Workspace.BruhVaria611Alt.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.BruhVaria611Alt.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 0.8199999928474426 | 0.8199999928474426 | — | 0.8199999928474426 |
| 'Workspace.BruhVaria611Alt.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.BruhVaria611Alt.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.BruhVaria611Alt.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.BruhVaria611Alt.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.BruhVaria611Alt.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.788139… |
| 'Workspace.BruhVaria611Alt.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0182774… |
| 'Workspace.BruhVaria611Alt.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.BruhVaria611Alt.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.149… |
| 'Workspace.BruhVaria611Alt.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004789… |
| 'Workspace.BruhVaria611Alt.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.3001… |
| 'Workspace.BruhVaria611Alt.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004786… |
| 'Workspace.BruhVaria611Alt.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004786… |
| 'Workspace.BruhVaria611Alt.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.0518… |
| 'Workspace.BruhVaria611Alt.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.BruhVaria611Alt.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9802322… |
| 'Workspace.BruhVaria611Alt.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.BruhVaria611Alt.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004792… |
| 'Workspace.BruhVaria611Alt.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3841857… |
| 'Workspace.BruhVaria611Alt.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5000003… |
| 'Workspace.BruhVaria611Alt.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5000003… |
| 'Workspace.BruhVaria611Alt.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1686… |
| 'Workspace.BruhVaria611Alt.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.BruhVaria611Alt.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.9406967… |
| 'Workspace.BruhVaria611Alt.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.BruhVaria611Alt.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.BruhVaria611Alt.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.5, -0.… |
| 'Workspace.BruhVaria611Alt.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.6722400… |
| 'Workspace.BruhVaria611Alt.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5, -0.3… |
| 'Workspace.BruhVaria611Alt.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.328… |
| 'Workspace.BruhVaria611Alt.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -2.720393… |
| 'Workspace.BruhVaria611Alt.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -3.027915… |
| 'Workspace.BruhVaria611Alt.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.301057… |
| 'Workspace.BruhVaria611Alt.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 4.8985526… |
| 'Workspace.BruhVaria611Alt.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.BruhVaria611Alt.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.101… |
| 'Workspace.BruhVaria611Alt.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.018277… |
| 'Workspace.BruhVaria611Alt.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.3001… |
| 'Workspace.BruhVaria611Alt.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.149… |
| 'Workspace.BruhVaria611Alt.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.5762786… |
| 'Workspace.BruhVaria611Alt.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.0518… |
| 'Workspace.BruhVaria611Alt.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1920928… |
| 'Workspace.BruhVaria611Alt.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1920928… |
| 'Workspace.BruhVaria611Alt.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.BruhVaria611Alt.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.54… |
| 'Workspace.BruhVaria611Alt.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.379… |
| 'Workspace.BruhVaria611Alt.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1686… |
| 'Workspace.BruhVaria611Alt.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.BruhVaria611Alt.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.344650… |
| 'Workspace.BruhVaria611Alt.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.BruhVaria611Alt.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.BruhVaria611Alt.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.BruhVaria611Alt.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.420… |
| 'Workspace.BruhVaria611Alt.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.40… |
| 'Workspace.BruhVaria611Alt.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.BruhVaria611Alt.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.2246434… |
| 'Workspace.BruhVaria611Alt.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.2246434… |
| 'Workspace.BruhVaria611Alt.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.713337… |
| 'Workspace.BruhVaria611Alt.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.916026… |
| 'Workspace.BruhVaria611Alt.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.916026… |
| 'Workspace.BruhVaria611Alt.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 9.0186951… |
| 'Workspace.BruhVaria611Alt.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.4492934… |
| 'Workspace.BruhVaria611Alt.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.8390778… |
| 'Workspace.BruhVaria611Alt.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7133379… |
| 'Workspace.BruhVaria611Alt.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9160000… |
| 'Workspace.BruhVaria611Alt.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9160000… |
| 'Workspace.BruhVaria611Alt.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 4.8985526… |
| 'Workspace.Pro Server Portal.MaxPoints' | IntValue | number | 1 | 0 | 10000 | 10000 | — | 10000 |
| 'Workspace.TopPoints.AllowTitles' | BoolValue | boolean | 1 | 0 | — | — | — | true |
| 'Workspace.TopPoints.TitleColor' | Color3Value | Color3 | 1 | 0 | — | — | — | Color3.new(0.5372549295425415, 0.7176470… |
| 'Workspace.TopPoints.TitleOrder' | IntValue | number | 1 | 0 | -2 | -2 | — | -2 |
| 'Workspace.nota0ki.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.nota0ki.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.nota0ki.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.nota0ki.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.nota0ki.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.nota0ki.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.nota0ki.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.nota0ki.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.nota0ki.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.nota0ki.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.nota0ki.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.nota0ki.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.nota0ki.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.nota0ki.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.001326… |
| 'Workspace.nota0ki.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.001326… |
| 'Workspace.nota0ki.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0486309… |
| 'Workspace.nota0ki.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.029053… |
| 'Workspace.nota0ki.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.021623… |
| 'Workspace.nota0ki.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.8109616… |
| 'Workspace.nota0ki.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.nota0ki.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.nota0ki.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.nota0ki.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.nota0ki.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.nota0ki.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.nota0ki.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.nota0ki.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.nota0ki.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.nota0ki.LeftFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.005521… |
| 'Workspace.nota0ki.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.087254… |
| 'Workspace.nota0ki.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7049179… |
| 'Workspace.nota0ki.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.nota0ki.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.006960… |
| 'Workspace.nota0ki.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6087788… |
| 'Workspace.nota0ki.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1456627… |
| 'Workspace.nota0ki.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.142447… |
| 'Workspace.nota0ki.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8416270… |
| 'Workspace.nota0ki.LeftLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.012059… |
| 'Workspace.nota0ki.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.012157… |
| 'Workspace.nota0ki.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7135694… |
| 'Workspace.nota0ki.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.091253… |
| 'Workspace.nota0ki.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.109258… |
| 'Workspace.nota0ki.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2490301… |
| 'Workspace.nota0ki.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2490301… |
| 'Workspace.nota0ki.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7394320… |
| 'Workspace.nota0ki.LeftUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0332268… |
| 'Workspace.nota0ki.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.023358… |
| 'Workspace.nota0ki.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6878786… |
| 'Workspace.nota0ki.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.319462… |
| 'Workspace.nota0ki.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.2430787… |
| 'Workspace.nota0ki.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2677243… |
| 'Workspace.nota0ki.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.036647… |
| 'Workspace.nota0ki.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004807… |
| 'Workspace.nota0ki.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1976655… |
| 'Workspace.nota0ki.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.040601… |
| 'Workspace.nota0ki.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.036647… |
| 'Workspace.nota0ki.RightFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7046012… |
| 'Workspace.nota0ki.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0058353… |
| 'Workspace.nota0ki.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0602194… |
| 'Workspace.nota0ki.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6097792… |
| 'Workspace.nota0ki.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.nota0ki.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.028793… |
| 'Workspace.nota0ki.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8430193… |
| 'Workspace.nota0ki.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.142826… |
| 'Workspace.nota0ki.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1035916… |
| 'Workspace.nota0ki.RightLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7119700… |
| 'Workspace.nota0ki.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0112664… |
| 'Workspace.nota0ki.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0113640… |
| 'Workspace.nota0ki.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7397439… |
| 'Workspace.nota0ki.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0930378… |
| 'Workspace.nota0ki.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1256653… |
| 'Workspace.nota0ki.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.247276… |
| 'Workspace.nota0ki.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.247276… |
| 'Workspace.nota0ki.RightUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6880207… |
| 'Workspace.nota0ki.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.035611… |
| 'Workspace.nota0ki.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0209739… |
| 'Workspace.nota0ki.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "ProportionsNormal" |
| 'Workspace.nota0ki.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.024166… |
| 'Workspace.nota0ki.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.041008… |
| 'Workspace.nota0ki.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.671878… |
| 'Workspace.nota0ki.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.334071… |
| 'Workspace.nota0ki.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.334071… |
| 'Workspace.nota0ki.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.041007… |
| 'Workspace.nota0ki.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.029604… |
| 'Workspace.nota0ki.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.2462142… |
| 'Workspace.nota0ki.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5854082… |
| 'Workspace.nota0ki.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3184137… |
| 'Workspace.nota0ki.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3184137… |
| 'Workspace.nota0ki.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.037054… |

## Numeric argument positions

- Every numeric argument position observed on any remote, with its
- observed range and how often the value moved up or down.

No numeric argument position was observed.

