# 02 - Structure

---

Instances walked: 34 of at most 8000 (budget).
Nil-parented instances included: 33.

- `?` after a property value means no default is known for that
- property, so equality with the default could not be checked.

## Instance tree

```text

```
|- Ugc (DataModel)
      Archivable = true  ?
      Capabilities = nil --[[unserialisable userdata: ]]  ?
      ClassName = "DataModel"  ?
      CreatorId = 38617013  ?
      CreatorType = Enum.CreatorType.User  ?
      DataCost = 222668  ?
      Environment = ""  ?
      GameId = 1182609799  ?
      GearGenreSetting = Enum.GearGenreSetting.AllGenres  ?
      Genre = Enum.Genre.All  ?
      IsPioneerBuild = false  ?
      IsSFFlagsLoaded = true  ?
      JobId = "46e980d4-e359-426c-94aa-4a9ff4f71389"  ?
      MatchmakingType = Enum.MatchmakingType.Default  ?
      Name = "Ugc"  *
      PioneerSource = Enum.PioneerSource.Roblox  ?
      PlaceId = 3281073759  ?
      PlaceVersion = 169  ?
      RunService = Instance.new("RunService") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to cal…  ?
      Sandboxed = false  ?
      SourceAssetId = -1  ?
      UniqueId = "00000000-0000-0000-0000-000000000000"  ?
      VIPServerId = ""  ?
      VIPServerOwnerId = 0  ?
      Workspace = Instance.new("Workspace") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to call…  ?
      archivable = true  ?
      className = "DataModel"  ?
      lighting = Instance.new("Lighting") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to call …  ?
      workspace = Instance.new("Workspace") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to call…  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- InputObject (InputObject)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "InputObject"  ?
        DataCost = 4  ?
        Delta = nil --[[unserialisable vector: 5.4957122802734375, -17.975051879882812, 0]]  ?
        KeyCode = Enum.KeyCode.None  ?
        Name = "InputObject"  ?
        Position = nil --[[unserialisable vector: 228.32162475585938, 185.1622772216797, 0]]  ?
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        UserInputState = Enum.UserInputState.Change  ?
        UserInputType = Enum.UserInputType.Touch  ?
        archivable = true  ?
        className = "InputObject"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- TrailDot (Part)  [nil parent]
        Anchored = true  *
        Archivable = true  ?
        AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
        AssemblyCenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
        AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
        AssemblyMass = 0.699999988079071  ?
        AudioCanCollide = true  ?
        BackParamA = -0.5  ?
        BackParamB = 0.5  ?
        BackSurface = Enum.SurfaceType.Smooth  ?
        BackSurfaceInput = Enum.InputType.NoInput  ?
        BottomParamA = -0.5  ?
        BottomParamB = 0.5  ?
        BottomSurface = Enum.SurfaceType.Inlet  ?
        BottomSurfaceInput = Enum.InputType.NoInput  ?
        BrickColor = BrickColor.new("Medium stone grey")  ?
        CFrame = CFrame.new(0, 0, 0)  ?
        CanCollide = false  *
        CanQuery = true  ?
        CanTouch = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        CastShadow = true  ?
        CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
        ClassName = "Part"  ?
        CollisionGroup = "Default"  ?
        CollisionGroupId = 0  ?
        Color = Color3.new(0.6392157077789307, 0.6352941393852234, 0.6470588445663452)  ?
        CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.300000012, 0.5, 1, 1, 0.300000012]]  ?
        DataCost = 24  ?
        Elasticity = 0.5  ?
        EnableFluidForces = true  ?
        ExtentsCFrame = CFrame.new(0, 0, 0)  ?
        ExtentsSize = nil --[[unserialisable vector: 1, 1, 1]]  ?
        FormFactor = Enum.FormFactor.Brick  ?
        Friction = 0.30000001192092896  ?
        FrontParamA = -0.5  ?
        FrontParamB = 0.5  ?
        FrontSurface = Enum.SurfaceType.Smooth  ?
        FrontSurfaceInput = Enum.InputType.NoInput  ?
        LeftParamA = -0.5  ?
        --[[ 42 more property/properties not shown ]]
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- InputObject (InputObject)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "InputObject"  ?
        DataCost = 4  ?
        Delta = nil --[[unserialisable vector: 0, 0, 0]]  ?
        KeyCode = Enum.KeyCode.None  ?
        Name = "InputObject"  ?
        Position = nil --[[unserialisable vector: 262.2950744628906, 94.28849792480469, 0]]  ?
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        UserInputState = Enum.UserInputState.End  ?
        UserInputType = Enum.UserInputType.Touch  ?
        archivable = true  ?
        className = "InputObject"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- Ugc (DataModel)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "DataModel"  ?
        CreatorId = 38617013  ?
        CreatorType = Enum.CreatorType.User  ?
        DataCost = 222668  ?
        Environment = ""  ?
        GameId = 1182609799  ?
        GearGenreSetting = Enum.GearGenreSetting.AllGenres  ?
        Genre = Enum.Genre.All  ?
        IsPioneerBuild = false  ?
        IsSFFlagsLoaded = true  ?
        JobId = "46e980d4-e359-426c-94aa-4a9ff4f71389"  ?
        MatchmakingType = Enum.MatchmakingType.Default  ?
        Name = "Ugc"  *
        PioneerSource = Enum.PioneerSource.Roblox  ?
        PlaceId = 3281073759  ?
        PlaceVersion = 169  ?
        RunService = Instance.new("RunService") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to cal…  ?
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        VIPServerId = ""  ?
        VIPServerOwnerId = 0  ?
        Workspace = Instance.new("Workspace") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to call…  ?
        archivable = true  ?
        className = "DataModel"  ?
        lighting = Instance.new("Lighting") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to call …  ?
        workspace = Instance.new("Workspace") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to call…  ?
  |- Instance (TextChatMessage)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ChatActionType = ""  ?
        ClassName = "TextChatMessage"  ?
        DataCost = 4  ?
        ForModeration = false  ?
        IsHiddenMessage = false  ?
        MessageId = "11007993958-{a90e029d-541b-482d-a401-7a8082ee6e3f}"  ?
        Metadata = ""  ?
        Name = "Instance"  ?
        OriginalText = ""  ?
        PrefixText = "<font color=\"#02b857\">itsmee_bea:</font>"  ?
        PrefixTextInternal = ""  ?
        PresetChatVersion = ""  ?
        PresetId = ""  ?
        RewrittenText = ""  ?
        RewrittenTranslation = ""  ?
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        Status = Enum.TextChatMessageStatus.Success  ?
        Text = "shampoo"  ?
        TextChannel = Instance.new("TextChannel") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to ca…  ?
        TextInternal = ""  ?
        TextSource = Instance.new("TextSource") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to cal…  ?
        Timestamp = DateTime.fromIsoDate("2026-10-04T14:16:45Z")  ?
        Translation = ""  ?
        TranslationInternal = ""  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        WasRewritten = false  ?
        archivable = true  ?
        className = "TextChatMessage"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- Instance (TextChatMessage)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ChatActionType = ""  ?
        ClassName = "TextChatMessage"  ?
        DataCost = 4  ?
        ForModeration = false  ?
        IsHiddenMessage = false  ?
        MessageId = "11007993958-{a90e029d-541b-482d-a401-7a8082ee6e3f}"  ?
        Metadata = ""  ?
        Name = "Instance"  ?
        OriginalText = ""  ?
        PrefixText = "itsmee_bea:"  ?
        PrefixTextInternal = ""  ?
        PresetChatVersion = ""  ?
        PresetId = ""  ?
        RewrittenText = ""  ?
        RewrittenTranslation = ""  ?
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        Status = Enum.TextChatMessageStatus.Success  ?
        Text = "shampoo"  ?
        TextChannel = Instance.new("TextChannel") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to ca…  ?
        TextInternal = ""  ?
        TextSource = Instance.new("TextSource") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to cal…  ?
        Timestamp = DateTime.fromIsoDate("2026-10-04T14:16:45Z")  ?
        Translation = ""  ?
        TranslationInternal = ""  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        WasRewritten = false  ?
        archivable = true  ?
        className = "TextChatMessage"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- EndWaypoint (Part)  [nil parent]
        Anchored = true  *
        Archivable = true  ?
        AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
        AssemblyCenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
        AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
        AssemblyMass = 5.599999904632568  ?
        AudioCanCollide = true  ?
        BackParamA = -0.5  ?
        BackParamB = 0.5  ?
        BackSurface = Enum.SurfaceType.Smooth  ?
        BackSurfaceInput = Enum.InputType.NoInput  ?
        BottomParamA = -0.5  ?
        BottomParamB = 0.5  ?
        BottomSurface = Enum.SurfaceType.Inlet  ?
        BottomSurfaceInput = Enum.InputType.NoInput  ?
        BrickColor = BrickColor.new("Medium stone grey")  ?
        CFrame = CFrame.new(0, 0, 0)  ?
        CanCollide = false  *
        CanQuery = true  ?
        CanTouch = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        CastShadow = true  ?
        CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
        ClassName = "Part"  ?
        CollisionGroup = "Default"  ?
        CollisionGroupId = 0  ?
        Color = Color3.new(0.6392157077789307, 0.6352941393852234, 0.6470588445663452)  ?
        CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.300000012, 0.5, 1, 1, 0.300000012]]  ?
        DataCost = 38  ?
        Elasticity = 0.5  ?
        EnableFluidForces = true  ?
        ExtentsCFrame = CFrame.new(0, 0, 0)  ?
        ExtentsSize = nil --[[unserialisable vector: 2, 2, 2]]  ?
        FormFactor = Enum.FormFactor.Brick  ?
        Friction = 0.30000001192092896  ?
        FrontParamA = -0.5  ?
        FrontParamB = 0.5  ?
        FrontSurface = Enum.SurfaceType.Smooth  ?
        FrontSurfaceInput = Enum.InputType.NoInput  ?
        LeftParamA = -0.5  ?
        --[[ 42 more property/properties not shown ]]
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- Animation (Animation)  [nil parent]
        AnimationContent = nil --[[unserialisable userdata: Content{SourceType=Uri, Uri=rbxassetid://2874840706}]]  ?
        AnimationId = "rbxassetid://2874840706"  ?
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "Animation"  ?
        DataCost = 5  ?
        Name = "Animation"  ?
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "Animation"  ?
  |- Instance (PlayerMouse)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "PlayerMouse"  ?
        DataCost = 4  ?
        Hit = CFrame.new(20.816953659057617, -2.800011157989502, 0.3013315200805664) * CFrame.fromEulerA…  ?
        Icon = ""  ?
        IconContent = nil --[[unserialisable userdata: Content{SourceType=None}]]  ?
        Name = "Instance"  ?
        Origin = CFrame.new(4.043153285980225, 4.989015579223633, 13.218741416931152) * CFrame.fromEulerAng…  ?
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        Target = Instance.new("Part") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to call a ni…  ?
        TargetFilter = Instance.new("Folder") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to call a …  ?
        TargetSurface = Enum.NormalId.Top  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        UnitRay = Ray.new(Vector3.new(4.043153285980225, 4.989015579223633, 13.218741416931152), Vector3.new…  ?
        ViewSizeX = 640  ?
        ViewSizeY = 244  ?
        X = 617  ?
        Y = 196  ?
        archivable = true  ?
        className = "PlayerMouse"  ?
        hit = CFrame.new(20.816953659057617, -2.800011157989502, 0.3013315200805664) * CFrame.fromEulerA…  ?
        target = Instance.new("Part") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to call a ni…  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- FailureWaypoint (Part)  [nil parent]
        Anchored = true  *
        Archivable = true  ?
        AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
        AssemblyCenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
        AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
        AssemblyMass = 5.599999904632568  ?
        AudioCanCollide = true  ?
        BackParamA = -0.5  ?
        BackParamB = 0.5  ?
        BackSurface = Enum.SurfaceType.Smooth  ?
        BackSurfaceInput = Enum.InputType.NoInput  ?
        BottomParamA = -0.5  ?
        BottomParamB = 0.5  ?
        BottomSurface = Enum.SurfaceType.Inlet  ?
        BottomSurfaceInput = Enum.InputType.NoInput  ?
        BrickColor = BrickColor.new("Medium stone grey")  ?
        CFrame = CFrame.new(0, 0, 0)  ?
        CanCollide = false  *
        CanQuery = true  ?
        CanTouch = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        CastShadow = true  ?
        CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
        ClassName = "Part"  ?
        CollisionGroup = "Default"  ?
        CollisionGroupId = 0  ?
        Color = Color3.new(0.6392157077789307, 0.6352941393852234, 0.6470588445663452)  ?
        CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.300000012, 0.5, 1, 1, 0.300000012]]  ?
        DataCost = 48  ?
        Elasticity = 0.5  ?
        EnableFluidForces = true  ?
        ExtentsCFrame = CFrame.new(0, 0, 0)  ?
        ExtentsSize = nil --[[unserialisable vector: 2, 2, 2]]  ?
        FormFactor = Enum.FormFactor.Brick  ?
        Friction = 0.30000001192092896  ?
        FrontParamA = -0.5  ?
        FrontParamB = 0.5  ?
        FrontSurface = Enum.SurfaceType.Smooth  ?
        FrontSurfaceInput = Enum.InputType.NoInput  ?
        LeftParamA = -0.5  ?
        --[[ 42 more property/properties not shown ]]
  |- Animation1 (AnimationTrack)  [nil parent]
        Animation = Instance.new("Animation") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to call…  ?
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "AnimationTrack"  ?
        DataCost = 4  ?
        IsPlaying = true  ?
        Length = 10  ?
        Looped = true  ?
        Name = "Animation1"  ?
        Priority = Enum.AnimationPriority.Core  ?
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        Speed = 1  ?
        TimePosition = 0.2166740596294403  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        WeightCurrent = 1  ?
        WeightTarget = 1  ?
        archivable = true  ?
        className = "AnimationTrack"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
  |- LocalScript (LocalScript)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "LocalScript"  ?
        DataCost = 5  ?
        Disabled = false
        Enabled = true  ?
        LinkedSource = ""  ?
        Name = "LocalScript"
        RunContext = Enum.RunContext.Legacy  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "LocalScript"  ?
  |- LocalScript (LocalScript)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "LocalScript"  ?
        DataCost = 5  ?
        Disabled = false
        Enabled = true  ?
        LinkedSource = ""  ?
        Name = "LocalScript"
        RunContext = Enum.RunContext.Legacy  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "LocalScript"  ?
  `- Event (BindableEvent)  [nil parent]
        Archivable = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "BindableEvent"  ?
        DataCost = 4  ?
        Name = "Event"  *
        Sandboxed = false  ?
        SourceAssetId = -1  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        archivable = true  ?
        className = "BindableEvent"  ?
```text

```

## Instance census

| Class | Count | Share |
| --- | :---: | :---: |
| 'Animation' | 1 | 2.9% |
| 'AnimationTrack' | 1 | 2.9% |
| 'BindableEvent' | 20 | 58.8% |
| 'DataModel' | 2 | 5.9% |
| 'InputObject' | 2 | 5.9% |
| 'LocalScript' | 2 | 5.9% |
| 'Part' | 3 | 8.8% |
| 'PlayerMouse' | 1 | 2.9% |
| 'TextChatMessage' | 2 | 5.9% |

