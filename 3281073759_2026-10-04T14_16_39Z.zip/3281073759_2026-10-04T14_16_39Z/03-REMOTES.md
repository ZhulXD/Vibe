# 03 - Remotes

---

| Measure | Count |
| --- | --- |
| Remotes discovered | 0 |
| With observed outgoing traffic | 0 |
| With observed incoming traffic | 0 |
| With both directions | 0 |
| Never observed in either direction | 0 |
| Outgoing calls recorded | 0 |
| Incoming calls recorded | 0 |
| Of those, produced by the AIDump sweep | 0 |

No remote instances were discovered.
