# 07 - Coverage and limitations

---

- This file lists what the run did NOT observe and what it could
- not observe. Anything absent from the other documents and
- absent from this file should be treated as genuinely unknown.

## Remotes with no observed traffic (0)

Every discovered remote was observed in at least one direction.

## Interactable instances

- These exist in the game and respond to player input. A reader
- of this dump cannot know whether they were exercised.

| Class | Count |
| --- | :---: |
| 'ProximityPrompt' | 0 |
| 'ClickDetector' | 0 |
| 'TouchTransmitter' | 0 |

## Sweep activity (0 action(s) attempted)

No sweep action was attempted.

## Capture layers not available

| Capability | Consequence |
| --- | --- |
| 'getcallingline' | call sites are attributed to a script but not to a line number; 05-SCRIPTS.md records the script only |
| 'ReflectionMetadata.xml' | not present on the filesystem; property coverage fell back to probing |
| 'parallel Luau actors' | this build observes only the main client; actor instances and their remotes are not instrumented regardless of executor support |

## Structural limits

| Limit | Configured | This run | State |
| --- | :---: | :---: | --- |
| Instance walk budget | 8000 | 0 | within budget |
| Depth budget | 40 | 40 | within budget |
| Properties per instance | 40 | 40 | cap applied |
| Total property emissions | 60000 | 60000 | cap applied |
| raw/instances.json instances | 20000 | 20000 | cap applied |
| raw/instances.json with properties | 4000 | 4000 | cap applied |

- Property reads failed 242 time(s) against a budget of 300.

- Most frequent unreadable properties: CachedRemoteSource x2, CachedRemoteSourceLoadState x2, HasAssociatedDrafts x2, IsDifferentFromFileSystem x2, MaterialVariantSerialized x3, NetworkIsSleeping x3, NetworkOwnerV3 x3, NetworkOwnershipRule x3, Origin x3, PhysicsRepRootRef x3, Pivot Offset x3, PredictionMode x39.
- These are properties this client is not permitted to
- observe. Each one raises an engine message when read,
- which is why reading stops once the budget is spent.

- Attribute names created after watching began and never changed are only
- discovered at the next export, so a short run can miss them.

## Scripts without readable source (0)

Every client-side script produced some output.

## Lines withheld by the fact-discipline linter (2)

| Withheld line | Trigger terms |
| --- | --- |
| This remote is probably the currency endpoint. | probably |
| 02-STRUCTURE.md - the full scene, last, because it is large. | because |

