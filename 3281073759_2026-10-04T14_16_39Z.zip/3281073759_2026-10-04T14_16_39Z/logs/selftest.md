# AIDump self-test

Generated: 2026-10-04T14:16:40Z

**10 passed, 4 failed, 14 total**

| Check | Result | Detail |
| --- | --- | --- |
| ring bounds head and tail | pass | true |
| string quoting survives control characters | pass | true |
| value serialiser emits compilable Luau | pass | true |
| cycle detection terminates | pass | true |
| packed argument arity is preserved | pass | true |
| markdown cells escape table syntax | pass | true |
| fact linter rejects an assertion | pass | true |
| fact linter accepts game vocabulary in values | pass | true |
| instance detection works on this executor | FAIL | uMBVhFUYKHYjdUhmHNSnviDIY:8532: attempt to call a nil value |
| service paths resolve | FAIL | uMBVhFUYKHYjdUhmHNSnviDIY:8545: workspace path wrong: Instance.new("Workspace") --[[unresolvable: uMBVhFUYKHYjdUhmHNSnviDIY:751: attempt to call a nil value]] |
| json output is valid | FAIL | uMBVhFUYKHYjdUhmHNSnviDIY:8559: JSONDecode rejected the output: uMBVhFUYKHYjdUhmHNSnviDIY:8557: attempt to call a nil value |
| filesystem write and read back | pass | true |
| bytecode parser handles a live script | FAIL | FAILED: getscriptbytecode returned nil for LocalScript; no bytecode is reachable for this script |
| number formatting round trips | pass | true |

Failing checks indicate a defect in this script or an executor
capability that differs from the assumption made. Both are recorded
rather than hidden.
