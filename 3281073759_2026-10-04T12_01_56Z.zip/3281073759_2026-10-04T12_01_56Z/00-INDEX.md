# AIDump documentation set

---

## What this is

- Game: Ugc (PlaceId 3281073759)
- JobId: d4dbb45b-ec02-49e6-b99e-4021c9b0afb1
- Executor: Delta 1.1.740.931
- Attached: 2026-10-04T12:01:56Z
- Exports written: 3, last at 2026-10-04T12:03:41Z

## How to read this set

- Every statement in these files is a measurement taken during
- this session. Nothing here interprets, explains or guesses.
- Counts marked exact remain exact even where sample lists are
- truncated; truncation is always stated next to the list.
- Absence from a document is not evidence of absence in the game.
- 07-COVERAGE.md lists what was not observed. Read it before
- concluding that something does not exist.

## Coverage totals

| Measure | Count |
| --- | --- |
| Remotes discovered | 26 |
| Remotes with observed traffic | 0 |
| Remotes never observed | 26 |
| Outgoing calls recorded | 0 |
| Incoming calls recorded | 0 |
| Scripts found | 132 |
| Scripts readable by the client | 128 |
| Attributes tracked | 14 |
| Value objects tracked | 958 |
| State transitions recorded | 31 |

## Recommended reading order

- 01-ENVIRONMENT.md - what this client can see, and what it cannot.
- 07-COVERAGE.md - the limits of this run. Read first.
- 03-REMOTES.md then the 04-REMOTE-*.md files - the protocol.
- 05-SCRIPTS.md - which code sends and receives each call.
- 06-STATES.md - the numbers that moved.
- --[[ AIDump: line withheld as unverified assertion (because) ]]

## File manifest

| File | Contents | Size |
| --- | --- | :---: |
| '01-ENVIRONMENT.md' | Place metadata, executor capability probe, reflection source | 2506 bytes |
| '02-STRUCTURE.md' | Instance tree with properties and attributes | 387255 bytes |
| '03-REMOTES.md' | One row per remote with argument schema and traffic counts | 3239 bytes |
| '05-SCRIPTS.md' | Script inventory, decompilation method, call-site cross-reference | 28318 bytes |
| '06-STATES.md' | Attributes, value objects and numeric argument positions | 137156 bytes |
| '07-COVERAGE.md' | What was not observed and what could not be observed | 5496 bytes |
| 'raw/coverage.json' | Machine-readable limits and capability report | 4470 bytes |
| 'raw/instances.json' | Full instance tree with all readable properties | 4885921 bytes |
| 'raw/remotes.json' | Full remote aggregates, samples and timelines | 15101 bytes |
| 'raw/scripts.json' | Script inventory with decompilation metadata | 44519 bytes |
| 'raw/states.json' | Attribute and value-object observation records | 275020 bytes |
| 'scripts/LocalScript.lua' | Generated data | 206 bytes |
| 'scripts/LocalScript.lua' | Generated data | 206 bytes |
| 'scripts/LocalScript.meta.json' | Generated data | 159 bytes |
| 'scripts/LocalScript.meta.json' | Generated data | 159 bytes |
| 'scripts/Players_SeoulKD_PlayerGui_BobuxDonationGui_Donation Script.lua' | Generated data | 245 bytes |
| 'scripts/Players_SeoulKD_PlayerGui_BobuxDonationGui_Donation Script.meta.json' | Generated data | 205 bytes |
| 'scripts/Players_SeoulKD_PlayerGui_GamepassGui_Gamepass Script.lua' | Generated data | 240 bytes |
| 'scripts/Players_SeoulKD_PlayerGui_GamepassGui_Gamepass Script.meta.json' | Generated data | 200 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_LocalScript.lua' | Generated data | 228 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_LocalScript.meta.json' | Generated data | 188 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule.lua' | Generated data | 193 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule.meta.json' | Generated data | 190 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule.lua' | Generated data | 206 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule.meta.json' | Generated data | 203 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_BaseCamera.lua' | Generated data | 217 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_BaseCamera.meta.json' | Generated data | 214 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_BaseOcclusion.lua' | Generated data | 220 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_BaseOcclusion.meta.json' | Generated data | 217 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraInput.lua' | Generated data | 218 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraInput.meta.json' | Generated data | 215 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraToggleStateController.lua' | Generated data | 234 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraToggleStateController.meta.json' | Generated data | 231 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraUI.lua' | Generated data | 215 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraUI.meta.json' | Generated data | 212 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraUtils.lua' | Generated data | 218 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraUtils.meta.json' | Generated data | 215 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_ClassicCamera.lua' | Generated data | 220 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_ClassicCamera.meta.json' | Generated data | 217 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_Invisicam.lua' | Generated data | 216 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_Invisicam.meta.json' | Generated data | 213 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_LegacyCamera.lua' | Generated data | 219 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_LegacyCamera.meta.json' | Generated data | 216 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_MouseLockController.lua' | Generated data | 226 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_MouseLockController.meta.json' | Generated data | 223 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_OrbitalCamera.lua' | Generated data | 220 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_OrbitalCamera.meta.json' | Generated data | 217 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_Poppercam.lua' | Generated data | 216 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_Poppercam.meta.json' | Generated data | 213 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_TransparencyController.lua' | Generated data | 229 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_TransparencyController.meta.json' | Generated data | 226 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRBaseCamera.lua' | Generated data | 219 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRBaseCamera.meta.json' | Generated data | 216 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRCamera.lua' | Generated data | 215 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRCamera.meta.json' | Generated data | 212 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector.lua' | Generated data | 231 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector.meta.json' | Generated data | 228 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector_spec.lua' | Generated data | 236 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector_spec.meta.json' | Generated data | 233 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRVehicleCamera.lua' | Generated data | 222 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRVehicleCamera.meta.json' | Generated data | 219 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VehicleCamera.lua' | Generated data | 220 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VehicleCamera.meta.json' | Generated data | 217 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraConfig.lua' | Generated data | 240 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraConfig.meta.json' | Generated data | 237 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraCore.lua' | Generated data | 238 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraCore.meta.json' | Generated data | 235 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_ZoomController.lua' | Generated data | 221 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_ZoomController.meta.json' | Generated data | 218 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_ZoomController_Popper.lua' | Generated data | 228 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_ZoomController_Popper.meta.json' | Generated data | 225 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_CameraWrapper.lua' | Generated data | 219 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_CameraWrapper.meta.json' | Generated data | 216 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_CameraWrapper_spec.lua' | Generated data | 224 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_CameraWrapper_spec.meta.json' | Generated data | 221 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_CharacterUtil.lua' | Generated data | 219 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_CharacterUtil.meta.json' | Generated data | 216 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_ConnectionUtil.lua' | Generated data | 220 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_ConnectionUtil.meta.json' | Generated data | 217 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_ConnectionUtil_spec.lua' | Generated data | 225 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_ConnectionUtil_spec.meta.json' | Generated data | 222 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_FlagUtil.lua' | Generated data | 214 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_FlagUtil.meta.json' | Generated data | 211 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule.lua' | Generated data | 207 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule.meta.json' | Generated data | 204 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_AvatarAbilitiesInterface.lua' | Generated data | 232 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_AvatarAbilitiesInterface.meta.json' | Generated data | 229 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_BaseCharacterController.lua' | Generated data | 231 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_BaseCharacterController.meta.json' | Generated data | 228 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_ClickToMoveController.lua' | Generated data | 229 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_ClickToMoveController.meta.json' | Generated data | 226 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_ClickToMoveDisplay.lua' | Generated data | 226 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_ClickToMoveDisplay.meta.json' | Generated data | 223 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_DynamicThumbstick.lua' | Generated data | 225 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_DynamicThumbstick.meta.json' | Generated data | 222 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_Gamepad.lua' | Generated data | 215 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_Gamepad.meta.json' | Generated data | 212 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_Keyboard.lua' | Generated data | 216 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_Keyboard.meta.json' | Generated data | 213 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_PathDisplay.lua' | Generated data | 219 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_PathDisplay.meta.json' | Generated data | 216 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_TouchJump.lua' | Generated data | 217 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_TouchJump.meta.json' | Generated data | 214 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_TouchThumbstick.lua' | Generated data | 223 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_TouchThumbstick.meta.json' | Generated data | 220 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_VRNavigation.lua' | Generated data | 220 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_VRNavigation.meta.json' | Generated data | 217 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_VehicleController.lua' | Generated data | 225 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_VehicleController.meta.json' | Generated data | 222 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerScriptsLoader.lua' | Generated data | 236 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerScriptsLoader.meta.json' | Generated data | 196 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_RbxCharacterSounds.lua' | Generated data | 235 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_RbxCharacterSounds.meta.json' | Generated data | 195 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_RbxCharacterSounds_AtomicBinding.lua' | Generated data | 213 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_RbxCharacterSounds_AtomicBinding.meta.json' | Generated data | 210 bytes |
| 'scripts/ReplicatedStorage_DrawCamera.lua' | Generated data | 179 bytes |
| 'scripts/ReplicatedStorage_DrawCamera.meta.json' | Generated data | 176 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_CheckboxLabel.lua' | Generated data | 197 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_CheckboxLabel.meta.json' | Generated data | 194 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_RadialMenu_CONSTANTS.lua' | Generated data | 213 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_RadialMenu_CONSTANTS.meta.json' | Generated data | 210 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_RadialMenu_CreateRadial.lua' | Generated data | 216 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_RadialMenu_CreateRadial.meta.json' | Generated data | 213 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_RadialMenu_Triangle.lua' | Generated data | 212 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_RadialMenu_Triangle.meta.json' | Generated data | 209 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Integer.lua' | Generated data | 209 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Integer.meta.json' | Generated data | 206 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Number.lua' | Generated data | 208 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Number.meta.json' | Generated data | 205 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_String.lua' | Generated data | 208 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_String.meta.json' | Generated data | 205 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Vector2.lua' | Generated data | 209 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Vector2.meta.json' | Generated data | 206 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Vector3.lua' | Generated data | 209 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Vector3.meta.json' | Generated data | 206 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Dragger.lua' | Generated data | 191 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Dragger.meta.json' | Generated data | 188 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Dropdown.lua' | Generated data | 192 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Dropdown.meta.json' | Generated data | 189 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_RadialMenu.lua' | Generated data | 194 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_RadialMenu.meta.json' | Generated data | 191 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_RadioButtonGroup.lua' | Generated data | 200 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_RadioButtonGroup.meta.json' | Generated data | 197 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_RadioButtonLabel.lua' | Generated data | 200 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_RadioButtonLabel.meta.json' | Generated data | 197 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Slider.lua' | Generated data | 190 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Slider.meta.json' | Generated data | 187 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_TextMask.lua' | Generated data | 192 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_TextMask.meta.json' | Generated data | 189 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Constructors_List.lua' | Generated data | 193 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Constructors_List.meta.json' | Generated data | 190 bytes |
| 'scripts/ReplicatedStorage_GuiLib_LazyLoader.lua' | Generated data | 186 bytes |
| 'scripts/ReplicatedStorage_GuiLib_LazyLoader.meta.json' | Generated data | 183 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Utilities_Maid.lua' | Generated data | 190 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Utilities_Maid.meta.json' | Generated data | 187 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Utilities_Spring.lua' | Generated data | 192 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Utilities_Spring.meta.json' | Generated data | 189 bytes |
| 'scripts/ReplicatedStorage_getPublicData.lua' | Generated data | 182 bytes |
| 'scripts/ReplicatedStorage_getPublicData.meta.json' | Generated data | 179 bytes |
| 'scripts/StarterGui_BobuxDonationGui_Donation Script.lua' | Generated data | 230 bytes |
| 'scripts/StarterGui_BobuxDonationGui_Donation Script.meta.json' | Generated data | 190 bytes |
| 'scripts/StarterGui_GamepassGui_Gamepass Script.lua' | Generated data | 225 bytes |
| 'scripts/StarterGui_GamepassGui_Gamepass Script.meta.json' | Generated data | 185 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_LocalScript.lua' | Generated data | 233 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_LocalScript.meta.json' | Generated data | 193 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule.lua' | Generated data | 198 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule.meta.json' | Generated data | 195 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule.lua' | Generated data | 211 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule.meta.json' | Generated data | 208 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_BaseCamera.lua' | Generated data | 222 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_BaseCamera.meta.json' | Generated data | 219 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_BaseOcclusion.lua' | Generated data | 225 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_BaseOcclusion.meta.json' | Generated data | 222 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraInput.lua' | Generated data | 223 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraInput.meta.json' | Generated data | 220 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraToggleStateController.lua' | Generated data | 239 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraToggleStateController.meta.json' | Generated data | 236 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraUI.lua' | Generated data | 220 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraUI.meta.json' | Generated data | 217 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraUtils.lua' | Generated data | 223 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraUtils.meta.json' | Generated data | 220 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_ClassicCamera.lua' | Generated data | 225 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_ClassicCamera.meta.json' | Generated data | 222 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_Invisicam.lua' | Generated data | 221 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_Invisicam.meta.json' | Generated data | 218 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_LegacyCamera.lua' | Generated data | 224 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_LegacyCamera.meta.json' | Generated data | 221 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_MouseLockController.lua' | Generated data | 231 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_MouseLockController.meta.json' | Generated data | 228 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_OrbitalCamera.lua' | Generated data | 225 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_OrbitalCamera.meta.json' | Generated data | 222 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_Poppercam.lua' | Generated data | 221 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_Poppercam.meta.json' | Generated data | 218 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_TransparencyController.lua' | Generated data | 234 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_TransparencyController.meta.json' | Generated data | 231 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRBaseCamera.lua' | Generated data | 224 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRBaseCamera.meta.json' | Generated data | 221 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRCamera.lua' | Generated data | 220 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRCamera.meta.json' | Generated data | 217 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector.lua' | Generated data | 236 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector.meta.json' | Generated data | 233 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector_spec.lua' | Generated data | 241 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector_spec.meta.json' | Generated data | 238 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRVehicleCamera.lua' | Generated data | 227 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRVehicleCamera.meta.json' | Generated data | 224 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VehicleCamera.lua' | Generated data | 225 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VehicleCamera.meta.json' | Generated data | 222 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraConfig.lua' | Generated data | 245 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraConfig.meta.json' | Generated data | 242 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraCore.lua' | Generated data | 243 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraCore.meta.json' | Generated data | 240 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_ZoomController.lua' | Generated data | 226 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_ZoomController.meta.json' | Generated data | 223 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_ZoomController_Popper.lua' | Generated data | 233 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_ZoomController_Popper.meta.json' | Generated data | 230 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_CameraWrapper.lua' | Generated data | 224 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_CameraWrapper.meta.json' | Generated data | 221 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_CameraWrapper_spec.lua' | Generated data | 229 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_CameraWrapper_spec.meta.json' | Generated data | 226 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_CharacterUtil.lua' | Generated data | 224 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_CharacterUtil.meta.json' | Generated data | 221 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_ConnectionUtil.lua' | Generated data | 225 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_ConnectionUtil.meta.json' | Generated data | 222 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_ConnectionUtil_spec.lua' | Generated data | 230 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_ConnectionUtil_spec.meta.json' | Generated data | 227 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_FlagUtil.lua' | Generated data | 219 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_FlagUtil.meta.json' | Generated data | 216 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule.lua' | Generated data | 212 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule.meta.json' | Generated data | 209 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_AvatarAbilitiesInterface.lua' | Generated data | 237 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_AvatarAbilitiesInterface.meta.json' | Generated data | 234 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_BaseCharacterController.lua' | Generated data | 236 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_BaseCharacterController.meta.json' | Generated data | 233 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_ClickToMoveController.lua' | Generated data | 234 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_ClickToMoveController.meta.json' | Generated data | 231 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_ClickToMoveDisplay.lua' | Generated data | 231 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_ClickToMoveDisplay.meta.json' | Generated data | 228 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_DynamicThumbstick.lua' | Generated data | 230 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_DynamicThumbstick.meta.json' | Generated data | 227 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_Gamepad.lua' | Generated data | 220 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_Gamepad.meta.json' | Generated data | 217 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_Keyboard.lua' | Generated data | 221 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_Keyboard.meta.json' | Generated data | 218 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_PathDisplay.lua' | Generated data | 224 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_PathDisplay.meta.json' | Generated data | 221 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_TouchJump.lua' | Generated data | 222 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_TouchJump.meta.json' | Generated data | 219 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_TouchThumbstick.lua' | Generated data | 228 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_TouchThumbstick.meta.json' | Generated data | 225 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_VRNavigation.lua' | Generated data | 225 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_VRNavigation.meta.json' | Generated data | 222 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_VehicleController.lua' | Generated data | 230 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_VehicleController.meta.json' | Generated data | 227 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerScriptsLoader.lua' | Generated data | 241 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerScriptsLoader.meta.json' | Generated data | 201 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_RbxCharacterSounds.lua' | Generated data | 240 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_RbxCharacterSounds.meta.json' | Generated data | 200 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_RbxCharacterSounds_AtomicBinding.lua' | Generated data | 218 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_RbxCharacterSounds_AtomicBinding.meta.json' | Generated data | 215 bytes |
| 'scripts/Workspace_I_lovecelebrations_Animate.lua' | Generated data | 223 bytes |
| 'scripts/Workspace_I_lovecelebrations_Animate.meta.json' | Generated data | 183 bytes |
| 'scripts/Workspace_Itss_Mila_Animate.lua' | Generated data | 214 bytes |
| 'scripts/Workspace_Itss_Mila_Animate.meta.json' | Generated data | 174 bytes |
| 'scripts/Workspace_Pro Server Portal_LocalScript.lua' | Generated data | 221 bytes |
| 'scripts/Workspace_Pro Server Portal_LocalScript.meta.json' | Generated data | 181 bytes |
| 'scripts/Workspace_SeoulKD_Animate.lua' | Generated data | 212 bytes |
| 'scripts/Workspace_SeoulKD_Animate.meta.json' | Generated data | 172 bytes |

