# 07 - Coverage and limitations

---

- This file lists what the run did NOT observe and what it could
- not observe. Anything absent from the other documents and
- absent from this file should be treated as genuinely unknown.

## Remotes with no observed traffic (26)

| Class | Path | Parent |
| --- | --- | --- |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.choosingWords' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.clear' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.draw' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.drawTools' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.erase' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.gameEnd' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.gameStart' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.guess' | ReplicatedStorage.Remotes |
| 'RemoteFunction' | 'ReplicatedStorage.Remotes.hash' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.isChoosing' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.sendGuess' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.systemChat' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.turn' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.undoRedo' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.voteKick' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.warnPlayer' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.wayPoint' | ReplicatedStorage.Remotes |
| 'RemoteEvent' | 'ReplicatedStorage.Remotes.word' | ReplicatedStorage.Remotes |
| 'BindableFunction' | 'Workspace.I_lovecelebrations.Animate.PlayEmote' | Workspace.I_lovecelebrations.Animate |
| 'BindableFunction' | 'Workspace.Itss_Mila.Animate.PlayEmote' | Workspace.Itss_Mila.Animate |
| 'RemoteEvent' | 'Workspace.Pro Server Portal.TeleportRemote' | Workspace.Pro Server Portal |
| 'BindableFunction' | 'Workspace.SSecretEyes.Animate.PlayEmote' | Workspace.SSecretEyes.Animate |
| 'BindableFunction' | 'Workspace.SeoulKD.Animate.PlayEmote' | Workspace.SeoulKD.Animate |
| 'BindableFunction' | 'Workspace.T5DD01.Animate.PlayEmote' | Workspace.T5DD01.Animate |
| 'BindableFunction' | 'Workspace.crucifypast.Animate.PlayEmote' | Workspace.crucifypast.Animate |
| 'BindableFunction' | 'Workspace.trenjay123.Animate.PlayEmote' | Workspace.trenjay123.Animate |

## Interactable instances

- These exist in the game and respond to player input. A reader
- of this dump cannot know whether they were exercised.

| Class | Count |
| --- | :---: |
| 'ProximityPrompt' | 0 |
| 'ClickDetector' | 0 |
| 'TouchTransmitter' | 1 |

## Sweep activity (1 action(s) attempted)

| Action | Subject | Outcome | Reason it was permitted |
| --- | --- | --- | --- |
| move | 'nil --[[unserialisable vector: 57.821151…' | issued | waypoint sampled from game geometry |


## Capture layers not available

| Capability | Consequence |
| --- | --- |
| 'getcallingline' | call sites are attributed to a script but not to a line number; 05-SCRIPTS.md records the script only |
| 'ReflectionMetadata.xml' | not present on the filesystem; property coverage fell back to probing |
| 'parallel Luau actors' | this build observes only the main client; actor instances and their remotes are not instrumented regardless of executor support |

## Structural limits

| Limit | Configured | This run | State |
| --- | :---: | :---: | --- |
| Instance walk budget | 8000 | 0 | within budget |
| Depth budget | 40 | 40 | within budget |
| Properties per instance | 40 | 40 | cap applied |
| Total property emissions | 60000 | 60000 | cap applied |
| raw/instances.json instances | 20000 | 20000 | cap applied |
| raw/instances.json with properties | 4000 | 4000 | cap applied |

- 02-STRUCTURE.md was truncated at the instance budget budget of 8000.

- Property reads failed 300 time(s) against a budget of 300; reading was then disabled for the rest of the run.

- Most frequent unreadable properties: AeroMeshData x6, AlternateMeshHash x6, Attributes x10, AttributesReplicate x10, AvatarUnificationMode x1, CollisionGroupData x1, CollisionGroupReplicate x6, DataModelPlaceVersion x1, DefinesCapabilities x10, DraggingV1 x6, EnableSLIMAvatars x1, ExpandedTerrain x1.
- These are properties this client is not permitted to
- observe. Each one raises an engine message when read,
- which is why reading stops once the budget is spent.

- Instances listed after that point carry name, class,
- children and attributes, but no property values.

- raw/instances.json lists every instance up to the cap, but properties were read for only the first 4000. The remaining 16000 carry name, class, children and attributes, but no property values.

- Attribute names created after watching began and never changed are only
- discovered at the next export, so a short run can miss them.

## Scripts without usable source (0)

Every client-side script produced some output.

## Lines withheld by the fact-discipline linter (3)

| Withheld line | Trigger terms |
| --- | --- |
| This remote is probably the currency endpoint. | probably |
| 02-STRUCTURE.md - the full scene, last, because it is large. | because |
| 02-STRUCTURE.md - the full scene, last, because it is large. | because |

