# 03 - Remotes

---

| Measure | Count |
| --- | --- |
| Remotes discovered | 26 |
| With observed outgoing traffic | 0 |
| With observed incoming traffic | 0 |
| With both directions | 0 |
| Never observed in either direction | 26 |
| Outgoing calls recorded | 0 |
| Incoming calls recorded | 0 |
| Of those, produced by the AIDump sweep | 0 |

## All discovered remotes

| Class | Name | Parent | Direction | Out | In | Shapes | Argument schema | Callers | Listeners | Detail file |
| --- | --- | --- | :---: | :---: | :---: | :---: | --- | :---: | :---: | --- |
| 'BindableFunction' | 'PlayEmote' | Workspace.I_lovecelebrations.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'BindableFunction' | 'PlayEmote' | Workspace.Itss_Mila.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'BindableFunction' | 'PlayEmote' | Workspace.SSecretEyes.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'BindableFunction' | 'PlayEmote' | Workspace.SeoulKD.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'BindableFunction' | 'PlayEmote' | Workspace.T5DD01.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'BindableFunction' | 'PlayEmote' | Workspace.crucifypast.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'BindableFunction' | 'PlayEmote' | Workspace.trenjay123.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'choosingWords' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'clear' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'draw' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'drawTools' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'erase' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'gameEnd' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'gameStart' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'guess' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'isChoosing' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'sendGuess' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'systemChat' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'turn' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'undoRedo' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'voteKick' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'warnPlayer' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'wayPoint' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'word' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'TeleportRemote' | Workspace.Pro Server Portal | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteFunction' | 'hash' | ReplicatedStorage.Remotes | — | 0 | 0 | 0 |  | 0 | 0 | — |

- `Direction` is `out`, `in` or `out+in`.
- `Shapes` counts distinct argument type signatures observed.
- `Callers` counts distinct (script, method, line) triples.

