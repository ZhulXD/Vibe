# 02 - Structure

---

Instances walked: 8000 of at most 8000 (budget).
Nil-parented instances included: 0.

- `?` after a property value means no default is known for that
- property, so equality with the default could not be checked.

## Instance tree

```text

```
`- Ugc (DataModel)
      Archivable = true  ?
      Capabilities = nil --[[unserialisable userdata: ]]  ?
      ClassName = "DataModel"  ?
      CreatorId = 38617013  ?
      CreatorType = Enum.CreatorType.User  ?
      DataCost = 209338  ?
      Environment = ""  ?
      GameId = 1182609799  ?
      GearGenreSetting = Enum.GearGenreSetting.AllGenres  ?
      Genre = Enum.Genre.All  ?
      IsPioneerBuild = false  ?
      IsSFFlagsLoaded = true  ?
      JobId = "d4dbb45b-ec02-49e6-b99e-4021c9b0afb1"  ?
      MatchmakingType = Enum.MatchmakingType.Default  ?
      Name = "Ugc"  *
      PioneerSource = Enum.PioneerSource.Roblox  ?
      PlaceId = 3281073759  ?
      PlaceVersion = 169  ?
      RunService = :GetService("Run Service")game  ?
      Sandboxed = false  ?
      SourceAssetId = -1  ?
      UniqueId = "00000000-0000-0000-0000-000000000000"  ?
      VIPServerId = ""  ?
      VIPServerOwnerId = 0  ?
      Workspace = workspace  ?
      archivable = true  ?
      className = "DataModel"  ?
      lighting = :GetService("Lighting")game  ?
      workspace = workspace  ?
  |- Workspace (Workspace)
        AirDensity = 0.0012000000569969416  ?
        AirTurbulenceIntensity = 0  ?
        AllowThirdPartySales = false  ?
        Archivable = true  ?
        AuthorityMode = Enum.AuthorityMode.Automatic  ?
        AutoSimulate = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "Workspace"  ?
        ClientAnimatorThrottling = Enum.ClientAnimatorThrottlingMode.Default  ?
        DataCost = 52526  ?
        DistributedGameTime = 23.225001278333366  ?
        FallHeightEnabled = true  ?
        FallenPartsDestroyHeight = -500  ?
        FilteringEnabled = true  ?
        GlobalWind = nil --[[unserialisable vector: 3, 0, 6]]  ?
        Gravity = 196.1999969482422  *
        GravityDirection = nil --[[unserialisable vector: 0, -1, 0]]  ?
        InsertPoint = nil --[[unserialisable vector: 0, 0, 0]]  ?
        InterpolationThrottling = Enum.InterpolationThrottlingMode.Default  ?
        LevelOfDetail = Enum.ModelLevelOfDetail.Automatic  ?
        LuauTypeCheckMode = Enum.LuauTypeCheckMode.Default  ?
        ModelStreamingMode = Enum.ModelStreamingMode.Default  ?
        Name = "Workspace"
        PhysicsStepTime = 0.00038208600017242134  ?
        Retargeting = Enum.AnimatorRetargetingMode.Default  ?
        Sandboxed = false  ?
        SimulationRate = 1  ?
        SourceAssetId = -1  ?
        StreamingAdaptiveRadius = false  ?
        StreamingEnabled = false  ?
        Terrain = .Terrainworkspace  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        Wind = 0  ?
        WindDirection = nil --[[unserialisable vector: 0, 0, 0]]  ?
        WorldPivot = CFrame.new(0, 0, 0)  ?
        archivable = true  ?
        className = "Workspace"  ?
    |- Camera (Camera)
          Archivable = true  ?
          CFrame = CFrame.new(20.737934112548828, 6.94360876083374, -26.353736877441406) * CFrame.fromEulerAn…  ?
          CameraSubject = .SeoulKD.Humanoidworkspace  ?
          CameraType = Enum.CameraType.Custom  ?
          Capabilities = nil --[[unserialisable userdata: ]]  ?
          ClassName = "Camera"  ?
          CoordinateFrame = CFrame.new(20.737934112548828, 6.94360876083374, -26.353736877441406) * CFrame.fromEulerAn…  ?
          DataCost = 10  ?
          DiagonalFieldOfView = 127.76887512207031  ?
          FieldOfView = 70
          FieldOfViewMode = Enum.FieldOfViewMode.Vertical  ?
          Focus = CFrame.new(15.555378913879395, 6.192893981933594, -37.70396041870117)  ?
          HeadLocked = true  ?
          HeadScale = 1  ?
          MaxAxisFieldOfView = 102.44786071777344  ?
          Name = "Camera"
          NearPlaneZ = -0.10000000149011612  ?
          Sandboxed = false  ?
          SourceAssetId = -1  ?
          UniqueId = "00000000-0000-0000-0000-000000000000"  ?
          VRTiltAndRollEnabled = false  ?
          ViewportSize = Vector2.new(640, 360)  ?
          archivable = true  ?
          className = "Camera"  ?
          focus = CFrame.new(15.555378913879395, 6.192893981933594, -37.70396041870117)  ?
    |- Stand (Model)
      |- Platform (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: -0.0726022720336914, -3.70001220703125, -100.76624298095703…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Stand:GetChildren()[1] --[[Platform is 1 of 6]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Cloudy grey")  ?
            CFrame = CFrame.new(-0.0726022720336914, -3.70001220703125, -100.76624298095703) * CFrame.fromEuler…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Hull  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.6941176652908325, 0.615686297416687, 0.5882353186607361)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(-0.0726022720336914, -3.70001220703125, -100.76624298095703) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 6, 4, 7]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Platform (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: -0.0726022720336914, -1.70001220703125, -100.76624298095703…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Stand:GetChildren()[2] --[[Platform is 2 of 6]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark grey")  ?
            CFrame = CFrame.new(-0.0726022720336914, -1.70001220703125, -100.76624298095703) * CFrame.fromEuler…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Hull  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(-0.0726022720336914, -1.70001220703125, -100.76624298095703) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 6.5, 1, 7.5]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Platform (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: -0.0726022720336914, -18.70001220703125, -100.7662429809570…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Stand:GetChildren()[3] --[[Platform is 3 of 6]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark grey")  ?
            CFrame = CFrame.new(-0.0726022720336914, -18.70001220703125, -100.76624298095703) * CFrame.fromEule…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Hull  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(-0.0726022720336914, -18.70001220703125, -100.76624298095703) * CFrame.fromEule…  ?
            ExtentsSize = nil --[[unserialisable vector: 6.5, 29, 7.5]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Platform (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: -0.0726022720336914, -26.20001220703125, -100.7662429809570…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Stand:GetChildren()[4] --[[Platform is 4 of 6]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Pine Cone")  ?
            CFrame = CFrame.new(-0.0726022720336914, -26.20001220703125, -100.76624298095703) * CFrame.fromEule…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Hull  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(-0.0726022720336914, -26.20001220703125, -100.76624298095703) * CFrame.fromEule…  ?
            ExtentsSize = nil --[[unserialisable vector: 32.5, 10, 37.5]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Platform (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: -0.0726022720336914, -21.20001220703125, -100.7662429809570…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Stand:GetChildren()[5] --[[Platform is 5 of 6]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark grey")  ?
            CFrame = CFrame.new(-0.0726022720336914, -21.20001220703125, -100.76624298095703) * CFrame.fromEule…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Hull  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(-0.0726022720336914, -21.20001220703125, -100.76624298095703) * CFrame.fromEule…  ?
            ExtentsSize = nil --[[unserialisable vector: 18.5, 10, 21.499998092651367]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      `- Platform (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: -0.0726022720336914, -15.20001220703125, -100.7662429809570…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Stand:GetChildren()[6] --[[Platform is 6 of 6]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark grey")  ?
            CFrame = CFrame.new(-0.0726022720336914, -15.20001220703125, -100.76624298095703) * CFrame.fromEule…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Hull  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(-0.0726022720336914, -15.20001220703125, -100.76624298095703) * CFrame.fromEule…  ?
            ExtentsSize = nil --[[unserialisable vector: 8.5, 12, 9.499998092651367]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
    |- Mountains (Model)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- Hexagon (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      |- HexagonGrass (MeshPart)
      `- HexagonGrass (MeshPart)
    |- TopPoints (Model)
      |- TitleOrder (IntValue)
      |- AllowTitles (BoolValue)
      |- TitleColor (Color3Value)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- ScoreBlock (Part)
        `- SurfaceGui (SurfaceGui)
          |- Category (Frame)
            |- AllTime (TextButton)
            |- Selection (Frame)
              `- UICorner (UICorner)
            `- UICorner (UICorner)
          |- DataLabel (TextLabel)
          `- LeaderboardAllTime (ScrollingFrame)
            |- UIListLayout (UIListLayout)
            |- Top001 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Name (TextLabel)
              |- Score (TextLabel)
              `- Position (TextLabel)
            |- Top003 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top004 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top002 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top005 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top006 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top007 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top008 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top009 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top010 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top011 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top012 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top013 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top014 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top015 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top016 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top017 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top018 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top019 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top020 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top021 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top022 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top023 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top024 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top025 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top026 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top027 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top028 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top029 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top030 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top031 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top032 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top033 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top034 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top035 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top036 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top037 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top038 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top039 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top040 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top041 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top042 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top043 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top044 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top045 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top046 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top047 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top048 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top049 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top050 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top051 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top052 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top053 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top054 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top055 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top056 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top057 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top058 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top059 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top060 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top061 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top062 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top063 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top064 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top065 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top066 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top067 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top068 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top069 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top070 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top071 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top072 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top073 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top074 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top075 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top076 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top077 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top078 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top079 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top080 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top081 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top082 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top083 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top084 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top085 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top086 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top087 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top088 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top089 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top090 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top091 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top092 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top093 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top094 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top095 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top096 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top097 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top098 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top099 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            `- Top100 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- Part (Part)
    |- Path (Model)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      `- Part (Part)
    |- normalCanvas (Model)
      |- canvasFrame (Part)
      |- canvasFrame (Part)
      |- canvasFrame (Part)
      `- canvasFrame (Part)
    |- Pro Server Portal (Model)
      |- LocalScript (Script)
      |- Script (Script)
      |- Portal (Model)
        |- Teleport (Part)
          |- ParticleEmitter (ParticleEmitter)
          `- TouchInterest (TouchTransmitter)
        `- Part (Part)
      |- Frame (Model)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        `- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
      |- MaxPoints (IntValue)
      |- TeleportRemote (RemoteEvent)
      `- ProText (Model)
        |- uni0050 (MeshPart)
        |- uni0072 (MeshPart)
        |- uni006F (MeshPart)
        |- uni0053 (MeshPart)
        |- uni0065 (MeshPart)
        |- uni0072 (MeshPart)
        |- uni0076 (MeshPart)
        |- uni0065 (MeshPart)
        `- uni0072 (MeshPart)
    |- Lights (Model)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Lantern (Model)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        `- Part (Part)
      |- Low Poly Lantern (Model)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        `- Part (Part)
      |- Low Poly Lantern (Model)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        `- Part (Part)
      `- Low Poly Lantern (Model)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        `- Part (Part)
    |- canvasPixels (Folder)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- Part (Part)
    |- :p (Model)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        `- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
      |- Model (Model)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        `- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
      |- Model (Model)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        `- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- Part (Part)
    |- BobuxDonation (Model)
      |- TitleOrder (IntValue)
      |- AllowTitles (BoolValue)
      |- TitleColor (Color3Value)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- ScoreBlock (Part)
        `- SurfaceGui (SurfaceGui)
          |- Category (Frame)
            |- AllTime (TextButton)
            |- Selection (Frame)
              `- UICorner (UICorner)
            `- UICorner (UICorner)
          |- DataLabel (TextLabel)
          `- LeaderboardAllTime (ScrollingFrame)
            |- UIListLayout (UIListLayout)
            |- Top001 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Name (TextLabel)
              |- Score (TextLabel)
              `- Position (TextLabel)
            |- Top003 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top004 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top002 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top005 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top006 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top007 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top008 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top009 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top010 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top011 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top012 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top013 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top014 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top015 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top016 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top017 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top018 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top019 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top020 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top021 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top022 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top023 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top024 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top025 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top026 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top027 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top028 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top029 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top030 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top031 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top032 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top033 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top034 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top035 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top036 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top037 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top038 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top039 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top040 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top041 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top042 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top043 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top044 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top045 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top046 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top047 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top048 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top049 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top050 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top051 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top052 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top053 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top054 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top055 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top056 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top057 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top058 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top059 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top060 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top061 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top062 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top063 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top064 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top065 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top066 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top067 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top068 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top069 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top070 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top071 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top072 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top073 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top074 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top075 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top076 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top077 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top078 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top079 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top080 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top081 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top082 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top083 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top084 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top085 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top086 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top087 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top088 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top089 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top090 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top091 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top092 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top093 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top094 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top095 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top096 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top097 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top098 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top099 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            `- Top100 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
      `- Part (Part)
    |- BobuxDonationFake (Model)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- ScoreBlock (Part)
    |- GamepassBoard (Model)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- ScoreBlock (Part)
      `- Part (Part)
    |- Fence (Model)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      `- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
    |- Ground (Model)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- Part (Part)
    |- Trees (Model)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
--[[ TRUNCATED: instance or line budget reached; see 07-COVERAGE.md ]]
```text

```

## Instance census

| Class | Count | Share |
| --- | :---: | :---: |
| 'Accessory' | 22 | 0.3% |
| 'AccessoryDescription' | 22 | 0.3% |
| 'Animation' | 220 | 2.8% |
| 'AnimationClipProvider' | 1 | 0% |
| 'AnimationConstraint' | 120 | 1.5% |
| 'Animator' | 8 | 0.1% |
| 'Attachment' | 448 | 5.6% |
| 'BallSocketConstraint' | 112 | 1.4% |
| 'BindableFunction' | 8 | 0.1% |
| 'BodyColors' | 8 | 0.1% |
| 'BodyPartDescription' | 48 | 0.6% |
| 'BoolValue' | 2 | 0% |
| 'CSGDictionaryService' | 1 | 0% |
| 'Camera' | 1 | 0% |
| 'CanvasGroup' | 1 | 0% |
| 'Chat' | 1 | 0% |
| 'Color3Value' | 2 | 0% |
| 'ContentProvider' | 1 | 0% |
| 'DataModel' | 1 | 0% |
| 'Decal' | 6 | 0.1% |
| 'FaceControls' | 8 | 0.1% |
| 'Folder' | 3 | 0% |
| 'ForceField' | 1 | 0% |
| 'Frame' | 240 | 3% |
| 'GuiService' | 1 | 0% |
| 'Highlight' | 1 | 0% |
| 'Humanoid' | 8 | 0.1% |
| 'HumanoidDescription' | 8 | 0.1% |
| 'ImageButton' | 1 | 0% |
| 'ImageLabel' | 209 | 2.6% |
| 'IntValue' | 3 | 0% |
| 'KeyframeSequenceProvider' | 1 | 0% |
| 'LocalScript' | 11 | 0.1% |
| 'LogService' | 1 | 0% |
| 'MarketplaceService' | 1 | 0% |
| 'MeshPart' | 605 | 7.6% |
| 'MicroProfilerService' | 1 | 0% |
| 'Model' | 136 | 1.7% |
| 'ModuleScript' | 45 | 0.6% |
| 'NoCollisionConstraint' | 152 | 1.9% |
| 'NonReplicatedCSGDictionaryService' | 1 | 0% |
| 'NumberValue' | 148 | 1.9% |
| 'Pants' | 8 | 0.1% |
| 'Part' | 1562 | 19.5% |
| 'ParticleEmitter' | 13 | 0.2% |
| 'Player' | 1 | 0% |
| 'PlayerGui' | 1 | 0% |
| 'PlayerScripts' | 1 | 0% |
| 'Players' | 1 | 0% |
| 'PointLight' | 21 | 0.3% |
| 'RemoteEvent' | 1 | 0% |
| 'RigidConstraint' | 22 | 0.3% |
| 'RunService' | 1 | 0% |
| 'RunningAverageItemDouble' | 2 | 0% |
| 'RunningAverageItemInt' | 42 | 0.5% |
| 'ScreenGui' | 4 | 0.1% |
| 'ScreenshotHud' | 1 | 0% |
| 'Script' | 10 | 0.1% |
| 'ScrollingFrame' | 4 | 0.1% |
| 'Seat' | 14 | 0.2% |
| 'Shirt' | 7 | 0.1% |
| 'Sound' | 72 | 0.9% |
| 'SoundService' | 1 | 0% |
| 'SpawnLocation' | 6 | 0.1% |
| 'Stats' | 1 | 0% |
| 'StatsItem' | 1136 | 14.2% |
| 'Status' | 8 | 0.1% |
| 'StringValue' | 279 | 3.5% |
| 'SurfaceAppearance' | 3 | 0% |
| 'SurfaceGui' | 2 | 0% |
| 'SurfaceLight' | 1 | 0% |
| 'Terrain' | 1 | 0% |
| 'TextBox' | 1 | 0% |
| 'TextButton' | 4 | 0.1% |
| 'TextLabel' | 876 | 11% |
| 'TimerService' | 1 | 0% |
| 'TotalCountTimeIntervalItem' | 36 | 0.5% |
| 'TouchTransmitter' | 1 | 0% |
| 'UIAspectRatioConstraint' | 211 | 2.6% |
| 'UICorner' | 220 | 2.8% |
| 'UIListLayout' | 5 | 0.1% |
| 'UISizeConstraint' | 1 | 0% |
| 'UIStroke' | 2 | 0% |
| 'Vector3Value' | 592 | 7.4% |
| 'VideoCaptureService' | 1 | 0% |
| 'WedgePart' | 80 | 1% |
| 'Workspace' | 1 | 0% |
| 'WrapLayer' | 4 | 0.1% |
| 'WrapTarget' | 120 | 1.5% |

