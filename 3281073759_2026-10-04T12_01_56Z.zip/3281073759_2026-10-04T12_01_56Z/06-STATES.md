# 06 - Observed state

---

| Measure | Count |
| --- | --- |
| Attribute cells tracked | 14 |
| Value objects tracked | 958 |
| Recorded transitions | 26 |
| Traffic events observed | 0 |
| Instances watched | 5121 |

## Attributes

| Instance | Attribute | Type | Observations | Changes | Min | Max | Direction | Last value | Distinct values |
| --- | --- | --- | :---: | :---: | :---: | :---: | --- | --- | :---: |
| 'Workspace.Lights.Low Poly Garden Lantern.Neon.PointLight' | 'ToTurnOn' | boolean | 14 | 13 | — | — | — | true | 14 |
| 'Workspace.Lights.Low Poly Lantern.Meshes/Booth42_Lantern2.PointLight' | 'ToTurnOn' | boolean | 4 | 3 | — | — | — | true | 4 |
| 'Lighting' | 'RBX_LightingTechnologyUnifiedMigration' | boolean | 1 | 0 | — | — | — | true | 1 |
| 'Workspace.I_lovecelebrations.CoolBoyHair.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.Itss_Mila.Accessory (defaultAccessory).Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.SSecretEyes.Hat1.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.T5DD01.SidePonytail.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.crucifypast.Accessory (Full Wispy Manga Lashes).Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.0700000… | 1 |
| 'Workspace.crucifypast.Accessory (default).Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.crucifypast.Bling.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.crucifypast.Curly Edges.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.crucifypast.FashionistaBangsAccessory.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.crucifypast.NewSideBangsCaramelAccessory.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.trenjay123.Hair.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |

## Value objects

| Instance | Class | Type | Observations | Changes | Min | Max | Direction | Last value |
| --- | --- | --- | :---: | :---: | :---: | :---: | --- | --- |
| 'Players.AverieB1310.leaderstats.Guesses' | IntValue | number | 2 | 1 | 14 | 15 | up 1 / down 0 | 15 |
| 'Players.AverieB1310.leaderstats.Points' | IntValue | number | 2 | 1 | 1070 | 1085 | up 1 / down 0 | 1085 |
| 'Players.I_lovecelebrations.leaderstats.Guesses' | IntValue | number | 2 | 1 | 298 | 299 | up 1 / down 0 | 299 |
| 'Players.I_lovecelebrations.leaderstats.Points' | IntValue | number | 2 | 1 | 22358 | 22368 | up 1 / down 0 | 22368 |
| 'Players.Itss_Mila.leaderstats.Points' | IntValue | number | 2 | 1 | 11547 | 11583 | up 1 / down 0 | 11583 |
| 'Players.SeoulKD.leaderstats.Guesses' | IntValue | number | 2 | 1 | 201 | 202 | up 1 / down 0 | 202 |
| 'Players.SeoulKD.leaderstats.Points' | IntValue | number | 2 | 1 | 25845 | 25919 | up 1 / down 0 | 25919 |
| 'Players.T5DD01.leaderstats.Guesses' | IntValue | number | 2 | 1 | 0 | 13 | up 1 / down 0 | 13 |
| 'Players.T5DD01.leaderstats.Points' | IntValue | number | 2 | 1 | 0 | 919 | up 1 / down 0 | 919 |
| 'Players.crucifypast.leaderstats.Guesses' | IntValue | number | 2 | 1 | 118 | 118 | — | 118 |
| 'Players.crucifypast.leaderstats.Points' | IntValue | number | 2 | 1 | 10066 | 10066 | — | 10066 |
| 'Players.trenjay123.leaderstats.Guesses' | IntValue | number | 2 | 1 | 0 | 32 | up 1 / down 0 | 32 |
| 'Players.trenjay123.leaderstats.Points' | IntValue | number | 2 | 1 | 0 | 2476 | up 1 / down 0 | 2476 |
| 'ReplicatedStorage.DATA.AverieB1310.guesses' | NumberValue | number | 2 | 1 | 14 | 15 | up 1 / down 0 | 15 |
| 'ReplicatedStorage.DATA.AverieB1310.lastUpdate' | NumberValue | number | 2 | 1 | 1791081276 | 1791115416 | up 1 / down 0 | 1791115416 |
| 'ReplicatedStorage.DATA.AverieB1310.points' | NumberValue | number | 2 | 1 | 1070 | 1085 | up 1 / down 0 | 1085 |
| 'ReplicatedStorage.DATA.I_lovecelebrations.guesses' | NumberValue | number | 2 | 1 | 298 | 299 | up 1 / down 0 | 299 |
| 'ReplicatedStorage.DATA.I_lovecelebrations.lastUpdate' | NumberValue | number | 2 | 1 | 1777628156 | 1791115344 | up 1 / down 0 | 1791115344 |
| 'ReplicatedStorage.DATA.I_lovecelebrations.points' | NumberValue | number | 2 | 1 | 22358 | 22368 | up 1 / down 0 | 22368 |
| 'ReplicatedStorage.DATA.Itss_Mila.lastUpdate' | NumberValue | number | 2 | 1 | 1791065242 | 1791115351 | up 1 / down 0 | 1791115351 |
| 'ReplicatedStorage.DATA.Itss_Mila.points' | NumberValue | number | 2 | 1 | 11547 | 11583 | up 1 / down 0 | 11583 |
| 'ReplicatedStorage.DATA.SeoulKD.guesses' | NumberValue | number | 2 | 1 | 201 | 202 | up 1 / down 0 | 202 |
| 'ReplicatedStorage.DATA.SeoulKD.lastUpdate' | NumberValue | number | 2 | 1 | 1791115311 | 1791115377 | up 1 / down 0 | 1791115377 |
| 'ReplicatedStorage.DATA.SeoulKD.points' | NumberValue | number | 2 | 1 | 25845 | 25919 | up 1 / down 0 | 25919 |
| 'ReplicatedStorage.DATA.crucifypast.lastUpdate' | NumberValue | number | 2 | 1 | 1748219909 | 1791115336 | up 1 / down 0 | 1791115336 |
| 'ReplicatedStorage.DATA.trenjay123.lastUpdate' | NumberValue | number | 2 | 1 | 1782481022 | 1791115398 | up 1 / down 0 | 1791115398 |
| 'Players.AverieB1310.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.I_lovecelebrations.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.Ilovezeke357.leaderstats.Guesses' | IntValue | number | 1 | 0 | 18 | 18 | — | 18 |
| 'Players.Ilovezeke357.leaderstats.Points' | IntValue | number | 1 | 0 | 1488 | 1488 | — | 1488 |
| 'Players.Ilovezeke357.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.Itss_Mila.leaderstats.Guesses' | IntValue | number | 1 | 0 | 133 | 133 | — | 133 |
| 'Players.Itss_Mila.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.SSecretEyes.leaderstats.Guesses' | IntValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Players.SSecretEyes.leaderstats.Points' | IntValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Players.SSecretEyes.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.MouseLockController.BoundKeys' | StringValue | string | 1 | 0 | — | — | — | "LeftShift,RightShift" |
| 'Players.SeoulKD.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.T5DD01.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.crucifypast.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.trenjay123.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'ReplicatedStorage.DATA.AverieB1310.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.AverieB1310.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.AverieB1310.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.AverieB1310.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.I_lovecelebrations.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.I_lovecelebrations.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.I_lovecelebrations.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.I_lovecelebrations.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Ilovezeke357.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Ilovezeke357.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Ilovezeke357.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Ilovezeke357.guesses' | NumberValue | number | 1 | 0 | 18 | 18 | — | 18 |
| 'ReplicatedStorage.DATA.Ilovezeke357.lastUpdate' | NumberValue | number | 1 | 0 | 1789389555 | 1789389555 | — | 1789389555 |
| 'ReplicatedStorage.DATA.Ilovezeke357.points' | NumberValue | number | 1 | 0 | 1488 | 1488 | — | 1488 |
| 'ReplicatedStorage.DATA.Ilovezeke357.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Itss_Mila.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Itss_Mila.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Itss_Mila.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Itss_Mila.guesses' | NumberValue | number | 1 | 0 | 133 | 133 | — | 133 |
| 'ReplicatedStorage.DATA.Itss_Mila.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SSecretEyes.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SSecretEyes.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SSecretEyes.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SSecretEyes.guesses' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SSecretEyes.lastUpdate' | NumberValue | number | 1 | 0 | 1791115412 | 1791115412 | — | 1791115412 |
| 'ReplicatedStorage.DATA.SSecretEyes.points' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SSecretEyes.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.T5DD01.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.T5DD01.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.T5DD01.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.T5DD01.guesses' | NumberValue | number | 1 | 0 | 13 | 13 | — | 13 |
| 'ReplicatedStorage.DATA.T5DD01.lastUpdate' | NumberValue | number | 1 | 0 | 1791090817 | 1791090817 | — | 1791090817 |
| 'ReplicatedStorage.DATA.T5DD01.points' | NumberValue | number | 1 | 0 | 919 | 919 | — | 919 |
| 'ReplicatedStorage.DATA.T5DD01.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.crucifypast.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.crucifypast.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.crucifypast.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.crucifypast.guesses' | NumberValue | number | 1 | 0 | 118 | 118 | — | 118 |
| 'ReplicatedStorage.DATA.crucifypast.points' | NumberValue | number | 1 | 0 | 10066 | 10066 | — | 10066 |
| 'ReplicatedStorage.DATA.crucifypast.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.trenjay123.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.trenjay123.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.trenjay123.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.trenjay123.guesses' | NumberValue | number | 1 | 0 | 32 | 32 | — | 32 |
| 'ReplicatedStorage.DATA.trenjay123.points' | NumberValue | number | 1 | 0 | 2476 | 2476 | — | 2476 |
| 'ReplicatedStorage.DATA.trenjay123.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.getPublicData.DataName' | StringValue | string | 1 | 0 | — | — | — | "DATA" |
| 'Workspace.BobuxDonation.AllowTitles' | BoolValue | boolean | 1 | 0 | — | — | — | true |
| 'Workspace.BobuxDonation.TitleColor' | Color3Value | Color3 | 1 | 0 | — | — | — | Color3.new(0.8274510502815247, 0.5764706… |
| 'Workspace.BobuxDonation.TitleOrder' | IntValue | number | 1 | 0 | -1 | -1 | — | -1 |
| 'Workspace.I_lovecelebrations.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.I_lovecelebrations.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.I_lovecelebrations.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.I_lovecelebrations.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.I_lovecelebrations.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.I_lovecelebrations.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.I_lovecelebrations.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.I_lovecelebrations.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.I_lovecelebrations.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.I_lovecelebrations.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.I_lovecelebrations.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.I_lovecelebrations.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.I_lovecelebrations.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.I_lovecelebrations.CoolBoyHair.Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.6583895… |
| 'Workspace.I_lovecelebrations.CoolBoyHair.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.4248399… |
| 'Workspace.I_lovecelebrations.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9921589… |
| 'Workspace.I_lovecelebrations.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.0895277… |
| 'Workspace.I_lovecelebrations.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.I_lovecelebrations.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.I_lovecelebrations.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3896427… |
| 'Workspace.I_lovecelebrations.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1978399… |
| 'Workspace.I_lovecelebrations.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 0.9399999976158142 | 0.9399999976158142 | — | 0.9399999976158142 |
| 'Workspace.I_lovecelebrations.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 0.8999999761581421 | 0.8999999761581421 | — | 0.8999999761581421 |
| 'Workspace.I_lovecelebrations.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.I_lovecelebrations.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0.18000000715255737 | 0.18000000715255737 | — | 0.18000000715255737 |
| 'Workspace.I_lovecelebrations.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 0.8899999856948853 | 0.8899999856948853 | — | 0.8899999856948853 |
| 'Workspace.I_lovecelebrations.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.I_lovecelebrations.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.I_lovecelebrations.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.I_lovecelebrations.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.I_lovecelebrations.LeftFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.079928… |
| 'Workspace.I_lovecelebrations.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.079928… |
| 'Workspace.I_lovecelebrations.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7213894… |
| 'Workspace.I_lovecelebrations.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0435575… |
| 'Workspace.I_lovecelebrations.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0440365… |
| 'Workspace.I_lovecelebrations.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7531499… |
| 'Workspace.I_lovecelebrations.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1392000… |
| 'Workspace.I_lovecelebrations.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.068575… |
| 'Workspace.I_lovecelebrations.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8118551… |
| 'Workspace.I_lovecelebrations.LeftLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.079929… |
| 'Workspace.I_lovecelebrations.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.079929… |
| 'Workspace.I_lovecelebrations.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7213889… |
| 'Workspace.I_lovecelebrations.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.106829… |
| 'Workspace.I_lovecelebrations.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1842197… |
| 'Workspace.I_lovecelebrations.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2316467… |
| 'Workspace.I_lovecelebrations.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2316467… |
| 'Workspace.I_lovecelebrations.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9424356… |
| 'Workspace.I_lovecelebrations.LeftUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.109618… |
| 'Workspace.I_lovecelebrations.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.109618… |
| 'Workspace.I_lovecelebrations.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7807660… |
| 'Workspace.I_lovecelebrations.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.5, -0.… |
| 'Workspace.I_lovecelebrations.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.6722400… |
| 'Workspace.I_lovecelebrations.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5, -0.3… |
| 'Workspace.I_lovecelebrations.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.328… |
| 'Workspace.I_lovecelebrations.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -2.720393… |
| 'Workspace.I_lovecelebrations.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -3.027915… |
| 'Workspace.I_lovecelebrations.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.301057… |
| 'Workspace.I_lovecelebrations.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 4.8985526… |
| 'Workspace.I_lovecelebrations.RightFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7213894… |
| 'Workspace.I_lovecelebrations.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0799288… |
| 'Workspace.I_lovecelebrations.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0799287… |
| 'Workspace.I_lovecelebrations.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7531499… |
| 'Workspace.I_lovecelebrations.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.044315… |
| 'Workspace.I_lovecelebrations.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.044314… |
| 'Workspace.I_lovecelebrations.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8118550… |
| 'Workspace.I_lovecelebrations.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.139702… |
| 'Workspace.I_lovecelebrations.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0682973… |
| 'Workspace.I_lovecelebrations.RightLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7213890… |
| 'Workspace.I_lovecelebrations.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0799295… |
| 'Workspace.I_lovecelebrations.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0799294… |
| 'Workspace.I_lovecelebrations.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9426322… |
| 'Workspace.I_lovecelebrations.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1062288… |
| 'Workspace.I_lovecelebrations.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.184318… |
| 'Workspace.I_lovecelebrations.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.231771… |
| 'Workspace.I_lovecelebrations.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.231771… |
| 'Workspace.I_lovecelebrations.RightUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7807660… |
| 'Workspace.I_lovecelebrations.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1096180… |
| 'Workspace.I_lovecelebrations.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1096180… |
| 'Workspace.I_lovecelebrations.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.I_lovecelebrations.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.2246434… |
| 'Workspace.I_lovecelebrations.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.2246434… |
| 'Workspace.I_lovecelebrations.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.713337… |
| 'Workspace.I_lovecelebrations.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.916026… |
| 'Workspace.I_lovecelebrations.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.916026… |
| 'Workspace.I_lovecelebrations.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 9.0186951… |
| 'Workspace.I_lovecelebrations.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.4492934… |
| 'Workspace.I_lovecelebrations.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.8390778… |
| 'Workspace.I_lovecelebrations.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7133379… |
| 'Workspace.I_lovecelebrations.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9160000… |
| 'Workspace.I_lovecelebrations.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9160000… |
| 'Workspace.I_lovecelebrations.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 4.8985526… |
| 'Workspace.Itss_Mila.Accessory (defaultAccessory).Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Itss_Mila.Accessory (defaultAccessory).Handle.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0191802… |
| 'Workspace.Itss_Mila.Accessory (defaultAccessory).Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3883528… |
| 'Workspace.Itss_Mila.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.Itss_Mila.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Itss_Mila.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Itss_Mila.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Itss_Mila.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Itss_Mila.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Itss_Mila.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Itss_Mila.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Itss_Mila.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Itss_Mila.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Itss_Mila.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.Itss_Mila.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.Itss_Mila.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Itss_Mila.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Itss_Mila.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.Itss_Mila.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.9356886… |
| 'Workspace.Itss_Mila.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0.6000… |
| 'Workspace.Itss_Mila.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0.6000… |
| 'Workspace.Itss_Mila.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.5, … |
| 'Workspace.Itss_Mila.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1978499… |
| 'Workspace.Itss_Mila.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 0.8500000238418579 | 0.8500000238418579 | — | 0.8500000238418579 |
| 'Workspace.Itss_Mila.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 0.8999999761581421 | 0.8999999761581421 | — | 0.8999999761581421 |
| 'Workspace.Itss_Mila.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0.5 | 0.5 | — | 0.5 |
| 'Workspace.Itss_Mila.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.Itss_Mila.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 0.699999988079071 | 0.699999988079071 | — | 0.699999988079071 |
| 'Workspace.Itss_Mila.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.Itss_Mila.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.Itss_Mila.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.Itss_Mila.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.Itss_Mila.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.788139… |
| 'Workspace.Itss_Mila.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0182774… |
| 'Workspace.Itss_Mila.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.Itss_Mila.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.149… |
| 'Workspace.Itss_Mila.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004789… |
| 'Workspace.Itss_Mila.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.3001… |
| 'Workspace.Itss_Mila.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004786… |
| 'Workspace.Itss_Mila.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004786… |
| 'Workspace.Itss_Mila.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.0518… |
| 'Workspace.Itss_Mila.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.Itss_Mila.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9802322… |
| 'Workspace.Itss_Mila.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.Itss_Mila.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004792… |
| 'Workspace.Itss_Mila.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3841857… |
| 'Workspace.Itss_Mila.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5000003… |
| 'Workspace.Itss_Mila.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5000003… |
| 'Workspace.Itss_Mila.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1686… |
| 'Workspace.Itss_Mila.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.Itss_Mila.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.9406967… |
| 'Workspace.Itss_Mila.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.Itss_Mila.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500003… |
| 'Workspace.Itss_Mila.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.9266678… |
| 'Workspace.Itss_Mila.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.4999961… |
| 'Workspace.Itss_Mila.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000003… |
| 'Workspace.Itss_Mila.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000003… |
| 'Workspace.Itss_Mila.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000004… |
| 'Workspace.Itss_Mila.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000003… |
| 'Workspace.Itss_Mila.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000003… |
| 'Workspace.Itss_Mila.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.Itss_Mila.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.101… |
| 'Workspace.Itss_Mila.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.018277… |
| 'Workspace.Itss_Mila.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.3001… |
| 'Workspace.Itss_Mila.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.149… |
| 'Workspace.Itss_Mila.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.5762786… |
| 'Workspace.Itss_Mila.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.0518… |
| 'Workspace.Itss_Mila.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1920928… |
| 'Workspace.Itss_Mila.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1920928… |
| 'Workspace.Itss_Mila.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.Itss_Mila.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.54… |
| 'Workspace.Itss_Mila.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.379… |
| 'Workspace.Itss_Mila.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1686… |
| 'Workspace.Itss_Mila.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.Itss_Mila.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.344650… |
| 'Workspace.Itss_Mila.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.Itss_Mila.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.Itss_Mila.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.Itss_Mila.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.420… |
| 'Workspace.Itss_Mila.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.40… |
| 'Workspace.Itss_Mila.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000003… |
| 'Workspace.Itss_Mila.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000003… |
| 'Workspace.Itss_Mila.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.000003… |
| 'Workspace.Itss_Mila.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.000003… |
| 'Workspace.Itss_Mila.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.000003… |
| 'Workspace.Itss_Mila.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000003… |
| 'Workspace.Itss_Mila.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000003… |
| 'Workspace.Itss_Mila.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.0428197… |
| 'Workspace.Itss_Mila.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9999961… |
| 'Workspace.Itss_Mila.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9999961… |
| 'Workspace.Itss_Mila.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9999961… |
| 'Workspace.Itss_Mila.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000003… |
| 'Workspace.Pro Server Portal.MaxPoints' | IntValue | number | 1 | 0 | 10000 | 10000 | — | 10000 |
| 'Workspace.SSecretEyes.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SSecretEyes.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SSecretEyes.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SSecretEyes.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SSecretEyes.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SSecretEyes.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SSecretEyes.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SSecretEyes.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SSecretEyes.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SSecretEyes.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SSecretEyes.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.SSecretEyes.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SSecretEyes.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SSecretEyes.Hat1.Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0025000… |
| 'Workspace.SSecretEyes.Hat1.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.4947700… |
| 'Workspace.SSecretEyes.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9921589… |
| 'Workspace.SSecretEyes.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.0895277… |
| 'Workspace.SSecretEyes.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.SSecretEyes.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.SSecretEyes.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3896427… |
| 'Workspace.SSecretEyes.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1978399… |
| 'Workspace.SSecretEyes.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 0.9200000166893005 | 0.9200000166893005 | — | 0.9200000166893005 |
| 'Workspace.SSecretEyes.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 1.0099999904632568 | 1.0099999904632568 | — | 1.0099999904632568 |
| 'Workspace.SSecretEyes.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0.47999998927116394 | 0.47999998927116394 | — | 0.47999998927116394 |
| 'Workspace.SSecretEyes.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0.46000000834465027 | 0.46000000834465027 | — | 0.46000000834465027 |
| 'Workspace.SSecretEyes.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 0.8500000238418579 | 0.8500000238418579 | — | 0.8500000238418579 |
| 'Workspace.SSecretEyes.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 0.949999988079071 | 0.949999988079071 | — | 0.949999988079071 |
| 'Workspace.SSecretEyes.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.SSecretEyes.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.SSecretEyes.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.SSecretEyes.LeftFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0044203… |
| 'Workspace.SSecretEyes.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0044205… |
| 'Workspace.SSecretEyes.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8361780… |
| 'Workspace.SSecretEyes.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0435575… |
| 'Workspace.SSecretEyes.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0440365… |
| 'Workspace.SSecretEyes.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7531499… |
| 'Workspace.SSecretEyes.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1392000… |
| 'Workspace.SSecretEyes.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.068575… |
| 'Workspace.SSecretEyes.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8118551… |
| 'Workspace.SSecretEyes.LeftLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.002462… |
| 'Workspace.SSecretEyes.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.005055… |
| 'Workspace.SSecretEyes.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7419999… |
| 'Workspace.SSecretEyes.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.106829… |
| 'Workspace.SSecretEyes.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1842197… |
| 'Workspace.SSecretEyes.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2316467… |
| 'Workspace.SSecretEyes.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2316467… |
| 'Workspace.SSecretEyes.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9424356… |
| 'Workspace.SSecretEyes.LeftUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.075534… |
| 'Workspace.SSecretEyes.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.026260… |
| 'Workspace.SSecretEyes.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7596539… |
| 'Workspace.SSecretEyes.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.SSecretEyes.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.6962258… |
| 'Workspace.SSecretEyes.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.4999999… |
| 'Workspace.SSecretEyes.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SSecretEyes.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.680857… |
| 'Workspace.SSecretEyes.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -3.623962… |
| 'Workspace.SSecretEyes.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -7.261522… |
| 'Workspace.SSecretEyes.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SSecretEyes.RightFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8361780… |
| 'Workspace.SSecretEyes.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.004554… |
| 'Workspace.SSecretEyes.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.004554… |
| 'Workspace.SSecretEyes.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7531499… |
| 'Workspace.SSecretEyes.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.044315… |
| 'Workspace.SSecretEyes.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.044314… |
| 'Workspace.SSecretEyes.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8118550… |
| 'Workspace.SSecretEyes.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.139702… |
| 'Workspace.SSecretEyes.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0682973… |
| 'Workspace.SSecretEyes.RightLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7419999… |
| 'Workspace.SSecretEyes.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0023289… |
| 'Workspace.SSecretEyes.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0053289… |
| 'Workspace.SSecretEyes.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9426322… |
| 'Workspace.SSecretEyes.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1062288… |
| 'Workspace.SSecretEyes.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.184318… |
| 'Workspace.SSecretEyes.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.231771… |
| 'Workspace.SSecretEyes.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.231771… |
| 'Workspace.SSecretEyes.RightUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7596539… |
| 'Workspace.SSecretEyes.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0755339… |
| 'Workspace.SSecretEyes.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0265339… |
| 'Workspace.SSecretEyes.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SSecretEyes.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SSecretEyes.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SSecretEyes.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.757948… |
| 'Workspace.SSecretEyes.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.911444… |
| 'Workspace.SSecretEyes.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.911444… |
| 'Workspace.SSecretEyes.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.058594… |
| 'Workspace.SSecretEyes.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SSecretEyes.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.8154158… |
| 'Workspace.SSecretEyes.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7579999… |
| 'Workspace.SSecretEyes.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9109999… |
| 'Workspace.SSecretEyes.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9109999… |
| 'Workspace.SSecretEyes.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SeoulKD.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SeoulKD.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.SeoulKD.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SeoulKD.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.pose' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.pose.RthroIdlePose.Weight' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.SeoulKD.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SeoulKD.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SeoulKD.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.SeoulKD.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.SeoulKD.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SeoulKD.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SeoulKD.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.SeoulKD.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.SeoulKD.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.SeoulKD.LeftFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0044203… |
| 'Workspace.SeoulKD.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0044205… |
| 'Workspace.SeoulKD.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8361780… |
| 'Workspace.SeoulKD.LeftLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.002462… |
| 'Workspace.SeoulKD.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.005055… |
| 'Workspace.SeoulKD.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7419999… |
| 'Workspace.SeoulKD.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.038313… |
| 'Workspace.SeoulKD.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1471741… |
| 'Workspace.SeoulKD.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2811447… |
| 'Workspace.SeoulKD.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2811447… |
| 'Workspace.SeoulKD.LeftUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.075534… |
| 'Workspace.SeoulKD.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.026260… |
| 'Workspace.SeoulKD.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7596539… |
| 'Workspace.SeoulKD.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.SeoulKD.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.6962258… |
| 'Workspace.SeoulKD.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.4999999… |
| 'Workspace.SeoulKD.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SeoulKD.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.680857… |
| 'Workspace.SeoulKD.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -3.623962… |
| 'Workspace.SeoulKD.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -7.261522… |
| 'Workspace.SeoulKD.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SeoulKD.RightFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8361780… |
| 'Workspace.SeoulKD.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.004554… |
| 'Workspace.SeoulKD.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.004554… |
| 'Workspace.SeoulKD.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6933399… |
| 'Workspace.SeoulKD.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.077919… |
| 'Workspace.SeoulKD.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0540800… |
| 'Workspace.SeoulKD.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6270951… |
| 'Workspace.SeoulKD.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.080102… |
| 'Workspace.SeoulKD.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1268978… |
| 'Workspace.SeoulKD.RightLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7419999… |
| 'Workspace.SeoulKD.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0023289… |
| 'Workspace.SeoulKD.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0053289… |
| 'Workspace.SeoulKD.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5698585… |
| 'Workspace.SeoulKD.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0374107… |
| 'Workspace.SeoulKD.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.147589… |
| 'Workspace.SeoulKD.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.281589… |
| 'Workspace.SeoulKD.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.281589… |
| 'Workspace.SeoulKD.RightUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7596539… |
| 'Workspace.SeoulKD.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0755339… |
| 'Workspace.SeoulKD.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0265339… |
| 'Workspace.SeoulKD.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SeoulKD.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SeoulKD.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.757948… |
| 'Workspace.SeoulKD.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.911444… |
| 'Workspace.SeoulKD.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.911444… |
| 'Workspace.SeoulKD.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.058594… |
| 'Workspace.SeoulKD.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SeoulKD.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.8154158… |
| 'Workspace.SeoulKD.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7579999… |
| 'Workspace.SeoulKD.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9109999… |
| 'Workspace.SeoulKD.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9109999… |
| 'Workspace.SeoulKD.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.T5DD01.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.T5DD01.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.T5DD01.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.T5DD01.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.T5DD01.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.T5DD01.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.T5DD01.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.T5DD01.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.T5DD01.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.T5DD01.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.T5DD01.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.T5DD01.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.T5DD01.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.pose' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.pose.RthroIdlePose.Weight' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.T5DD01.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.T5DD01.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9921589… |
| 'Workspace.T5DD01.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.0895277… |
| 'Workspace.T5DD01.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.T5DD01.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.T5DD01.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3896427… |
| 'Workspace.T5DD01.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1978399… |
| 'Workspace.T5DD01.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 0.9800000190734863 | 0.9800000190734863 | — | 0.9800000190734863 |
| 'Workspace.T5DD01.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 0.8999999761581421 | 0.8999999761581421 | — | 0.8999999761581421 |
| 'Workspace.T5DD01.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.T5DD01.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0.05000000074505806 | 0.05000000074505806 | — | 0.05000000074505806 |
| 'Workspace.T5DD01.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 0.9700000286102295 | 0.9700000286102295 | — | 0.9700000286102295 |
| 'Workspace.T5DD01.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.T5DD01.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.T5DD01.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.T5DD01.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.T5DD01.LC_PrettyImpressiveRightEyebrow_Accessory.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.4228824… |
| 'Workspace.T5DD01.LeftFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0034454… |
| 'Workspace.T5DD01.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0034456… |
| 'Workspace.T5DD01.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5877767… |
| 'Workspace.T5DD01.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.017243… |
| 'Workspace.T5DD01.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1085174… |
| 'Workspace.T5DD01.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459886… |
| 'Workspace.T5DD01.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1874169… |
| 'Workspace.T5DD01.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.174442… |
| 'Workspace.T5DD01.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623244… |
| 'Workspace.T5DD01.LeftLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0229650… |
| 'Workspace.T5DD01.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0025257… |
| 'Workspace.T5DD01.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6228439… |
| 'Workspace.T5DD01.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.160127… |
| 'Workspace.T5DD01.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.022783… |
| 'Workspace.T5DD01.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.T5DD01.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.T5DD01.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489318… |
| 'Workspace.T5DD01.LeftUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.081800… |
| 'Workspace.T5DD01.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.035082… |
| 'Workspace.T5DD01.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7855476… |
| 'Workspace.T5DD01.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.349282… |
| 'Workspace.T5DD01.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3261278… |
| 'Workspace.T5DD01.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3492811… |
| 'Workspace.T5DD01.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.T5DD01.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.212736… |
| 'Workspace.T5DD01.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000001… |
| 'Workspace.T5DD01.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.070802… |
| 'Workspace.T5DD01.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.T5DD01.RightFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5877767… |
| 'Workspace.T5DD01.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.003301… |
| 'Workspace.T5DD01.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.003301… |
| 'Workspace.T5DD01.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459872… |
| 'Workspace.T5DD01.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0172429… |
| 'Workspace.T5DD01.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.090098… |
| 'Workspace.T5DD01.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623249… |
| 'Workspace.T5DD01.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.187417… |
| 'Workspace.T5DD01.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1928601… |
| 'Workspace.T5DD01.RightLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6228439… |
| 'Workspace.T5DD01.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.022820… |
| 'Workspace.T5DD01.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.002820… |
| 'Workspace.T5DD01.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489327… |
| 'Workspace.T5DD01.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1601286… |
| 'Workspace.T5DD01.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0227840… |
| 'Workspace.T5DD01.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.T5DD01.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.T5DD01.RightUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7855476… |
| 'Workspace.T5DD01.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0817872… |
| 'Workspace.T5DD01.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0347872… |
| 'Workspace.T5DD01.SidePonytail.Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.6583895… |
| 'Workspace.T5DD01.SidePonytail.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.7030599… |
| 'Workspace.T5DD01.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.T5DD01.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.T5DD01.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.T5DD01.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.T5DD01.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.T5DD01.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.T5DD01.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.9644888… |
| 'Workspace.T5DD01.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.T5DD01.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3034231… |
| 'Workspace.T5DD01.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.T5DD01.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.T5DD01.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.T5DD01.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.TopPoints.AllowTitles' | BoolValue | boolean | 1 | 0 | — | — | — | true |
| 'Workspace.TopPoints.TitleColor' | Color3Value | Color3 | 1 | 0 | — | — | — | Color3.new(0.5372549295425415, 0.7176470… |
| 'Workspace.TopPoints.TitleOrder' | IntValue | number | 1 | 0 | -2 | -2 | — | -2 |
| 'Workspace.crucifypast.Accessory (Full Wispy Manga Lashes).Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.Accessory (Full Wispy Manga Lashes).Handle.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000138… |
| 'Workspace.crucifypast.Accessory (Full Wispy Manga Lashes).Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1230890… |
| 'Workspace.crucifypast.Accessory (default).Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.Accessory (default).Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0003271… |
| 'Workspace.crucifypast.Accessory (default).Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.4078140… |
| 'Workspace.crucifypast.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.crucifypast.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.crucifypast.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.crucifypast.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.crucifypast.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.crucifypast.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.crucifypast.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.crucifypast.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.crucifypast.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.crucifypast.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.crucifypast.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.crucifypast.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.crucifypast.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.pose' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.pose.StylishPose.Weight' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.crucifypast.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.crucifypast.Bling.Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.Bling.Handle.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.029693… |
| 'Workspace.crucifypast.Bling.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1686553… |
| 'Workspace.crucifypast.Curly Edges.Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.Curly Edges.Handle.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0347349… |
| 'Workspace.crucifypast.Curly Edges.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8971840… |
| 'Workspace.crucifypast.FashionistaBangsAccessory.Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.FashionistaBangsAccessory.Handle.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.009520… |
| 'Workspace.crucifypast.FashionistaBangsAccessory.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3390389… |
| 'Workspace.crucifypast.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.crucifypast.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, -0.… |
| 'Workspace.crucifypast.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0.6000… |
| 'Workspace.crucifypast.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0.6000… |
| 'Workspace.crucifypast.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.5, … |
| 'Workspace.crucifypast.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.2308900… |
| 'Workspace.crucifypast.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 0.8500000238418579 | 0.8500000238418579 | — | 0.8500000238418579 |
| 'Workspace.crucifypast.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 0.8999999761581421 | 0.8999999761581421 | — | 0.8999999761581421 |
| 'Workspace.crucifypast.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0.5 | 0.5 | — | 0.5 |
| 'Workspace.crucifypast.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.crucifypast.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 0.699999988079071 | 0.699999988079071 | — | 0.699999988079071 |
| 'Workspace.crucifypast.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 0.949999988079071 | 0.949999988079071 | — | 0.949999988079071 |
| 'Workspace.crucifypast.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.crucifypast.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.crucifypast.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.crucifypast.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.788139… |
| 'Workspace.crucifypast.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0182774… |
| 'Workspace.crucifypast.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.crucifypast.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.017243… |
| 'Workspace.crucifypast.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1085174… |
| 'Workspace.crucifypast.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459886… |
| 'Workspace.crucifypast.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1874169… |
| 'Workspace.crucifypast.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.174442… |
| 'Workspace.crucifypast.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623244… |
| 'Workspace.crucifypast.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.crucifypast.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9802322… |
| 'Workspace.crucifypast.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.crucifypast.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.160127… |
| 'Workspace.crucifypast.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.022783… |
| 'Workspace.crucifypast.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.crucifypast.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.crucifypast.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489318… |
| 'Workspace.crucifypast.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.crucifypast.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.9406967… |
| 'Workspace.crucifypast.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.crucifypast.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.349282… |
| 'Workspace.crucifypast.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3261278… |
| 'Workspace.crucifypast.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3492811… |
| 'Workspace.crucifypast.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.crucifypast.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.212736… |
| 'Workspace.crucifypast.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000001… |
| 'Workspace.crucifypast.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.070802… |
| 'Workspace.crucifypast.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.crucifypast.NewSideBangsCaramelAccessory.Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.NewSideBangsCaramelAccessory.Handle.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.002216… |
| 'Workspace.crucifypast.NewSideBangsCaramelAccessory.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3555669… |
| 'Workspace.crucifypast.RightFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2635574… |
| 'Workspace.crucifypast.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.crucifypast.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.crucifypast.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459872… |
| 'Workspace.crucifypast.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0172429… |
| 'Workspace.crucifypast.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.090098… |
| 'Workspace.crucifypast.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623249… |
| 'Workspace.crucifypast.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.187417… |
| 'Workspace.crucifypast.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1928601… |
| 'Workspace.crucifypast.RightLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3500669… |
| 'Workspace.crucifypast.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0102564… |
| 'Workspace.crucifypast.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0102564… |
| 'Workspace.crucifypast.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489327… |
| 'Workspace.crucifypast.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1601286… |
| 'Workspace.crucifypast.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0227840… |
| 'Workspace.crucifypast.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.crucifypast.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.crucifypast.RightUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3142320… |
| 'Workspace.crucifypast.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0187659… |
| 'Workspace.crucifypast.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1167659… |
| 'Workspace.crucifypast.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.crucifypast.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.crucifypast.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.crucifypast.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.crucifypast.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.crucifypast.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.crucifypast.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.9644888… |
| 'Workspace.crucifypast.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.crucifypast.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3034231… |
| 'Workspace.crucifypast.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.crucifypast.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.crucifypast.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.crucifypast.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.trenjay123.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.trenjay123.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.trenjay123.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.trenjay123.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.trenjay123.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.trenjay123.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.trenjay123.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.trenjay123.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.trenjay123.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.trenjay123.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.trenjay123.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.trenjay123.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.trenjay123.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.trenjay123.Hair.Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.Hair.Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.002093… |
| 'Workspace.trenjay123.Hair.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.2306674… |
| 'Workspace.trenjay123.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9921589… |
| 'Workspace.trenjay123.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.0895277… |
| 'Workspace.trenjay123.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.trenjay123.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.trenjay123.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3896427… |
| 'Workspace.trenjay123.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1978399… |
| 'Workspace.trenjay123.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.trenjay123.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.trenjay123.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.trenjay123.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.trenjay123.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.trenjay123.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.trenjay123.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.trenjay123.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.trenjay123.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.trenjay123.LC_PrettyImpressiveRightEyebrow_Accessory.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.4228824… |
| 'Workspace.trenjay123.LeftFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0044203… |
| 'Workspace.trenjay123.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0044205… |
| 'Workspace.trenjay123.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8361780… |
| 'Workspace.trenjay123.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0777419… |
| 'Workspace.trenjay123.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.054612… |
| 'Workspace.trenjay123.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6933399… |
| 'Workspace.trenjay123.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0791994… |
| 'Workspace.trenjay123.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.127430… |
| 'Workspace.trenjay123.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6270952… |
| 'Workspace.trenjay123.LeftLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.002462… |
| 'Workspace.trenjay123.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.005055… |
| 'Workspace.trenjay123.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7419999… |
| 'Workspace.trenjay123.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.038313… |
| 'Workspace.trenjay123.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1471741… |
| 'Workspace.trenjay123.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2811447… |
| 'Workspace.trenjay123.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2811447… |
| 'Workspace.trenjay123.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5698586… |
| 'Workspace.trenjay123.LeftUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.075534… |
| 'Workspace.trenjay123.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.026260… |
| 'Workspace.trenjay123.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7596539… |
| 'Workspace.trenjay123.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.trenjay123.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.6962258… |
| 'Workspace.trenjay123.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.4999999… |
| 'Workspace.trenjay123.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.trenjay123.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.680857… |
| 'Workspace.trenjay123.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -3.623962… |
| 'Workspace.trenjay123.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -7.261522… |
| 'Workspace.trenjay123.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.trenjay123.RightFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8361780… |
| 'Workspace.trenjay123.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.004554… |
| 'Workspace.trenjay123.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.004554… |
| 'Workspace.trenjay123.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6933399… |
| 'Workspace.trenjay123.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.077919… |
| 'Workspace.trenjay123.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0540800… |
| 'Workspace.trenjay123.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6270951… |
| 'Workspace.trenjay123.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.080102… |
| 'Workspace.trenjay123.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1268978… |
| 'Workspace.trenjay123.RightLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7419999… |
| 'Workspace.trenjay123.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0023289… |
| 'Workspace.trenjay123.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0053289… |
| 'Workspace.trenjay123.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5698585… |
| 'Workspace.trenjay123.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0374107… |
| 'Workspace.trenjay123.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.147589… |
| 'Workspace.trenjay123.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.281589… |
| 'Workspace.trenjay123.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.281589… |
| 'Workspace.trenjay123.RightUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7596539… |
| 'Workspace.trenjay123.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0755339… |
| 'Workspace.trenjay123.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0265339… |
| 'Workspace.trenjay123.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.trenjay123.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.trenjay123.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.trenjay123.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.757948… |
| 'Workspace.trenjay123.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.911444… |
| 'Workspace.trenjay123.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.911444… |
| 'Workspace.trenjay123.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.058594… |
| 'Workspace.trenjay123.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.trenjay123.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.8154158… |
| 'Workspace.trenjay123.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7579999… |
| 'Workspace.trenjay123.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9109999… |
| 'Workspace.trenjay123.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9109999… |
| 'Workspace.trenjay123.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |

## Numeric argument positions

- Every numeric argument position observed on any remote, with its
- observed range and how often the value moved up or down.

No numeric argument position was observed.

