--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.DynamicThumbstick
	Method:      executor decompile()
	DebugId:     0_61350
]]
-- decompilation panicked