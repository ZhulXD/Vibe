--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ClassicCamera
	Method:      executor decompile()
	DebugId:     1_13874
]]
-- decompilation panicked