--[[
	AIDump decompilation output for LocalScript
	Script:      Players.SeoulKD.PlayerGui.BobuxDonationGui.Donation Script
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Legacy
	DebugId:     1_51768
]]
-- decompilation panicked