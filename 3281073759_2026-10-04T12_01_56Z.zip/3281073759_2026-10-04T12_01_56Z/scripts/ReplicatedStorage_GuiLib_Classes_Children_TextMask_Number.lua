--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Classes.Children.TextMask.Number
	Method:      executor decompile()
	DebugId:     1_12791
]]
-- decompilation panicked