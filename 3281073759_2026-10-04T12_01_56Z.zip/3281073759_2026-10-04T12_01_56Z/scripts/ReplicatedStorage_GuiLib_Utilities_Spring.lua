--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Utilities.Spring
	Method:      executor decompile()
	DebugId:     1_12778
]]
-- decompilation panicked