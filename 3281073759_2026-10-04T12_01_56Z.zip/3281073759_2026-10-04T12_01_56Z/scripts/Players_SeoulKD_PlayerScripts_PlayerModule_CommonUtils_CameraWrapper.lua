--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper
	Method:      executor decompile()
	DebugId:     0_61357
]]
-- decompilation panicked