--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore
	Method:      executor decompile()
	DebugId:     0_61323
]]
-- decompilation panicked