--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCamera
	Method:      executor decompile()
	DebugId:     1_13882
]]
-- decompilation panicked