--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec
	Method:      executor decompile()
	DebugId:     0_61358
]]
-- decompilation panicked