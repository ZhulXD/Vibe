--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.LazyLoader
	Method:      executor decompile()
	DebugId:     1_12779
]]
-- decompilation panicked