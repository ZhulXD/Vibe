--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector
	Method:      executor decompile()
	DebugId:     1_13886
]]
-- decompilation panicked