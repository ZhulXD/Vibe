--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraUtils
	Method:      executor decompile()
	DebugId:     1_13875
]]
-- decompilation panicked