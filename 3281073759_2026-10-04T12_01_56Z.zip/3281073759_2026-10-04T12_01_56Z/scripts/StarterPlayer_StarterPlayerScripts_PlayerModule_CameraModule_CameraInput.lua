--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraInput
	Method:      executor decompile()
	DebugId:     1_13891
]]
-- decompilation panicked