--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CharacterUtil
	Method:      executor decompile()
	DebugId:     1_13878
]]
-- decompilation panicked