--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.BaseCamera
	Method:      executor decompile()
	DebugId:     1_13912
]]
-- decompilation panicked