--[[
	AIDump decompilation output for LocalScript
	Script:      Players.SeoulKD.PlayerGui.GamepassGui.Gamepass Script
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Legacy
	DebugId:     1_51788
]]
-- decompilation panicked