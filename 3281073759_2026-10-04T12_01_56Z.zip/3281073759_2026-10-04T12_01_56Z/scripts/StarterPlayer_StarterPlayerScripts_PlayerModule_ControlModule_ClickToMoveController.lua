--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.ClickToMoveController
	Method:      executor decompile()
	DebugId:     1_13894
]]
-- decompilation panicked