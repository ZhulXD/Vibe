--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.DynamicThumbstick
	Method:      executor decompile()
	DebugId:     1_13913
]]
-- decompilation panicked