--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig
	Method:      executor decompile()
	DebugId:     1_13889
]]
-- decompilation panicked