--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec
	Method:      executor decompile()
	DebugId:     0_61328
]]
-- decompilation panicked