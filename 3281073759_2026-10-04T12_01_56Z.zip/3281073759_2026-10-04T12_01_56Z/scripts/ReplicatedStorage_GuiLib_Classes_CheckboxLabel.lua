--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Classes.CheckboxLabel
	Method:      executor decompile()
	DebugId:     1_12782
]]
-- decompilation panicked