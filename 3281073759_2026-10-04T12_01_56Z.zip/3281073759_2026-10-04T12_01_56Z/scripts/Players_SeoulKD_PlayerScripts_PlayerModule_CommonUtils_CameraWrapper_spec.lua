--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec
	Method:      executor decompile()
	DebugId:     0_61356
]]
-- decompilation panicked