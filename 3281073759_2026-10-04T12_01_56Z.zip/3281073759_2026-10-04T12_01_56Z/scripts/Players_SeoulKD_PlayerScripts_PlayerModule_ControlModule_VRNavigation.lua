--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.VRNavigation
	Method:      executor decompile()
	DebugId:     0_61340
]]
-- decompilation panicked