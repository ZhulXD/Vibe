--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRVehicleCamera
	Method:      executor decompile()
	DebugId:     1_13879
]]
-- decompilation panicked