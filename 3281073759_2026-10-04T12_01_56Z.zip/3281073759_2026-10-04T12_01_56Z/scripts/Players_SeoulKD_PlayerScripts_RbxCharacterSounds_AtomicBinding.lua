--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.RbxCharacterSounds.AtomicBinding
	Method:      executor decompile()
	DebugId:     0_61295
]]
-- decompilation panicked