--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec
	Method:      executor decompile()
	DebugId:     1_13916
]]
-- decompilation panicked