--[[
	AIDump decompilation output for LocalScript
	Script:      Workspace.I_lovecelebrations.Animate
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Legacy
	DebugId:     1_48933
]]
-- decompilation panicked