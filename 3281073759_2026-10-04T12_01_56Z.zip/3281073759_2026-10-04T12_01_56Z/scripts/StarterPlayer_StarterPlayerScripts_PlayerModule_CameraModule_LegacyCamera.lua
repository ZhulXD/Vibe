--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.LegacyCamera
	Method:      executor decompile()
	DebugId:     1_13904
]]
-- decompilation panicked