--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.ConnectionUtil
	Method:      executor decompile()
	DebugId:     1_13903
]]
-- decompilation panicked