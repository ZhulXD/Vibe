--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.Poppercam
	Method:      executor decompile()
	DebugId:     1_13897
]]
-- decompilation panicked