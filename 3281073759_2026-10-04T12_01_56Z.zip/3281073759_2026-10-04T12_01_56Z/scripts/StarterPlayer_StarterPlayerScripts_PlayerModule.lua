--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule
	Method:      executor decompile()
	DebugId:     1_13872
]]
-- decompilation panicked