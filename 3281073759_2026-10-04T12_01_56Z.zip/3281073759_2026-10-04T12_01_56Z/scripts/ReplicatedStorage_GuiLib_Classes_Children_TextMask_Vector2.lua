--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Classes.Children.TextMask.Vector2
	Method:      executor decompile()
	DebugId:     1_12793
]]
-- decompilation panicked