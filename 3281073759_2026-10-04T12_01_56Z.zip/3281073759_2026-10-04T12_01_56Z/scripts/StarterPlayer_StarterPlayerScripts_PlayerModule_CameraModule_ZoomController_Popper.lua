--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ZoomController.Popper
	Method:      executor decompile()
	DebugId:     1_13900
]]
-- decompilation panicked