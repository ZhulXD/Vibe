--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.Triangle
	Method:      executor decompile()
	DebugId:     1_12790
]]
-- decompilation panicked