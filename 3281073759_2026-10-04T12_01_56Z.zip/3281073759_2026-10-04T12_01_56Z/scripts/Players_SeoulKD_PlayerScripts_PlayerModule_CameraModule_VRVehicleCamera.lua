--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRVehicleCamera
	Method:      executor decompile()
	DebugId:     0_61319
]]
-- decompilation panicked