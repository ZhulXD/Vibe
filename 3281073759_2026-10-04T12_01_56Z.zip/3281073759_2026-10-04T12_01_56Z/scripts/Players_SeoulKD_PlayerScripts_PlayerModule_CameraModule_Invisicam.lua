--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.Invisicam
	Method:      executor decompile()
	DebugId:     0_61326
]]
-- decompilation panicked