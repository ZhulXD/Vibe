--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera
	Method:      executor decompile()
	DebugId:     0_61321
]]
-- decompilation panicked