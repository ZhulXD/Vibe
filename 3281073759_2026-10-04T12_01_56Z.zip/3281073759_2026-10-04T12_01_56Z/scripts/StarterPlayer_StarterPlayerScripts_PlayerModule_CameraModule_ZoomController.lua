--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ZoomController
	Method:      executor decompile()
	DebugId:     1_13899
]]
-- decompilation panicked