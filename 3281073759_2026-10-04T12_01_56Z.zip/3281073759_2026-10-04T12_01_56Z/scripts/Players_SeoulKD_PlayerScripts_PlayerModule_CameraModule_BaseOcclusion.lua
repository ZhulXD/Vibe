--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.BaseOcclusion
	Method:      executor decompile()
	DebugId:     0_61327
]]
-- decompilation panicked