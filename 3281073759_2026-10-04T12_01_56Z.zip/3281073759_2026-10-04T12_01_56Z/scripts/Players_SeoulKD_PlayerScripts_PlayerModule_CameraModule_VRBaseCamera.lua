--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRBaseCamera
	Method:      executor decompile()
	DebugId:     0_61318
]]
-- decompilation panicked