--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.BaseCamera
	Method:      executor decompile()
	DebugId:     0_61338
]]
-- decompilation panicked