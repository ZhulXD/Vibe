--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.TouchJump
	Method:      executor decompile()
	DebugId:     1_13906
]]
-- decompilation panicked