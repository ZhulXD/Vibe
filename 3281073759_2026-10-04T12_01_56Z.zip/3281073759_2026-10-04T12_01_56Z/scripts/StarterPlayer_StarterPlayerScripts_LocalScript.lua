--[[
	AIDump decompilation output for LocalScript
	Script:      StarterPlayer.StarterPlayerScripts.LocalScript
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Legacy
	DebugId:     1_12069
]]
-- decompilation panicked