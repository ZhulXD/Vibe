--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera
	Method:      executor decompile()
	DebugId:     1_13884
]]
-- decompilation panicked