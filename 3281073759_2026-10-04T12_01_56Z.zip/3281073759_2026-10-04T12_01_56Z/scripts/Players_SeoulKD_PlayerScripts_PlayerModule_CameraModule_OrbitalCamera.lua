--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.OrbitalCamera
	Method:      executor decompile()
	DebugId:     0_61336
]]
-- decompilation panicked