--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.Invisicam
	Method:      executor decompile()
	DebugId:     1_13887
]]
-- decompilation panicked