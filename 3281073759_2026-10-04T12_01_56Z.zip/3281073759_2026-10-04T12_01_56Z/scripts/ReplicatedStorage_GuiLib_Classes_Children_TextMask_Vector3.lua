--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Classes.Children.TextMask.Vector3
	Method:      executor decompile()
	DebugId:     1_12794
]]
-- decompilation panicked