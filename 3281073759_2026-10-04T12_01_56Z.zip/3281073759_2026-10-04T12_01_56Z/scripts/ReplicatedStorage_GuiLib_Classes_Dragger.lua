--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Classes.Dragger
	Method:      executor decompile()
	DebugId:     1_12780
]]
-- decompilation panicked