--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ClassicCamera
	Method:      executor decompile()
	DebugId:     0_61316
]]
-- decompilation panicked