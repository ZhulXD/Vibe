--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Classes.RadialMenu
	Method:      executor decompile()
	DebugId:     1_12787
]]
-- decompilation panicked