--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface
	Method:      executor decompile()
	DebugId:     1_13917
]]
-- decompilation panicked