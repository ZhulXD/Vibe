--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.getPublicData
	Method:      executor decompile()
	DebugId:     1_12776
]]
-- decompilation panicked