--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Classes.Slider
	Method:      executor decompile()
	DebugId:     1_12785
]]
-- decompilation panicked