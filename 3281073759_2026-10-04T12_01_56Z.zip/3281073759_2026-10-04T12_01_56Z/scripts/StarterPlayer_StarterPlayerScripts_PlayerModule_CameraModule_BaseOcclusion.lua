--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.BaseOcclusion
	Method:      executor decompile()
	DebugId:     1_13888
]]
-- decompilation panicked