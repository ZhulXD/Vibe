--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.CONSTANTS
	Method:      executor decompile()
	DebugId:     1_12788
]]
-- decompilation panicked