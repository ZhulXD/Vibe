--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay
	Method:      executor decompile()
	DebugId:     1_13902
]]
-- decompilation panicked