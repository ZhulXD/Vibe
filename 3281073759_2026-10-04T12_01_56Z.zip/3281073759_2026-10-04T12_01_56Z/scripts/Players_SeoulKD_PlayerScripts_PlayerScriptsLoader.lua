--[[
	AIDump decompilation output for LocalScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerScriptsLoader
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Legacy
	DebugId:     0_61359
]]
-- decompilation panicked