--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.RbxCharacterSounds.AtomicBinding
	Method:      executor decompile()
	DebugId:     1_13871
]]
-- decompilation panicked