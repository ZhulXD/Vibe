--[[
	AIDump decompilation output for LocalScript
	Script:      Players.SeoulKD.PlayerScripts.RbxCharacterSounds
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Legacy
	DebugId:     0_61294
]]
-- decompilation panicked