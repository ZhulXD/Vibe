--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.FlagUtil
	Method:      executor decompile()
	DebugId:     1_13907
]]
-- decompilation panicked