--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Classes.Children.TextMask.String
	Method:      executor decompile()
	DebugId:     1_12792
]]
-- decompilation panicked