--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.Poppercam
	Method:      executor decompile()
	DebugId:     0_61331
]]
-- decompilation panicked