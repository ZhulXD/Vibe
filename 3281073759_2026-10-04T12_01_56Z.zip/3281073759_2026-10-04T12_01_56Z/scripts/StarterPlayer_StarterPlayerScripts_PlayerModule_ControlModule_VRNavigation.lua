--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.VRNavigation
	Method:      executor decompile()
	DebugId:     1_13881
]]
-- decompilation panicked