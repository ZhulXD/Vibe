--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Classes.Dropdown
	Method:      executor decompile()
	DebugId:     1_12786
]]
-- decompilation panicked