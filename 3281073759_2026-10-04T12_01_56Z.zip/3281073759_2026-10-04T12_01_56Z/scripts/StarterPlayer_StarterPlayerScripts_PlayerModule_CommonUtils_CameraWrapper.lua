--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CameraWrapper
	Method:      executor decompile()
	DebugId:     1_13915
]]
-- decompilation panicked