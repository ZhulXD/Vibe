--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraToggleStateController
	Method:      executor decompile()
	DebugId:     0_61324
]]
-- decompilation panicked