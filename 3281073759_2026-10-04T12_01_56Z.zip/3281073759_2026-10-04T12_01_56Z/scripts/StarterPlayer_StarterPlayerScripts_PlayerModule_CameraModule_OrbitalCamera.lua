--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.OrbitalCamera
	Method:      executor decompile()
	DebugId:     1_13905
]]
-- decompilation panicked