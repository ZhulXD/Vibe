--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig
	Method:      executor decompile()
	DebugId:     0_61322
]]
-- decompilation panicked