--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraInput
	Method:      executor decompile()
	DebugId:     0_61329
]]
-- decompilation panicked