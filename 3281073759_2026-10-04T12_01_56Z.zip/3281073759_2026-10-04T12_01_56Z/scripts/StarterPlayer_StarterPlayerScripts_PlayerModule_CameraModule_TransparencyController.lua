--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.TransparencyController
	Method:      executor decompile()
	DebugId:     1_13901
]]
-- decompilation panicked