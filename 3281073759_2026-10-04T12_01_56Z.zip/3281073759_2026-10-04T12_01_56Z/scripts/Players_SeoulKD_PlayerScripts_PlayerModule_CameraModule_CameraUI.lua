--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraUI
	Method:      executor decompile()
	DebugId:     0_61330
]]
-- decompilation panicked