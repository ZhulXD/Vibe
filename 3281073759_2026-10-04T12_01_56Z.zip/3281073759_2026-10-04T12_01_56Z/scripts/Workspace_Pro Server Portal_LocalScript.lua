--[[
	AIDump decompilation output for Script
	Script:      Workspace.Pro Server Portal.LocalScript
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Client
	DebugId:     1_13284
]]
-- decompilation panicked