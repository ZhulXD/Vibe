--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRBaseCamera
	Method:      executor decompile()
	DebugId:     1_13876
]]
-- decompilation panicked