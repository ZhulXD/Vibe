--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.PathDisplay
	Method:      executor decompile()
	DebugId:     1_13895
]]
-- decompilation panicked