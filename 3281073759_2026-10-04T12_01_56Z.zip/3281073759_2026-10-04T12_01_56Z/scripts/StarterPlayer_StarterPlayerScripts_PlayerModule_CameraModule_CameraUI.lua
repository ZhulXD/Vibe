--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraUI
	Method:      executor decompile()
	DebugId:     1_13893
]]
-- decompilation panicked