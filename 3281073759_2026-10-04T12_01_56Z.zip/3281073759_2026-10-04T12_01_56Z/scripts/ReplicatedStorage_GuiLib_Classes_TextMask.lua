--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Classes.TextMask
	Method:      executor decompile()
	DebugId:     1_12781
]]
-- decompilation panicked