--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraToggleStateController
	Method:      executor decompile()
	DebugId:     1_13885
]]
-- decompilation panicked