--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.DrawCamera
	Method:      executor decompile()
	DebugId:     1_12797
]]
-- decompilation panicked