--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.TouchThumbstick
	Method:      executor decompile()
	DebugId:     1_13896
]]
-- decompilation panicked