--[[
	AIDump decompilation output for LocalScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerScriptsLoader
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Legacy
	DebugId:     1_13911
]]
-- decompilation panicked