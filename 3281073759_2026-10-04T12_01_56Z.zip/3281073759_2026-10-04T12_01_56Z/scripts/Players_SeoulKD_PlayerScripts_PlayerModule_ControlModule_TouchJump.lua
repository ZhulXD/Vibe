--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.TouchJump
	Method:      executor decompile()
	DebugId:     0_61347
]]
-- decompilation panicked