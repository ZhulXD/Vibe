--[[
	AIDump decompilation output for LocalScript
	Script:      Workspace.SeoulKD.Animate
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Legacy
	DebugId:     1_51148
]]
-- decompilation panicked