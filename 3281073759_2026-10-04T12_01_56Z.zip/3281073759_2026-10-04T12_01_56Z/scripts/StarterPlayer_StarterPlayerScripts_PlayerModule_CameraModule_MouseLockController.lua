--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.MouseLockController
	Method:      executor decompile()
	DebugId:     1_13910
]]
-- decompilation panicked