--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec
	Method:      executor decompile()
	DebugId:     1_13914
]]
-- decompilation panicked