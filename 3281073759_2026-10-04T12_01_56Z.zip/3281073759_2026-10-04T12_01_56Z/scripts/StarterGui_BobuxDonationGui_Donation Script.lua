--[[
	AIDump decompilation output for LocalScript
	Script:      StarterGui.BobuxDonationGui.Donation Script
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Legacy
	DebugId:     1_12070
]]
-- decompilation panicked