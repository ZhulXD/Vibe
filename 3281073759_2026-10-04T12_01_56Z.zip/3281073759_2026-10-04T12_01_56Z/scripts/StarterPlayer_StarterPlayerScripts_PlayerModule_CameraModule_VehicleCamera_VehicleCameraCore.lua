--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore
	Method:      executor decompile()
	DebugId:     1_13892
]]
-- decompilation panicked