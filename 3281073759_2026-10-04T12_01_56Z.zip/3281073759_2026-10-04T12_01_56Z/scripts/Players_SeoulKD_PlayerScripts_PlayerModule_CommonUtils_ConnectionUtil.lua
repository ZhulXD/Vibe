--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil
	Method:      executor decompile()
	DebugId:     0_61354
]]
-- decompilation panicked