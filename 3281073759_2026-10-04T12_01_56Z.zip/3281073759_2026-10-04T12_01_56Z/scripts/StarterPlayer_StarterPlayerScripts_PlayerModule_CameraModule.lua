--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule
	Method:      executor decompile()
	DebugId:     1_13873
]]
-- decompilation panicked