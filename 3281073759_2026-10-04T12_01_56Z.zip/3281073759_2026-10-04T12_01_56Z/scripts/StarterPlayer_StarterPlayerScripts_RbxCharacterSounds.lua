--[[
	AIDump decompilation output for LocalScript
	Script:      StarterPlayer.StarterPlayerScripts.RbxCharacterSounds
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Legacy
	DebugId:     1_13870
]]
-- decompilation panicked