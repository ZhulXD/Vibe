--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec
	Method:      executor decompile()
	DebugId:     1_13890
]]
-- decompilation panicked