--[[
	AIDump decompilation output for ModuleScript
	Script:      ReplicatedStorage.GuiLib.Classes.Children.TextMask.Integer
	Method:      executor decompile()
	DebugId:     1_12795
]]
-- decompilation panicked