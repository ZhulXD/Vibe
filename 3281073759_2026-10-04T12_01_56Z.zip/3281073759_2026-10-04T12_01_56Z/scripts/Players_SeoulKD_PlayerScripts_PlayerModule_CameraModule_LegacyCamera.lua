--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.LegacyCamera
	Method:      executor decompile()
	DebugId:     0_61335
]]
-- decompilation panicked