--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.TransparencyController
	Method:      executor decompile()
	DebugId:     0_61334
]]
-- decompilation panicked