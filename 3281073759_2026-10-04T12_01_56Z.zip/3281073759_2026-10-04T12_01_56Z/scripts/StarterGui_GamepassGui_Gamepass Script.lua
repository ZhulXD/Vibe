--[[
	AIDump decompilation output for LocalScript
	Script:      StarterGui.GamepassGui.Gamepass Script
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Legacy
	DebugId:     1_12071
]]
-- decompilation panicked