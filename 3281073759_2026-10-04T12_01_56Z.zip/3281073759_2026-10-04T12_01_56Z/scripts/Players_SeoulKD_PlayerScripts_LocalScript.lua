--[[
	AIDump decompilation output for LocalScript
	Script:      Players.SeoulKD.PlayerScripts.LocalScript
	Method:      executor decompile()
	RunContext:  Enum.RunContext.Legacy
	DebugId:     0_61293
]]
-- decompilation panicked