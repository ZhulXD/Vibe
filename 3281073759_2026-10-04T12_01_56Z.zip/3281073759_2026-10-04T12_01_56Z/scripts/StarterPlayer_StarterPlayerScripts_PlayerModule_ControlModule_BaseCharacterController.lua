--[[
	AIDump decompilation output for ModuleScript
	Script:      StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.BaseCharacterController
	Method:      executor decompile()
	DebugId:     1_13908
]]
-- decompilation panicked