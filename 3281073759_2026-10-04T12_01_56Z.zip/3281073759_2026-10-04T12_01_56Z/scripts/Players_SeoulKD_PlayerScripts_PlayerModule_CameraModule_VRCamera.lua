--[[
	AIDump decompilation output for ModuleScript
	Script:      Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCamera
	Method:      executor decompile()
	DebugId:     0_61320
]]
-- decompilation panicked