# 06 - Observed state

---

| Measure | Count |
| --- | --- |
| Attribute cells tracked | 0 |
| Value objects tracked | 0 |
| Recorded transitions | 0 |
| Traffic events observed | 0 |
| Instances watched | 0 |

## Attributes

No attribute was observed on any watched instance.

## Value objects

No value object was observed.

## Numeric argument positions

- Every numeric argument position observed on any remote, with its
- observed range and how often the value moved up or down.

No numeric argument position was observed.

