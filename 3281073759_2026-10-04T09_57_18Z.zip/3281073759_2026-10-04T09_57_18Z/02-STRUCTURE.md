# 02 - Structure

---

Instances walked: 1 of at most 8000 (budget).
Nil-parented instances included: 0.

- `?` after a property value means no default is known for that
- property, so equality with the default could not be checked.

## Instance tree

```text

```
`- Ugc (DataModel)
```text

```

## Instance census

| Class | Count | Share |
| --- | :---: | :---: |
| 'DataModel' | 1 | 100% |

