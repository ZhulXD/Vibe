# AIDump self-test

Generated: 2026-10-04T09:57:35Z

**10 passed, 3 failed, 13 total**

| Check | Result | Detail |
| --- | --- | --- |
| ring bounds head and tail | pass | ok |
| string quoting survives control characters | pass | ok |
| value serialiser emits compilable Luau | FAIL | Invalid number of arguments: 6 |
| cycle detection terminates | pass | ok |
| packed argument arity is preserved | pass | ok |
| markdown cells escape table syntax | pass | ok |
| fact linter rejects an assertion | pass | ok |
| fact linter accepts game vocabulary in values | pass | ok |
| service paths resolve | FAIL | dvscnLzvnavxJRDJgyxdIlBNC:7851: game path wrong: nil |
| json output is valid | FAIL | dvscnLzvnavxJRDJgyxdIlBNC:7866: JSONDecode rejected the output: dvscnLzvnavxJRDJgyxdIlBNC:7864: attempt to call a nil value |
| filesystem write and read back | pass | ok |
| bytecode parser handles a live script | pass | bytecode version 3, 1 protos, 160 bytes |
| number formatting round trips | pass | ok |

Failing checks indicate a defect in this script or an executor
capability that differs from the assumption made. Both are recorded
rather than hidden.
