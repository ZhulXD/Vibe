# MinHub bridge: polls for a signal file created by PythonSDLActivity to open/close URM

init python:
    import os as _mh_os

    # True only while we are blocked inside x52URM.Open()() / renpy.run(Show('URM_main'))
    _mh_urm_is_open = False

    def _minhub_poll_urm():
        global _mh_urm_is_open
        _signal = _mh_os.path.join(renpy.config.gamedir, '.minhub_urm_open')
        if not _mh_os.path.exists(_signal):
            return
        try:
            _mh_os.remove(_signal)
        except Exception:
            pass
        if renpy.get_screen('URM_main') is not None:
            renpy.hide_screen('URM_main')
            if _mh_urm_is_open:
                # We are inside renpy.run(Show('URM_main')).
                # Returning non-None ends that interaction, closing URM cleanly.
                return True
            # else: URM_main was shown as an overlay inside the game's own interaction
            # (e.g. renpy.input is running). Just hide the screen — do NOT return True
            # or we would end the game's interaction and corrupt its return value.
        elif not _mh_urm_is_open:
            # URM not open and we are not already opening it — open it now
            _mh_urm_is_open = True
            try:
                x52URM.Open()()
            finally:
                _mh_urm_is_open = False

# Timer screen with no visuals — just polls the signal file every 0.3 s
screen _minhub_urm_poll:
    timer 0.3 action Function(_minhub_poll_urm) repeat True

# Runs at init 1000 (after URM's init 999).
init 1000 python:
    if '_minhub_urm_poll' not in renpy.config.overlay_screens:
        renpy.config.overlay_screens.append('_minhub_urm_poll')

    # MinHub red-on-black color theme matching the app palette
    _mh_theme = {
        'text':       '#F0F0F6',  # text_pri
        'primary':    '#EF4444',  # accent red
        'secondary':  '#B91C1C',  # darker red
        'tertiary':   '#18181f',  # s2 card bg
        'background': '#09090d',  # bg near-black
    }
    # Register so users can also pick it from URM Options > Theme
    x52URM.availableThemes['MinHub'] = _mh_theme

    # Patch afterLoad so that:
    #   - URM's floating overlay icon and quickmenu bar are hidden
    #   - MinHub theme is applied (unless user already chose a custom theme)
    # afterLoad fires via after_load_callbacks (save load) AND via onLabelCalled 'start' (new game).
    _mh_orig_after_load = x52URM.afterLoad

    def _mh_after_load():
        _mh_orig_after_load()

        # Apply MinHub theme when user hasn't overridden it
        if x52URM.Settings.theme in ('Default', None):
            try:
                x52URM.Theme.setTheme(_mh_theme)
            except Exception:
                pass

        # Disable quickmenu bar
        x52URM.Settings.quickmenuEnabled = False
        try:
            renpy.config.overlay_screens.remove('URM_quickmenu')
        except (ValueError, AttributeError):
            pass

        # Hide the floating "52" overlay icon
        try:
            renpy.hide_screen('URM_overlay')
        except Exception:
            pass

    # Replace in after_load_callbacks (handles save-load path)
    try:
        _mh_i = renpy.config.after_load_callbacks.index(_mh_orig_after_load)
        renpy.config.after_load_callbacks[_mh_i] = _mh_after_load
    except ValueError:
        renpy.config.after_load_callbacks.append(_mh_after_load)

    # Replace in LabelMon.onLabelCalled (handles new-game 'start' label path)
    _mh_orig_on_label = x52URM.onLabelCalled
    def _mh_on_label(label, called):
        if label == 'start':
            _mh_after_load()
        else:
            _mh_orig_on_label(label, called)
    x52URM.onLabelCalled = _mh_on_label
    try:
        _mh_j = x52URM.LabelMon.onLabelCalled.index(_mh_orig_on_label)
        x52URM.LabelMon.onLabelCalled[_mh_j] = _mh_on_label
    except (ValueError, AttributeError):
        x52URM.LabelMon.onLabelCalled.append(_mh_on_label)
