# 02 - Structure

---

Instances walked: 8000 of at most 8000 (budget).
Nil-parented instances included: 0.

- `?` after a property value means no default is known for that
- property, so equality with the default could not be checked.

## Instance tree

```text

```
`- Ugc (DataModel)
      Archivable = true  ?
      Capabilities = nil --[[unserialisable userdata: ]]  ?
      ClassName = "DataModel"  ?
      CreatorId = 38617013  ?
      CreatorType = Enum.CreatorType.User  ?
      DataCost = 264510  ?
      Environment = ""  ?
      GameId = 1182609799  ?
      GearGenreSetting = Enum.GearGenreSetting.AllGenres  ?
      Genre = Enum.Genre.All  ?
      IsPioneerBuild = false  ?
      IsSFFlagsLoaded = true  ?
      JobId = "9e93e9bf-35d2-4124-9edb-b339df8ac0a6"  ?
      MatchmakingType = Enum.MatchmakingType.Default  ?
      Name = "Ugc"  *
      PioneerSource = Enum.PioneerSource.Roblox  ?
      PlaceId = 3281073759  ?
      PlaceVersion = 169  ?
      RunService = :GetService("Run Service")game  ?
      Sandboxed = false  ?
      SourceAssetId = -1  ?
      UniqueId = "00000000-0000-0000-0000-000000000000"  ?
      VIPServerId = ""  ?
      VIPServerOwnerId = 0  ?
      Workspace = workspace  ?
      archivable = true  ?
      className = "DataModel"  ?
      lighting = :GetService("Lighting")game  ?
      workspace = workspace  ?
  |- Workspace (Workspace)
        AirDensity = 0.0012000000569969416  ?
        AirTurbulenceIntensity = 0  ?
        AllowThirdPartySales = false  ?
        Archivable = true  ?
        AuthorityMode = Enum.AuthorityMode.Automatic  ?
        AutoSimulate = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "Workspace"  ?
        ClientAnimatorThrottling = Enum.ClientAnimatorThrottlingMode.Default  ?
        DataCost = 107530  ?
        DistributedGameTime = 47.41250266227871  ?
        FallHeightEnabled = true  ?
        FallenPartsDestroyHeight = -500  ?
        FilteringEnabled = true  ?
        GlobalWind = nil --[[unserialisable vector: 3, 0, 6]]  ?
        Gravity = 196.1999969482422  *
        GravityDirection = nil --[[unserialisable vector: 0, -1, 0]]  ?
        InsertPoint = nil --[[unserialisable vector: 0, 0, 0]]  ?
        InterpolationThrottling = Enum.InterpolationThrottlingMode.Default  ?
        LevelOfDetail = Enum.ModelLevelOfDetail.Automatic  ?
        LuauTypeCheckMode = Enum.LuauTypeCheckMode.Default  ?
        ModelStreamingMode = Enum.ModelStreamingMode.Default  ?
        Name = "Workspace"
        PhysicsStepTime = 0.00038471000152640045  ?
        Retargeting = Enum.AnimatorRetargetingMode.Default  ?
        Sandboxed = false  ?
        SimulationRate = 1  ?
        SourceAssetId = -1  ?
        StreamingAdaptiveRadius = false  ?
        StreamingEnabled = false  ?
        Terrain = .Terrainworkspace  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        Wind = 0  ?
        WindDirection = nil --[[unserialisable vector: 0, 0, 0]]  ?
        WorldPivot = CFrame.new(0, 0, 0)  ?
        archivable = true  ?
        className = "Workspace"  ?
    |- Camera (Camera)
          Archivable = true  ?
          CFrame = CFrame.new(-4.071946620941162, 5.042729377746582, 22.05791473388672) * CFrame.fromEulerAng…  ?
          CameraSubject = .SeoulKD.Humanoidworkspace  ?
          CameraType = Enum.CameraType.Custom  ?
          Capabilities = nil --[[unserialisable userdata: ]]  ?
          ClassName = "Camera"  ?
          CoordinateFrame = CFrame.new(-4.071946620941162, 5.042729377746582, 22.05791473388672) * CFrame.fromEulerAng…  ?
          DataCost = 10  ?
          DiagonalFieldOfView = 127.76887512207031  ?
          FieldOfView = 70
          FieldOfViewMode = Enum.FieldOfViewMode.Vertical  ?
          Focus = CFrame.new(-4.071768283843994, 1.8075194358825684, 9.983833312988281)  ?
          HeadLocked = true  ?
          HeadScale = 1  ?
          MaxAxisFieldOfView = 102.44786071777344  ?
          Name = "Camera"
          NearPlaneZ = -0.10000000149011612  ?
          Sandboxed = false  ?
          SourceAssetId = -1  ?
          UniqueId = "00000000-0000-0000-0000-000000000000"  ?
          VRTiltAndRollEnabled = false  ?
          ViewportSize = Vector2.new(640, 360)  ?
          archivable = true  ?
          className = "Camera"  ?
          focus = CFrame.new(-4.071768283843994, 1.8075194358825684, 9.983833312988281)  ?
    |- Path (Model)
      |- Model (Model)
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -80.18643188476562, -2.57501220703125, -90.03902435302734]]  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[1] --[[Model is 1 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-80.18643188476562, -2.57501220703125, -90.03902435302734) * CFrame.fromEulerAn…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-80.18643188476562, -2.57501220703125, -90.03902435302734) * CFrame.fromEulerAn…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -81.01861572265625, -2.500012159347534, -89.76862335205078]…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[1] --[[Model is 1 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-81.01861572265625, -2.500012159347534, -89.76862335205078) * CFrame.fromEulerA…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-81.01861572265625, -2.500012159347534, -89.76862335205078) * CFrame.fromEulerA…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -87.34417724609375, -2.57501220703125, -105.0456314086914]]  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[2] --[[Model is 2 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-87.34417724609375, -2.57501220703125, -105.0456314086914) * CFrame.fromEulerAn…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-87.34417724609375, -2.57501220703125, -105.0456314086914) * CFrame.fromEulerAn…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -88.07805633544922, -2.500012159347534, -104.56903076171875…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[2] --[[Model is 2 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-88.07805633544922, -2.500012159347534, -104.56903076171875) * CFrame.fromEuler…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-88.07805633544922, -2.500012159347534, -104.56903076171875) * CFrame.fromEuler…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -98.14200592041016, -2.57501220703125, -117.68827056884766]…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[3] --[[Model is 3 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-98.14200592041016, -2.57501220703125, -117.68827056884766) * CFrame.fromEulerA…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-98.14200592041016, -2.57501220703125, -117.68827056884766) * CFrame.fromEulerA…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        `- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -98.72753143310547, -2.500012159347534, -117.03795623779297…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[3] --[[Model is 3 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-98.72753143310547, -2.500012159347534, -117.03795623779297) * CFrame.fromEuler…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-98.72753143310547, -2.500012159347534, -117.03795623779297) * CFrame.fromEuler…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
      |- Model (Model)
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -80.18643188476562, -2.57501220703125, -90.03902435302734]]  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[1] --[[Model is 1 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-80.18643188476562, -2.57501220703125, -90.03902435302734) * CFrame.fromEulerAn…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-80.18643188476562, -2.57501220703125, -90.03902435302734) * CFrame.fromEulerAn…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -81.01861572265625, -2.500012159347534, -89.76862335205078]…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[1] --[[Model is 1 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-81.01861572265625, -2.500012159347534, -89.76862335205078) * CFrame.fromEulerA…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-81.01861572265625, -2.500012159347534, -89.76862335205078) * CFrame.fromEulerA…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -87.34417724609375, -2.57501220703125, -105.0456314086914]]  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[2] --[[Model is 2 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-87.34417724609375, -2.57501220703125, -105.0456314086914) * CFrame.fromEulerAn…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-87.34417724609375, -2.57501220703125, -105.0456314086914) * CFrame.fromEulerAn…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -88.07805633544922, -2.500012159347534, -104.56903076171875…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[2] --[[Model is 2 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-88.07805633544922, -2.500012159347534, -104.56903076171875) * CFrame.fromEuler…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-88.07805633544922, -2.500012159347534, -104.56903076171875) * CFrame.fromEuler…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -98.14200592041016, -2.57501220703125, -117.68827056884766]…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[3] --[[Model is 3 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-98.14200592041016, -2.57501220703125, -117.68827056884766) * CFrame.fromEulerA…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-98.14200592041016, -2.57501220703125, -117.68827056884766) * CFrame.fromEulerA…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        `- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -98.72753143310547, -2.500012159347534, -117.03795623779297…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[3] --[[Model is 3 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-98.72753143310547, -2.500012159347534, -117.03795623779297) * CFrame.fromEuler…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-98.72753143310547, -2.500012159347534, -117.03795623779297) * CFrame.fromEuler…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
      |- Model (Model)
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -80.18643188476562, -2.57501220703125, -90.03902435302734]]  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[1] --[[Model is 1 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-80.18643188476562, -2.57501220703125, -90.03902435302734) * CFrame.fromEulerAn…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-80.18643188476562, -2.57501220703125, -90.03902435302734) * CFrame.fromEulerAn…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -81.01861572265625, -2.500012159347534, -89.76862335205078]…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[1] --[[Model is 1 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-81.01861572265625, -2.500012159347534, -89.76862335205078) * CFrame.fromEulerA…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-81.01861572265625, -2.500012159347534, -89.76862335205078) * CFrame.fromEulerA…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -87.34417724609375, -2.57501220703125, -105.0456314086914]]  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[2] --[[Model is 2 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-87.34417724609375, -2.57501220703125, -105.0456314086914) * CFrame.fromEulerAn…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-87.34417724609375, -2.57501220703125, -105.0456314086914) * CFrame.fromEulerAn…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -88.07805633544922, -2.500012159347534, -104.56903076171875…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[2] --[[Model is 2 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-88.07805633544922, -2.500012159347534, -104.56903076171875) * CFrame.fromEuler…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-88.07805633544922, -2.500012159347534, -104.56903076171875) * CFrame.fromEuler…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        |- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -98.14200592041016, -2.57501220703125, -117.68827056884766]…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[3] --[[Model is 3 of 3]]:GetChildren()[1] --[[Part is 1 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Dark grey")  ?
              CFrame = CFrame.new(-98.14200592041016, -2.57501220703125, -117.68827056884766) * CFrame.fromEulerA…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-98.14200592041016, -2.57501220703125, -117.68827056884766) * CFrame.fromEulerA…  ?
              ExtentsSize = nil --[[unserialisable vector: 1.75, 0.25, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
        `- Part (Part)
              Anchored = true  *
              Archivable = true  ?
              AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyCenterOfMass = nil --[[unserialisable vector: -98.72753143310547, -2.500012159347534, -117.03795623779297…  ?
              AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
              AssemblyMass = math.huge  ?
              AssemblyRootPart = .Path:GetChildren()[3] --[[Model is 3 of 3]]:GetChildren()[2] --[[Part is 2 of 2]]workspac…  ?
              AudioCanCollide = true  ?
              BackParamA = -0.5  ?
              BackParamB = 0.5  ?
              BackSurface = Enum.SurfaceType.Smooth  ?
              BackSurfaceInput = Enum.InputType.NoInput  ?
              BottomParamA = -0.5  ?
              BottomParamB = 0.5  ?
              BottomSurface = Enum.SurfaceType.Smooth  ?
              BottomSurfaceInput = Enum.InputType.NoInput  ?
              BrickColor = BrickColor.new("Pine Cone")  ?
              CFrame = CFrame.new(-98.72753143310547, -2.500012159347534, -117.03795623779297) * CFrame.fromEuler…  ?
              CanCollide = true
              CanQuery = true  ?
              CanTouch = true  ?
              Capabilities = nil --[[unserialisable userdata: ]]  ?
              CastShadow = true  ?
              CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
              ClassName = "Part"  ?
              CollisionGroup = "Default"  ?
              CollisionGroupId = 0  ?
              Color = Color3.new(0.42352941632270813, 0.3450980484485626, 0.29411765933036804)  ?
              CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
              DataCost = 20  ?
              Elasticity = 0.5  ?
              EnableFluidForces = true  ?
              ExtentsCFrame = CFrame.new(-98.72753143310547, -2.500012159347534, -117.03795623779297) * CFrame.fromEuler…  ?
              ExtentsSize = nil --[[unserialisable vector: 0.5, 0.6000000238418579, 17]]  ?
              FormFactor = Enum.FormFactor.Brick  ?
              Friction = 0.30000001192092896  ?
              FrontParamA = -0.5  ?
              FrontParamB = 0.5  ?
              FrontSurface = Enum.SurfaceType.Smooth  ?
              FrontSurfaceInput = Enum.InputType.NoInput  ?
              --[[ 43 more property/properties not shown ]]
      |- Pebble (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 2.488523483276367, -2.6844680309295654, -15.788663864135742…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Path:GetChildren()[1] --[[Pebble is 1 of 63]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark grey")  ?
            CFrame = CFrame.new(2.488523483276367, -2.6844680309295654, -15.788663864135742)  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Hull  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(2.488523483276367, -2.6844680309295654, -15.788663864135742)  ?
            ExtentsSize = nil --[[unserialisable vector: 1.2826735973358154, 0.05000000074505806, 1.4636240005493164…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Pebble (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: -11.073480606079102, -2.6844680309295654, -6.49752426147460…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Path:GetChildren()[2] --[[Pebble is 2 of 63]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark grey")  ?
            CFrame = CFrame.new(-11.073480606079102, -2.6844680309295654, -6.497524261474609) * CFrame.fromEule…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Hull  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5137255191802979, 0.45490196347236633, 0.43529412150382996)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(-11.073480606079102, -2.6844680309295654, -6.497524261474609) * CFrame.fromEule…  ?
            ExtentsSize = nil --[[unserialisable vector: 0.8476364612579346, 0.05000000074505806, 0.9755163192749023…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Part (Part)
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Path:GetChildren()[1] --[[Part is 1 of 57]]workspace  ?
            AudioCanCollide = true  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            CFrame = CFrame.new(0.05239677429199219, -3.20001220703125, 0.9837570190429688)  ?
            CastShadow = true  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Elasticity = 0.5  ?
            ExtentsSize = nil --[[unserialisable vector: 31.25, 1, 45]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurfaceInput = Enum.InputType.NoInput  ?
            LeftParamA = -0.5  ?
            LocalTransparencyModifier = 0  ?
            Locked = false  ?
            Mass = 984.375  ?
            Massless = false  ?
            Material = Enum.Material.SmoothPlastic  ?
            Name = "Part"  ?
            Position = nil --[[unserialisable vector: 0.05239677429199219, -3.20001220703125, 0.9837570190429688]…  ?
            ReceiveAge = 0  ?
            RightParamA = -0.5  ?
            RightParamB = 0.5  ?
            RightSurface = Enum.SurfaceType.Smooth  ?
            RootPriority = 0  ?
            RotVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            Rotation = nil --[[unserialisable vector: 0, 0, 0]]  ?
            Size = nil --[[unserialisable vector: 31.25, 1, 45]]  *
            TopSurface = Enum.SurfaceType.Smooth  ?
            TopSurfaceInput = Enum.InputType.NoInput  ?
            Velocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            archivable = true  ?
            --[[ 2 more property/properties not shown ]]
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      `- Part (Part)
    |- normalCanvas (Model)
      |- canvasFrame (Part)
      |- canvasFrame (Part)
      |- canvasFrame (Part)
      `- canvasFrame (Part)
    |- Lights (Model)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Lantern (Model)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        `- Part (Part)
      |- Low Poly Lantern (Model)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        `- Part (Part)
      |- Low Poly Lantern (Model)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        `- Part (Part)
      `- Low Poly Lantern (Model)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        |- Part (Part)
        |- Meshes/Booth42_Lantern2 (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Meshes/Booth42_Lantern (MeshPart)
        `- Part (Part)
    |- canvasPixels (Folder)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- Part (Part)
    |- :p (Model)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- POP (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        `- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
      |- Model (Model)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        `- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
      |- Model (Model)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        |- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
        `- Part (Part)
          |- PointLight (PointLight)
          |- PointLight (PointLight)
          `- PointLight (PointLight)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- Part (Part)
    |- BobuxDonation (Model)
      |- TitleOrder (IntValue)
      |- AllowTitles (BoolValue)
      |- TitleColor (Color3Value)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- ScoreBlock (Part)
        `- SurfaceGui (SurfaceGui)
          |- Category (Frame)
            |- AllTime (TextButton)
            |- Selection (Frame)
              `- UICorner (UICorner)
            `- UICorner (UICorner)
          |- DataLabel (TextLabel)
          `- LeaderboardAllTime (ScrollingFrame)
            |- UIListLayout (UIListLayout)
            |- Top001 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Name (TextLabel)
              |- Score (TextLabel)
              `- Position (TextLabel)
            |- Top003 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top004 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top002 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top005 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top006 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top007 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top008 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top009 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top010 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top011 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top012 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top013 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top014 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top015 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top016 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top017 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top018 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top019 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top020 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top021 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top022 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top023 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top024 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top025 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top026 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top027 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top028 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top029 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top030 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top031 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top032 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top033 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top034 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top035 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top036 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top037 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top038 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top039 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top040 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top041 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top042 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top043 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top044 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top045 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top046 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top047 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top048 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top049 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top050 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top051 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top052 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top053 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top054 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top055 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top056 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top057 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top058 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top059 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top060 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top061 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top062 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top063 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top064 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top065 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top066 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top067 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top068 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top069 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top070 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top071 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top072 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top073 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top074 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top075 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top076 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top077 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top078 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top079 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top080 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top081 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top082 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top083 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top084 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top085 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top086 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top087 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top088 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top089 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top090 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top091 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top092 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top093 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top094 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top095 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top096 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top097 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top098 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            |- Top099 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
            `- Top100 (Frame)
              |- Avatar (ImageLabel)
                |- UIAspectRatioConstraint (UIAspectRatioConstraint)
                `- UICorner (UICorner)
              |- DisplayName (TextLabel)
              |- Score (TextLabel)
              |- Name (TextLabel)
              `- Position (TextLabel)
      `- Part (Part)
    |- BobuxDonationFake (Model)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- ScoreBlock (Part)
    |- GamepassBoard (Model)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- ScoreBlock (Part)
      `- Part (Part)
    |- Fence (Model)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      `- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
    |- Ground (Model)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      `- Part (Part)
    |- Trees (Model)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- Low Poly Tree (Model)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        |- Low Poly Tree Top (MeshPart)
        |- Low Poly Tree Trunk (MeshPart)
        `- Low Poly Tree Top (MeshPart)
      |- LowPolyTree (Model)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        `- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
      |- LowPolyTree (Model)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        `- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
      |- LowPolyTree (Model)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        `- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
      |- LowPolyTree (Model)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          `- SakuraParticle (ParticleEmitter)
        |- MeshPart (MeshPart)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
          |- SakuraParticle (ParticleEmitter)
--[[ TRUNCATED: instance or line budget reached; see 07-COVERAGE.md ]]
```text

```

## Instance census

| Class | Count | Share |
| --- | :---: | :---: |
| 'Accessory' | 24 | 0.3% |
| 'AccessoryDescription' | 24 | 0.3% |
| 'Animation' | 167 | 2.1% |
| 'AnimationClipProvider' | 1 | 0% |
| 'AnimationConstraint' | 90 | 1.1% |
| 'Animator' | 6 | 0.1% |
| 'Attachment' | 344 | 4.3% |
| 'BallSocketConstraint' | 84 | 1.1% |
| 'BindableFunction' | 6 | 0.1% |
| 'BodyColors' | 6 | 0.1% |
| 'BodyPartDescription' | 36 | 0.5% |
| 'BoolValue' | 2 | 0% |
| 'CSGDictionaryService' | 1 | 0% |
| 'Camera' | 1 | 0% |
| 'CanvasGroup' | 11 | 0.1% |
| 'Chat' | 1 | 0% |
| 'Color3Value' | 2 | 0% |
| 'ContentProvider' | 1 | 0% |
| 'DataModel' | 1 | 0% |
| 'Decal' | 6 | 0.1% |
| 'FaceControls' | 6 | 0.1% |
| 'Folder' | 3 | 0% |
| 'Frame' | 284 | 3.6% |
| 'GuiService' | 1 | 0% |
| 'Highlight' | 1 | 0% |
| 'Humanoid' | 6 | 0.1% |
| 'HumanoidDescription' | 6 | 0.1% |
| 'ImageButton' | 2 | 0% |
| 'ImageLabel' | 222 | 2.8% |
| 'IntValue' | 3 | 0% |
| 'KeyframeSequenceProvider' | 1 | 0% |
| 'LocalScript' | 11 | 0.1% |
| 'LogService' | 1 | 0% |
| 'MarketplaceService' | 1 | 0% |
| 'MeshPart' | 577 | 7.2% |
| 'MicroProfilerService' | 1 | 0% |
| 'Model' | 134 | 1.7% |
| 'ModuleScript' | 45 | 0.6% |
| 'NoCollisionConstraint' | 114 | 1.4% |
| 'NonReplicatedCSGDictionaryService' | 1 | 0% |
| 'NumberValue' | 113 | 1.4% |
| 'Pants' | 5 | 0.1% |
| 'Part' | 1837 | 23% |
| 'ParticleEmitter' | 13 | 0.2% |
| 'Player' | 1 | 0% |
| 'PlayerGui' | 1 | 0% |
| 'PlayerScripts' | 1 | 0% |
| 'Players' | 1 | 0% |
| 'PointLight' | 21 | 0.3% |
| 'RemoteEvent' | 1 | 0% |
| 'RigidConstraint' | 24 | 0.3% |
| 'RunService' | 1 | 0% |
| 'RunningAverageItemDouble' | 2 | 0% |
| 'RunningAverageItemInt' | 42 | 0.5% |
| 'ScreenGui' | 13 | 0.2% |
| 'ScreenshotHud' | 1 | 0% |
| 'Script' | 8 | 0.1% |
| 'ScrollingFrame' | 4 | 0.1% |
| 'Seat' | 14 | 0.2% |
| 'Shirt' | 5 | 0.1% |
| 'ShirtGraphic' | 1 | 0% |
| 'Sound' | 54 | 0.7% |
| 'SoundService' | 1 | 0% |
| 'SpawnLocation' | 6 | 0.1% |
| 'Stats' | 1 | 0% |
| 'StatsItem' | 1136 | 14.2% |
| 'Status' | 6 | 0.1% |
| 'StringValue' | 194 | 2.4% |
| 'SurfaceAppearance' | 2 | 0% |
| 'SurfaceGui' | 4 | 0.1% |
| 'SurfaceLight' | 1 | 0% |
| 'Terrain' | 1 | 0% |
| 'TextBox' | 1 | 0% |
| 'TextButton' | 74 | 0.9% |
| 'TextLabel' | 916 | 11.5% |
| 'TimerService' | 1 | 0% |
| 'TotalCountTimeIntervalItem' | 36 | 0.5% |
| 'TouchTransmitter' | 1 | 0% |
| 'UIAspectRatioConstraint' | 218 | 2.7% |
| 'UICorner' | 311 | 3.9% |
| 'UIGradient' | 3 | 0% |
| 'UIGridLayout' | 2 | 0% |
| 'UIListLayout' | 20 | 0.3% |
| 'UIPadding' | 18 | 0.2% |
| 'UISizeConstraint' | 5 | 0.1% |
| 'UIStroke' | 11 | 0.1% |
| 'Vector3Value' | 461 | 5.8% |
| 'VideoCaptureService' | 1 | 0% |
| 'WedgePart' | 80 | 1% |
| 'Workspace' | 1 | 0% |
| 'WrapLayer' | 1 | 0% |
| 'WrapTarget' | 90 | 1.1% |

