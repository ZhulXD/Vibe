# 01 - Environment

---

## Place
| Field | Value |
| --- | --- |
| Game name | Ugc |
| PlaceId | 3281073759 |
| GameId | 1182609799 |
| JobId | 9e93e9bf-35d2-4124-9edb-b339df8ac0a6 |
| Local player | SeoulKD |
| Name source | game.Name (local read; no GetProductInfo call) |

## Executor capabilities

- Each row is the result of probing for the function, not of using it successfully.

### actor
| Function | State | Detail |
| --- | --- | --- |
| 'getactors' | available | present |
| 'run_on_actor' | available | present |

### attribution
| Function | State | Detail |
| --- | --- | --- |
| 'getcallingline' | absent | absent |
| 'getcallingscript' | available | present |
| 'getcallingsource' | absent | absent |
| 'getscriptfromthread' | available | present |

### capture
| Function | State | Detail |
| --- | --- | --- |
| 'fireclickdetector' | available | present |
| 'fireproximityprompt' | available | present |
| 'getcallbackvalue' | available | present |
| 'getconnections' | available | present |
| 'getnilinstances' | available | present |

### decompile
| Function | State | Detail |
| --- | --- | --- |
| 'decompile' | available | present |
| 'getscriptbytecode' | available | present |

### filesystem
| Function | State | Detail |
| --- | --- | --- |
| 'appendfile' | available | present |
| 'delfile' | available | present |
| 'isfile' | available | present |
| 'isfolder' | available | present |
| 'makefolder' | available | present |
| 'readfile' | available | present |
| 'writefile' | available | present |

### hooking
| Function | State | Detail |
| --- | --- | --- |
| 'getconstants' | available | present |
| 'getnamecallmethod' | available | present |
| 'getupvalues' | available | present |
| 'hookfunction' | available | present |
| 'hookmetamethod' | available | present |
| 'newcclosure' | available | present |

### identity
| Function | State | Detail |
| --- | --- | --- |
| 'identifyexecutor' | available | present |

### reflect
| Function | State | Detail |
| --- | --- | --- |
| 'gethiddenproperties' | available | present |
| 'getproperties' | available | present |

### thread
| Function | State | Detail |
| --- | --- | --- |
| 'getthreadidentity' | available | present |
| 'setthreadidentity' | available | present |

## Reflection metadata
| Field | Value |
| --- | --- |
| Source | probe |
| Detail | no ReflectionMetadata.xml on filesystem; using executor reflection or the embedded candidate list |
| Classes with properties | 0 |
| Enums with items | 0 |

