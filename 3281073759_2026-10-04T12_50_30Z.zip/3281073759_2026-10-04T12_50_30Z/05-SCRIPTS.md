# 05 - Scripts

---

| Measure | Count |
| --- | --- |
| Script instances found | 125 |
| Authored by the game | 125 |
| of those, readable by the client | 125 |
| Belonging to Roblox's own engine | 0 |
| Readable by the client, all scripts | 125 |
| Not client-side or unreadable | 0 |
| Skipped by the inventory cap | 0 |
| Skipped as duplicates | 0 |
| Had no readable debug id | 0 |

## Decompilation methods

| Method | Scripts |
| --- | :---: |
| bytecode-unsupported | 122 |
| executor-decompile | 1 |

- `source`: the script's own Source property was readable.
- `executor-decompile`: the executor's decompile() succeeded.
- `bytecode-disassembly`: bytecode parsed and disassembled.
- `bytecode-unsupported`: bytecode obtained but not parsed; raw hex written.
- `no-bytecode`: no bytecode available for this script.

## Script inventory and cross-reference

| Script path | Class | RunContext | Disabled | Decompiled by | Outgoing calls observed | Incoming handled | Unavailability reason |
| --- | --- | --- | :---: | --- | --- | --- | --- |
| 'LocalScript' | LocalScript | Enum.RunContext.Legacy | no | executor-decompile | — | — | — |
| 'LocalScript' | LocalScript | Enum.RunContext.Legacy | no | executor-decompile | — | — | — |
| 'LocalScript' | LocalScript | Enum.RunContext.Legacy | no | executor-decompile | — | — | — |
| 'Players.SeoulKD.PlayerGui.BobuxDonationGui.Donation Script' | LocalScript | Enum.RunContext.Legacy | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerGui.GamepassGui.Gamepass Script' | LocalScript | Enum.RunContext.Legacy | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.LocalScript' | LocalScript | Enum.RunContext.Legacy | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.BaseCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.BaseOcclusion' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraInput' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraToggleStateController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraUI' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraUtils' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ClassicCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.Invisicam' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.LegacyCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.MouseLockController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.OrbitalCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.Poppercam' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.TransparencyController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRBaseCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRVehicleCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ZoomController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ZoomController.Popper' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CharacterUtil' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.FlagUtil' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.BaseCharacterController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.ClickToMoveController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.DynamicThumbstick' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.Gamepad' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.Keyboard' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.PathDisplay' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.TouchJump' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.TouchThumbstick' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.VRNavigation' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.VehicleController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.PlayerScriptsLoader' | LocalScript | Enum.RunContext.Legacy | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.RbxCharacterSounds' | LocalScript | Enum.RunContext.Legacy | no | bytecode-unsupported | — | — | — |
| 'Players.SeoulKD.PlayerScripts.RbxCharacterSounds.AtomicBinding' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.DrawCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.CheckboxLabel' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.CONSTANTS' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.CreateRadial' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.Triangle' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.TextMask.Integer' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.TextMask.Number' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.TextMask.String' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.TextMask.Vector2' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Children.TextMask.Vector3' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Dragger' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Dropdown' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.RadialMenu' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.RadioButtonGroup' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.RadioButtonLabel' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.Slider' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Classes.TextMask' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Constructors.List' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.LazyLoader' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Utilities.Maid' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.GuiLib.Utilities.Spring' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'ReplicatedStorage.getPublicData' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterGui.BobuxDonationGui.Donation Script' | LocalScript | Enum.RunContext.Legacy | no | bytecode-unsupported | — | — | — |
| 'StarterGui.GamepassGui.Gamepass Script' | LocalScript | Enum.RunContext.Legacy | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.LocalScript' | LocalScript | Enum.RunContext.Legacy | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.BaseCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.BaseOcclusion' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraInput' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraToggleStateController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraUI' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraUtils' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ClassicCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.Invisicam' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.LegacyCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.MouseLockController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.OrbitalCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.Poppercam' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.TransparencyController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRBaseCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRVehicleCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ZoomController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ZoomController.Popper' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CameraWrapper' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CharacterUtil' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.ConnectionUtil' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.FlagUtil' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.BaseCharacterController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.ClickToMoveController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.DynamicThumbstick' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.Gamepad' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.Keyboard' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.PathDisplay' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.TouchJump' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.TouchThumbstick' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.VRNavigation' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.VehicleController' | ModuleScript | — | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.PlayerScriptsLoader' | LocalScript | Enum.RunContext.Legacy | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.RbxCharacterSounds' | LocalScript | Enum.RunContext.Legacy | no | bytecode-unsupported | — | — | — |
| 'StarterPlayer.StarterPlayerScripts.RbxCharacterSounds.AtomicBinding' | ModuleScript | — | no | bytecode-unsupported | — | — | — |

## Scripts with no observed traffic involvement (125)

- `LocalScript`
- `LocalScript`
- `LocalScript`
- `Players.SeoulKD.PlayerGui.BobuxDonationGui.Donation Script`
- `Players.SeoulKD.PlayerGui.GamepassGui.Gamepass Script`
- `Players.SeoulKD.PlayerScripts.LocalScript`
- `Players.SeoulKD.PlayerScripts.PlayerModule`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.BaseCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.BaseOcclusion`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraInput`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraToggleStateController`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraUI`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.CameraUtils`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ClassicCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.Invisicam`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.LegacyCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.MouseLockController`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.OrbitalCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.Poppercam`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.TransparencyController`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRBaseCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VRVehicleCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ZoomController`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.ZoomController.Popper`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.CharacterUtil`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec`
- `Players.SeoulKD.PlayerScripts.PlayerModule.CommonUtils.FlagUtil`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.BaseCharacterController`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.ClickToMoveController`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.DynamicThumbstick`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.Gamepad`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.Keyboard`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.PathDisplay`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.TouchJump`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.TouchThumbstick`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.VRNavigation`
- `Players.SeoulKD.PlayerScripts.PlayerModule.ControlModule.VehicleController`
- `Players.SeoulKD.PlayerScripts.PlayerScriptsLoader`
- `Players.SeoulKD.PlayerScripts.RbxCharacterSounds`
- `Players.SeoulKD.PlayerScripts.RbxCharacterSounds.AtomicBinding`
- `ReplicatedStorage.DrawCamera`
- `ReplicatedStorage.GuiLib.Classes.CheckboxLabel`
- `ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.CONSTANTS`
- `ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.CreateRadial`
- `ReplicatedStorage.GuiLib.Classes.Children.RadialMenu.Triangle`
- `ReplicatedStorage.GuiLib.Classes.Children.TextMask.Integer`
- `ReplicatedStorage.GuiLib.Classes.Children.TextMask.Number`
- `ReplicatedStorage.GuiLib.Classes.Children.TextMask.String`
- `ReplicatedStorage.GuiLib.Classes.Children.TextMask.Vector2`
- `ReplicatedStorage.GuiLib.Classes.Children.TextMask.Vector3`
- `ReplicatedStorage.GuiLib.Classes.Dragger`
- `ReplicatedStorage.GuiLib.Classes.Dropdown`
- `ReplicatedStorage.GuiLib.Classes.RadialMenu`
- `ReplicatedStorage.GuiLib.Classes.RadioButtonGroup`
- `ReplicatedStorage.GuiLib.Classes.RadioButtonLabel`
- `ReplicatedStorage.GuiLib.Classes.Slider`
- `ReplicatedStorage.GuiLib.Classes.TextMask`
- `ReplicatedStorage.GuiLib.Constructors.List`
- `ReplicatedStorage.GuiLib.LazyLoader`
- `ReplicatedStorage.GuiLib.Utilities.Maid`
- `ReplicatedStorage.GuiLib.Utilities.Spring`
- `ReplicatedStorage.getPublicData`
- `StarterGui.BobuxDonationGui.Donation Script`
- `StarterGui.GamepassGui.Gamepass Script`
- `StarterPlayer.StarterPlayerScripts.LocalScript`
- `StarterPlayer.StarterPlayerScripts.PlayerModule`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.BaseCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.BaseOcclusion`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraInput`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraToggleStateController`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraUI`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.CameraUtils`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ClassicCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.Invisicam`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.LegacyCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.MouseLockController`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.OrbitalCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.Poppercam`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.TransparencyController`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRBaseCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRCameraTeleportDetector.spec`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VRVehicleCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraConfig`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.VehicleCamera.VehicleCameraCore`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ZoomController`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CameraModule.ZoomController.Popper`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CameraWrapper`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CameraWrapper.spec`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.CharacterUtil`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.ConnectionUtil`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.ConnectionUtil.spec`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.CommonUtils.FlagUtil`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.AvatarAbilitiesInterface`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.BaseCharacterController`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.ClickToMoveController`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.ClickToMoveDisplay`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.DynamicThumbstick`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.Gamepad`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.Keyboard`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.PathDisplay`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.TouchJump`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.TouchThumbstick`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.VRNavigation`
- `StarterPlayer.StarterPlayerScripts.PlayerModule.ControlModule.VehicleController`
- `StarterPlayer.StarterPlayerScripts.PlayerScriptsLoader`
- `StarterPlayer.StarterPlayerScripts.RbxCharacterSounds`
- `StarterPlayer.StarterPlayerScripts.RbxCharacterSounds.AtomicBinding`

