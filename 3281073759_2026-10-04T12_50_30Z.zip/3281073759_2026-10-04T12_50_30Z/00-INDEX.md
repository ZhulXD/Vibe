# AIDump documentation set

---

## What this is

- Game: Ugc (PlaceId 3281073759)
- JobId: 9e93e9bf-35d2-4124-9edb-b339df8ac0a6
- Executor: Delta 1.1.740.931
- Attached: 2026-10-04T12:50:30Z
- Exports written: 3, last at 2026-10-04T12:52:15Z

## How to read this set

- Every statement in these files is a measurement taken during
- this session. Nothing here interprets, explains or guesses.
- Counts marked exact remain exact even where sample lists are
- truncated; truncation is always stated next to the list.
- Absence from a document is not evidence of absence in the game.
- 07-COVERAGE.md lists what was not observed. Read it before
- concluding that something does not exist.

## Coverage totals

| Measure | Count |
| --- | --- |
| Remotes discovered | 18 |
| Remotes with observed traffic | 0 |
| Remotes never observed | 18 |
| Outgoing calls recorded | 0 |
| Incoming calls recorded | 0 |
| Scripts found | 125 |
| Scripts readable by the client | 125 |
| Attributes tracked | 3 |
| Value objects tracked | 65 |
| State transitions recorded | 38 |

## Recommended reading order

- 01-ENVIRONMENT.md - what this client can see, and what it cannot.
- 07-COVERAGE.md - the limits of this run. Read first.
- 03-REMOTES.md then the 04-REMOTE-*.md files - the protocol.
- 05-SCRIPTS.md - which code sends and receives each call.
- 06-STATES.md - the numbers that moved.
- --[[ AIDump: line withheld as unverified assertion (because) ]]

## File manifest

| File | Contents | Size |
| --- | --- | :---: |
| '01-ENVIRONMENT.md' | Place metadata, executor capability probe, reflection source | 2506 bytes |
| '02-STRUCTURE.md' | Instance tree with properties and attributes | 423371 bytes |
| '03-REMOTES.md' | One row per remote with argument schema and traffic counts | 2414 bytes |
| '05-SCRIPTS.md' | Script inventory, decompilation method, call-site cross-reference | 27417 bytes |
| '06-STATES.md' | Attributes, value objects and numeric argument positions | 8084 bytes |
| '07-COVERAGE.md' | What was not observed and what could not be observed | 20156 bytes |
| 'raw/coverage.json' | Machine-readable limits and capability report | 4495 bytes |
| 'raw/instances.json' | Full instance tree with all readable properties | 4744607 bytes |
| 'raw/remotes.json' | Full remote aggregates, samples and timelines | 10452 bytes |
| 'raw/scripts.json' | Script inventory with decompilation metadata | 54736 bytes |
| 'raw/states.json' | Attribute and value-object observation records | 14796 bytes |
| 'scripts/LocalScript.lua' | Generated data | 206 bytes |
| 'scripts/LocalScript.lua' | Generated data | 206 bytes |
| 'scripts/LocalScript.lua' | Generated data | 206 bytes |
| 'scripts/LocalScript.meta.json' | Generated data | 159 bytes |
| 'scripts/LocalScript.meta.json' | Generated data | 159 bytes |
| 'scripts/LocalScript.meta.json' | Generated data | 159 bytes |
| 'scripts/Players_SeoulKD_PlayerGui_BobuxDonationGui_Donation Script.disasm.txt' | Generated data | 7828 bytes |
| 'scripts/Players_SeoulKD_PlayerGui_BobuxDonationGui_Donation Script.meta.json' | Generated data | 347 bytes |
| 'scripts/Players_SeoulKD_PlayerGui_GamepassGui_Gamepass Script.disasm.txt' | Generated data | 4624 bytes |
| 'scripts/Players_SeoulKD_PlayerGui_GamepassGui_Gamepass Script.meta.json' | Generated data | 342 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_LocalScript.disasm.txt' | Generated data | 20250 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_LocalScript.meta.json' | Generated data | 329 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule.disasm.txt' | Generated data | 3484 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule.meta.json' | Generated data | 330 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule.disasm.txt' | Generated data | 20227 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule.meta.json' | Generated data | 343 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_BaseCamera.disasm.txt' | Generated data | 20239 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_BaseCamera.meta.json' | Generated data | 355 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_BaseOcclusion.disasm.txt' | Generated data | 5384 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_BaseOcclusion.meta.json' | Generated data | 357 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraInput.disasm.txt' | Generated data | 20239 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraInput.meta.json' | Generated data | 356 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraToggleStateController.disasm.txt' | Generated data | 10468 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraToggleStateController.meta.json' | Generated data | 371 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraUI.disasm.txt' | Generated data | 3194 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraUI.meta.json' | Generated data | 353 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraUtils.disasm.txt' | Generated data | 20238 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_CameraUtils.meta.json' | Generated data | 355 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_ClassicCamera.disasm.txt' | Generated data | 20240 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_ClassicCamera.meta.json' | Generated data | 357 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_Invisicam.disasm.txt' | Generated data | 20237 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_Invisicam.meta.json' | Generated data | 354 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_LegacyCamera.disasm.txt' | Generated data | 13417 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_LegacyCamera.meta.json' | Generated data | 356 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_MouseLockController.disasm.txt' | Generated data | 20245 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_MouseLockController.meta.json' | Generated data | 363 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_OrbitalCamera.disasm.txt' | Generated data | 20240 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_OrbitalCamera.meta.json' | Generated data | 357 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_Poppercam.disasm.txt' | Generated data | 14896 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_Poppercam.meta.json' | Generated data | 354 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_TransparencyController.disasm.txt' | Generated data | 20248 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_TransparencyController.meta.json' | Generated data | 367 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRBaseCamera.disasm.txt' | Generated data | 20239 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRBaseCamera.meta.json' | Generated data | 357 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRCamera.disasm.txt' | Generated data | 20236 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRCamera.meta.json' | Generated data | 352 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector.disasm.txt' | Generated data | 2196 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector.meta.json' | Generated data | 368 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector_spec.disasm.txt' | Generated data | 11952 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector_spec.meta.json' | Generated data | 374 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRVehicleCamera.disasm.txt' | Generated data | 20242 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VRVehicleCamera.meta.json' | Generated data | 360 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VehicleCamera.disasm.txt' | Generated data | 20240 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VehicleCamera.meta.json' | Generated data | 358 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraConfig.disasm.txt' | Generated data | 3687 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraConfig.meta.json' | Generated data | 377 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraCore.disasm.txt' | Generated data | 20257 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraCore.meta.json' | Generated data | 376 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_ZoomController.disasm.txt' | Generated data | 12093 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_ZoomController.meta.json' | Generated data | 359 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_ZoomController_Popper.disasm.txt' | Generated data | 20249 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CameraModule_ZoomController_Popper.meta.json' | Generated data | 366 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_CameraWrapper.disasm.txt' | Generated data | 8893 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_CameraWrapper.meta.json' | Generated data | 357 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_CameraWrapper_spec.disasm.txt' | Generated data | 6870 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_CameraWrapper_spec.meta.json' | Generated data | 362 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_CharacterUtil.disasm.txt' | Generated data | 13807 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_CharacterUtil.meta.json' | Generated data | 356 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_ConnectionUtil.disasm.txt' | Generated data | 4447 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_ConnectionUtil.meta.json' | Generated data | 357 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_ConnectionUtil_spec.disasm.txt' | Generated data | 13033 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_ConnectionUtil_spec.meta.json' | Generated data | 363 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_FlagUtil.disasm.txt' | Generated data | 1711 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_CommonUtils_FlagUtil.meta.json' | Generated data | 345 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule.disasm.txt' | Generated data | 20229 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule.meta.json' | Generated data | 345 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_AvatarAbilitiesInterface.disasm.txt' | Generated data | 8984 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_AvatarAbilitiesInterface.meta.json' | Generated data | 370 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_BaseCharacterController.disasm.txt' | Generated data | 5317 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_BaseCharacterController.meta.json' | Generated data | 368 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_ClickToMoveController.disasm.txt' | Generated data | 20251 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_ClickToMoveController.meta.json' | Generated data | 367 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_ClickToMoveDisplay.disasm.txt' | Generated data | 20247 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_ClickToMoveDisplay.meta.json' | Generated data | 364 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_DynamicThumbstick.disasm.txt' | Generated data | 20247 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_DynamicThumbstick.meta.json' | Generated data | 362 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_Gamepad.disasm.txt' | Generated data | 20235 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_Gamepad.meta.json' | Generated data | 353 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_Keyboard.disasm.txt' | Generated data | 20235 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_Keyboard.meta.json' | Generated data | 354 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_PathDisplay.disasm.txt' | Generated data | 15601 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_PathDisplay.meta.json' | Generated data | 357 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_TouchJump.disasm.txt' | Generated data | 20237 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_TouchJump.meta.json' | Generated data | 355 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_TouchThumbstick.disasm.txt' | Generated data | 20243 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_TouchThumbstick.meta.json' | Generated data | 360 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_VRNavigation.disasm.txt' | Generated data | 20241 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_VRNavigation.meta.json' | Generated data | 358 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_VehicleController.disasm.txt' | Generated data | 19273 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerModule_ControlModule_VehicleController.meta.json' | Generated data | 363 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerScriptsLoader.disasm.txt' | Generated data | 1031 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_PlayerScriptsLoader.meta.json' | Generated data | 330 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_RbxCharacterSounds.disasm.txt' | Generated data | 20256 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_RbxCharacterSounds.meta.json' | Generated data | 335 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_RbxCharacterSounds_AtomicBinding.disasm.txt' | Generated data | 20232 bytes |
| 'scripts/Players_SeoulKD_PlayerScripts_RbxCharacterSounds_AtomicBinding.meta.json' | Generated data | 351 bytes |
| 'scripts/ReplicatedStorage_DrawCamera.disasm.txt' | Generated data | 20198 bytes |
| 'scripts/ReplicatedStorage_DrawCamera.meta.json' | Generated data | 316 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_CheckboxLabel.disasm.txt' | Generated data | 12771 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_CheckboxLabel.meta.json' | Generated data | 335 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_RadialMenu_CONSTANTS.disasm.txt' | Generated data | 3192 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_RadialMenu_CONSTANTS.meta.json' | Generated data | 351 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_RadialMenu_CreateRadial.disasm.txt' | Generated data | 19654 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_RadialMenu_CreateRadial.meta.json' | Generated data | 354 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_RadialMenu_Triangle.disasm.txt' | Generated data | 5922 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_RadialMenu_Triangle.meta.json' | Generated data | 349 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Integer.disasm.txt' | Generated data | 3812 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Integer.meta.json' | Generated data | 347 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Number.disasm.txt' | Generated data | 5372 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Number.meta.json' | Generated data | 346 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_String.disasm.txt' | Generated data | 1705 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_String.meta.json' | Generated data | 339 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Vector2.disasm.txt' | Generated data | 5763 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Vector2.meta.json' | Generated data | 347 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Vector3.disasm.txt' | Generated data | 5763 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Children_TextMask_Vector3.meta.json' | Generated data | 347 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Dragger.disasm.txt' | Generated data | 11517 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Dragger.meta.json' | Generated data | 328 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Dropdown.disasm.txt' | Generated data | 18928 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Dropdown.meta.json' | Generated data | 329 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_RadialMenu.disasm.txt' | Generated data | 20214 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_RadialMenu.meta.json' | Generated data | 332 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_RadioButtonGroup.disasm.txt' | Generated data | 9810 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_RadioButtonGroup.meta.json' | Generated data | 337 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_RadioButtonLabel.disasm.txt' | Generated data | 9966 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_RadioButtonLabel.meta.json' | Generated data | 338 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Slider.disasm.txt' | Generated data | 20210 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_Slider.meta.json' | Generated data | 327 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_TextMask.disasm.txt' | Generated data | 9880 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Classes_TextMask.meta.json' | Generated data | 330 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Constructors_List.disasm.txt' | Generated data | 9335 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Constructors_List.meta.json' | Generated data | 331 bytes |
| 'scripts/ReplicatedStorage_GuiLib_LazyLoader.disasm.txt' | Generated data | 4101 bytes |
| 'scripts/ReplicatedStorage_GuiLib_LazyLoader.meta.json' | Generated data | 323 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Utilities_Maid.disasm.txt' | Generated data | 5744 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Utilities_Maid.meta.json' | Generated data | 328 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Utilities_Spring.disasm.txt' | Generated data | 6682 bytes |
| 'scripts/ReplicatedStorage_GuiLib_Utilities_Spring.meta.json' | Generated data | 335 bytes |
| 'scripts/ReplicatedStorage_getPublicData.disasm.txt' | Generated data | 2069 bytes |
| 'scripts/ReplicatedStorage_getPublicData.meta.json' | Generated data | 313 bytes |
| 'scripts/StarterGui_BobuxDonationGui_Donation Script.disasm.txt' | Generated data | 7812 bytes |
| 'scripts/StarterGui_BobuxDonationGui_Donation Script.meta.json' | Generated data | 331 bytes |
| 'scripts/StarterGui_GamepassGui_Gamepass Script.disasm.txt' | Generated data | 4608 bytes |
| 'scripts/StarterGui_GamepassGui_Gamepass Script.meta.json' | Generated data | 326 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_LocalScript.disasm.txt' | Generated data | 20255 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_LocalScript.meta.json' | Generated data | 334 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule.disasm.txt' | Generated data | 3489 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule.meta.json' | Generated data | 335 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule.disasm.txt' | Generated data | 20232 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule.meta.json' | Generated data | 348 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_BaseCamera.disasm.txt' | Generated data | 20244 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_BaseCamera.meta.json' | Generated data | 360 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_BaseOcclusion.disasm.txt' | Generated data | 5389 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_BaseOcclusion.meta.json' | Generated data | 362 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraInput.disasm.txt' | Generated data | 20244 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraInput.meta.json' | Generated data | 361 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraToggleStateController.disasm.txt' | Generated data | 10473 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraToggleStateController.meta.json' | Generated data | 376 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraUI.disasm.txt' | Generated data | 3199 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraUI.meta.json' | Generated data | 358 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraUtils.disasm.txt' | Generated data | 20243 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_CameraUtils.meta.json' | Generated data | 360 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_ClassicCamera.disasm.txt' | Generated data | 20245 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_ClassicCamera.meta.json' | Generated data | 362 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_Invisicam.disasm.txt' | Generated data | 20242 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_Invisicam.meta.json' | Generated data | 359 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_LegacyCamera.disasm.txt' | Generated data | 13422 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_LegacyCamera.meta.json' | Generated data | 361 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_MouseLockController.disasm.txt' | Generated data | 20250 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_MouseLockController.meta.json' | Generated data | 368 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_OrbitalCamera.disasm.txt' | Generated data | 20245 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_OrbitalCamera.meta.json' | Generated data | 362 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_Poppercam.disasm.txt' | Generated data | 14901 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_Poppercam.meta.json' | Generated data | 359 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_TransparencyController.disasm.txt' | Generated data | 20253 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_TransparencyController.meta.json' | Generated data | 372 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRBaseCamera.disasm.txt' | Generated data | 20244 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRBaseCamera.meta.json' | Generated data | 362 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRCamera.disasm.txt' | Generated data | 20241 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRCamera.meta.json' | Generated data | 357 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector.disasm.txt' | Generated data | 2201 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector.meta.json' | Generated data | 373 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector_spec.disasm.txt' | Generated data | 11957 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRCameraTeleportDetector_spec.meta.json' | Generated data | 379 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRVehicleCamera.disasm.txt' | Generated data | 20247 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VRVehicleCamera.meta.json' | Generated data | 365 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VehicleCamera.disasm.txt' | Generated data | 20245 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VehicleCamera.meta.json' | Generated data | 363 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraConfig.disasm.txt' | Generated data | 3692 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraConfig.meta.json' | Generated data | 382 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraCore.disasm.txt' | Generated data | 20262 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_VehicleCamera_VehicleCameraCore.meta.json' | Generated data | 381 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_ZoomController.disasm.txt' | Generated data | 12098 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_ZoomController.meta.json' | Generated data | 364 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_ZoomController_Popper.disasm.txt' | Generated data | 20254 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CameraModule_ZoomController_Popper.meta.json' | Generated data | 371 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_CameraWrapper.disasm.txt' | Generated data | 8898 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_CameraWrapper.meta.json' | Generated data | 362 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_CameraWrapper_spec.disasm.txt' | Generated data | 6875 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_CameraWrapper_spec.meta.json' | Generated data | 367 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_CharacterUtil.disasm.txt' | Generated data | 13812 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_CharacterUtil.meta.json' | Generated data | 361 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_ConnectionUtil.disasm.txt' | Generated data | 4452 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_ConnectionUtil.meta.json' | Generated data | 362 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_ConnectionUtil_spec.disasm.txt' | Generated data | 13038 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_ConnectionUtil_spec.meta.json' | Generated data | 368 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_FlagUtil.disasm.txt' | Generated data | 1716 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_CommonUtils_FlagUtil.meta.json' | Generated data | 350 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule.disasm.txt' | Generated data | 20234 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule.meta.json' | Generated data | 350 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_AvatarAbilitiesInterface.disasm.txt' | Generated data | 8989 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_AvatarAbilitiesInterface.meta.json' | Generated data | 375 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_BaseCharacterController.disasm.txt' | Generated data | 5322 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_BaseCharacterController.meta.json' | Generated data | 373 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_ClickToMoveController.disasm.txt' | Generated data | 20256 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_ClickToMoveController.meta.json' | Generated data | 372 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_ClickToMoveDisplay.disasm.txt' | Generated data | 20252 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_ClickToMoveDisplay.meta.json' | Generated data | 369 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_DynamicThumbstick.disasm.txt' | Generated data | 20252 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_DynamicThumbstick.meta.json' | Generated data | 367 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_Gamepad.disasm.txt' | Generated data | 20240 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_Gamepad.meta.json' | Generated data | 358 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_Keyboard.disasm.txt' | Generated data | 20240 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_Keyboard.meta.json' | Generated data | 359 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_PathDisplay.disasm.txt' | Generated data | 15606 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_PathDisplay.meta.json' | Generated data | 362 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_TouchJump.disasm.txt' | Generated data | 20242 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_TouchJump.meta.json' | Generated data | 360 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_TouchThumbstick.disasm.txt' | Generated data | 20248 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_TouchThumbstick.meta.json' | Generated data | 365 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_VRNavigation.disasm.txt' | Generated data | 20246 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_VRNavigation.meta.json' | Generated data | 363 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_VehicleController.disasm.txt' | Generated data | 19278 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerModule_ControlModule_VehicleController.meta.json' | Generated data | 368 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerScriptsLoader.disasm.txt' | Generated data | 1036 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_PlayerScriptsLoader.meta.json' | Generated data | 335 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_RbxCharacterSounds.disasm.txt' | Generated data | 20261 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_RbxCharacterSounds.meta.json' | Generated data | 340 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_RbxCharacterSounds_AtomicBinding.disasm.txt' | Generated data | 20237 bytes |
| 'scripts/StarterPlayer_StarterPlayerScripts_RbxCharacterSounds_AtomicBinding.meta.json' | Generated data | 356 bytes |

