# 06 - Observed state

---

| Measure | Count |
| --- | --- |
| Attribute cells tracked | 3 |
| Value objects tracked | 65 |
| Recorded transitions | 28 |
| Traffic events observed | 0 |
| Instances watched | 3964 |

## Attributes

| Instance | Attribute | Type | Observations | Changes | Min | Max | Direction | Last value | Distinct values |
| --- | --- | --- | :---: | :---: | :---: | :---: | --- | --- | :---: |
| 'Workspace.Lights.Low Poly Garden Lantern.Neon.PointLight' | 'ToTurnOn' | boolean | 14 | 13 | — | — | — | true | 14 |
| 'Workspace.Lights.Low Poly Lantern.Meshes/Booth42_Lantern2.PointLight' | 'ToTurnOn' | boolean | 4 | 3 | — | — | — | true | 4 |
| 'Lighting' | 'RBX_LightingTechnologyUnifiedMigration' | boolean | 1 | 0 | — | — | — | true | 1 |

## Value objects

| Instance | Class | Type | Observations | Changes | Min | Max | Direction | Last value |
| --- | --- | --- | :---: | :---: | :---: | :---: | --- | --- |
| 'Players.Ayanapixel.leaderstats.Guesses' | IntValue | number | 2 | 1 | 69 | 70 | up 1 / down 0 | 70 |
| 'Players.Ayanapixel.leaderstats.Points' | IntValue | number | 2 | 1 | 6098 | 6149 | up 1 / down 0 | 6149 |
| 'Players.Giani_Ckj.leaderstats.Guesses' | IntValue | number | 2 | 1 | 54 | 55 | up 1 / down 0 | 55 |
| 'Players.Giani_Ckj.leaderstats.Points' | IntValue | number | 2 | 1 | 4330 | 4389 | up 1 / down 0 | 4389 |
| 'Players.Lisedex.leaderstats.Guesses' | IntValue | number | 2 | 1 | 0 | 1 | up 1 / down 0 | 1 |
| 'Players.Lisedex.leaderstats.Points' | IntValue | number | 2 | 1 | 0 | 55 | up 1 / down 0 | 55 |
| 'Players.SeoulKD.leaderstats.Guesses' | IntValue | number | 2 | 1 | 205 | 206 | up 1 / down 0 | 206 |
| 'Players.SeoulKD.leaderstats.Points' | IntValue | number | 2 | 1 | 26107 | 26147 | up 1 / down 0 | 26147 |
| 'Players.magenta_290.leaderstats.Guesses' | IntValue | number | 2 | 1 | 18 | 19 | up 1 / down 0 | 19 |
| 'Players.magenta_290.leaderstats.Points' | IntValue | number | 2 | 1 | 1342 | 1415 | up 1 / down 0 | 1415 |
| 'Players.yuime_8.leaderstats.Points' | IntValue | number | 2 | 1 | 2956 | 3097 | up 1 / down 0 | 3097 |
| 'ReplicatedStorage.DATA.Ayanapixel.guesses' | NumberValue | number | 2 | 1 | 69 | 70 | up 1 / down 0 | 70 |
| 'ReplicatedStorage.DATA.Ayanapixel.lastUpdate' | NumberValue | number | 2 | 1 | 1791018627 | 1791118287 | up 1 / down 0 | 1791118287 |
| 'ReplicatedStorage.DATA.Ayanapixel.points' | NumberValue | number | 2 | 1 | 6098 | 6149 | up 1 / down 0 | 6149 |
| 'ReplicatedStorage.DATA.Giani_Ckj.guesses' | NumberValue | number | 2 | 1 | 54 | 55 | up 1 / down 0 | 55 |
| 'ReplicatedStorage.DATA.Giani_Ckj.lastUpdate' | NumberValue | number | 2 | 1 | 1791118138 | 1791118282 | up 1 / down 0 | 1791118282 |
| 'ReplicatedStorage.DATA.Giani_Ckj.points' | NumberValue | number | 2 | 1 | 4330 | 4389 | up 1 / down 0 | 4389 |
| 'ReplicatedStorage.DATA.Lisedex.guesses' | NumberValue | number | 2 | 1 | 0 | 1 | up 1 / down 0 | 1 |
| 'ReplicatedStorage.DATA.Lisedex.lastUpdate' | NumberValue | number | 2 | 1 | 1791118159 | 1791118284 | up 1 / down 0 | 1791118284 |
| 'ReplicatedStorage.DATA.Lisedex.points' | NumberValue | number | 2 | 1 | 0 | 55 | up 1 / down 0 | 55 |
| 'ReplicatedStorage.DATA.SeoulKD.guesses' | NumberValue | number | 2 | 1 | 205 | 206 | up 1 / down 0 | 206 |
| 'ReplicatedStorage.DATA.SeoulKD.lastUpdate' | NumberValue | number | 2 | 1 | 1791116478 | 1791118294 | up 1 / down 0 | 1791118294 |
| 'ReplicatedStorage.DATA.SeoulKD.points' | NumberValue | number | 2 | 1 | 26107 | 26147 | up 1 / down 0 | 26147 |
| 'ReplicatedStorage.DATA.magenta_290.guesses' | NumberValue | number | 2 | 1 | 18 | 19 | up 1 / down 0 | 19 |
| 'ReplicatedStorage.DATA.magenta_290.lastUpdate' | NumberValue | number | 2 | 1 | 1782905216 | 1791118273 | up 1 / down 0 | 1791118273 |
| 'ReplicatedStorage.DATA.magenta_290.points' | NumberValue | number | 2 | 1 | 1342 | 1415 | up 1 / down 0 | 1415 |
| 'ReplicatedStorage.DATA.yuime_8.lastUpdate' | NumberValue | number | 2 | 1 | 1771332626 | 1791118294 | up 1 / down 0 | 1791118294 |
| 'ReplicatedStorage.DATA.yuime_8.points' | NumberValue | number | 2 | 1 | 2956 | 3097 | up 1 / down 0 | 3097 |
| 'Players.Ayanapixel.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.Giani_Ckj.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.Lisedex.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.MouseLockController.BoundKeys' | StringValue | string | 1 | 0 | — | — | — | "LeftShift,RightShift" |
| 'Players.SeoulKD.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.magenta_290.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.yuime_8.leaderstats.Guesses' | IntValue | number | 1 | 0 | 30 | 30 | — | 30 |
| 'Players.yuime_8.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'ReplicatedStorage.DATA.Ayanapixel.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Ayanapixel.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Ayanapixel.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Ayanapixel.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Giani_Ckj.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Giani_Ckj.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Giani_Ckj.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Giani_Ckj.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Lisedex.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Lisedex.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Lisedex.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.Lisedex.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.SeoulKD.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.magenta_290.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.magenta_290.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.magenta_290.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.magenta_290.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.yuime_8.banDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.yuime_8.banDuration' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.yuime_8.donations' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.DATA.yuime_8.guesses' | NumberValue | number | 1 | 0 | 30 | 30 | — | 30 |
| 'ReplicatedStorage.DATA.yuime_8.warningDate' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'ReplicatedStorage.getPublicData.DataName' | StringValue | string | 1 | 0 | — | — | — | "DATA" |
| 'Workspace.BobuxDonation.AllowTitles' | BoolValue | boolean | 1 | 0 | — | — | — | true |
| 'Workspace.BobuxDonation.TitleColor' | Color3Value | Color3 | 1 | 0 | — | — | — | Color3.new(0.8274510502815247, 0.5764706… |
| 'Workspace.BobuxDonation.TitleOrder' | IntValue | number | 1 | 0 | -1 | -1 | — | -1 |

## Numeric argument positions

- Every numeric argument position observed on any remote, with its
- observed range and how often the value moved up or down.

No numeric argument position was observed.

