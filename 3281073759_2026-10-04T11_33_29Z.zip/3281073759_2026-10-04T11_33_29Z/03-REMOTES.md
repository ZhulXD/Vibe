# 03 - Remotes

---

| Measure | Count |
| --- | --- |
| Remotes discovered | 9 |
| With observed outgoing traffic | 0 |
| With observed incoming traffic | 0 |
| With both directions | 0 |
| Never observed in either direction | 9 |
| Outgoing calls recorded | 0 |
| Incoming calls recorded | 0 |
| Of those, produced by the AIDump sweep | 0 |

## All discovered remotes

| Class | Name | Parent | Direction | Out | In | Shapes | Argument schema | Callers | Listeners | Detail file |
| --- | --- | --- | :---: | :---: | :---: | :---: | --- | :---: | :---: | --- |
| 'BindableFunction' | 'PlayEmote' | Workspace.FFGAMING964.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'BindableFunction' | 'PlayEmote' | Workspace.SYIRGI7.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'BindableFunction' | 'PlayEmote' | Workspace.SeoulKD.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'BindableFunction' | 'PlayEmote' | Workspace.Wisitrap09.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'BindableFunction' | 'PlayEmote' | Workspace.kayulr7.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'BindableFunction' | 'PlayEmote' | Workspace.pikachihuyyyyy.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'BindableFunction' | 'PlayEmote' | Workspace.smoothie_0260.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'BindableFunction' | 'PlayEmote' | Workspace.xxKoPiToPixx.Animate | — | 0 | 0 | 0 |  | 0 | 0 | — |
| 'RemoteEvent' | 'TeleportRemote' | Workspace.Pro Server Portal | — | 0 | 0 | 0 |  | 0 | 0 | — |

- `Direction` is `out`, `in` or `out+in`.
- `Shapes` counts distinct argument type signatures observed.
- `Callers` counts distinct (script, method, line) triples.

