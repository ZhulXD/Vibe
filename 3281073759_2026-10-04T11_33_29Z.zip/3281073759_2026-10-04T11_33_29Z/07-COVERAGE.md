# 07 - Coverage and limitations

---

- This file lists what the run did NOT observe and what it could
- not observe. Anything absent from the other documents and
- absent from this file should be treated as genuinely unknown.

## Remotes with no observed traffic (9)

| Class | Path | Parent |
| --- | --- | --- |
| 'BindableFunction' | 'Workspace.FFGAMING964.Animate.PlayEmote' | Workspace.FFGAMING964.Animate |
| 'RemoteEvent' | 'Workspace.Pro Server Portal.TeleportRemote' | Workspace.Pro Server Portal |
| 'BindableFunction' | 'Workspace.SYIRGI7.Animate.PlayEmote' | Workspace.SYIRGI7.Animate |
| 'BindableFunction' | 'Workspace.SeoulKD.Animate.PlayEmote' | Workspace.SeoulKD.Animate |
| 'BindableFunction' | 'Workspace.Wisitrap09.Animate.PlayEmote' | Workspace.Wisitrap09.Animate |
| 'BindableFunction' | 'Workspace.kayulr7.Animate.PlayEmote' | Workspace.kayulr7.Animate |
| 'BindableFunction' | 'Workspace.pikachihuyyyyy.Animate.PlayEmote' | Workspace.pikachihuyyyyy.Animate |
| 'BindableFunction' | 'Workspace.smoothie_0260.Animate.PlayEmote' | Workspace.smoothie_0260.Animate |
| 'BindableFunction' | 'Workspace.xxKoPiToPixx.Animate.PlayEmote' | Workspace.xxKoPiToPixx.Animate |

## Interactable instances

- These exist in the game and respond to player input. A reader
- of this dump cannot know whether they were exercised.

| Class | Count |
| --- | :---: |
| 'ProximityPrompt' | 0 |
| 'ClickDetector' | 0 |
| 'TouchTransmitter' | 1 |

## Sweep activity (0 action(s) attempted)

No sweep action was attempted.

## Capture layers not available

| Capability | Consequence |
| --- | --- |
| 'getcallingline' | call sites are attributed to a script but not to a line number; 05-SCRIPTS.md records the script only |
| 'ReflectionMetadata.xml' | not present on the filesystem; property coverage fell back to probing |
| 'parallel Luau actors' | this build observes only the main client; actor instances and their remotes are not instrumented regardless of executor support |

## Structural limits

| Limit | Configured | This run | State |
| --- | :---: | :---: | --- |
| Instance walk budget | 8000 | 0 | within budget |
| Depth budget | 40 | 40 | within budget |
| Properties per instance | 40 | 40 | cap applied |
| Total property emissions | 60000 | 60000 | cap applied |
| raw/instances.json instances | 20000 | 20000 | cap applied |
| raw/instances.json with properties | 4000 | 4000 | cap applied |

- 02-STRUCTURE.md was truncated at the instance budget budget of 8000.

- Property reads failed 300 time(s) against a budget of 300; reading was then disabled for the rest of the run.

- Instances listed after that point carry name, class,
- children and attributes, but no property values.

- raw/instances.json lists every instance up to the cap, but properties were read for only the first 4000. The remaining 16000 carry name, class, children and attributes, but no property values.

- Attribute names created after watching began and never changed are only
- discovered at the next export, so a short run can miss them.

## Scripts without usable source (0)

Every client-side script produced some output.

## Lines withheld by the fact-discipline linter (2)

| Withheld line | Trigger terms |
| --- | --- |
| This remote is probably the currency endpoint. | probably |
| 02-STRUCTURE.md - the full scene, last, because it is large. | because |

