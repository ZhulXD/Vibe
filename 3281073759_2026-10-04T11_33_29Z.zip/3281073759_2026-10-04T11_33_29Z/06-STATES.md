# 06 - Observed state

---

| Measure | Count |
| --- | --- |
| Attribute cells tracked | 54 |
| Value objects tracked | 1020 |
| Recorded transitions | 1 |
| Traffic events observed | 0 |
| Instances watched | 1237 |

## Attributes

| Instance | Attribute | Type | Observations | Changes | Min | Max | Direction | Last value | Distinct values |
| --- | --- | --- | :---: | :---: | :---: | :---: | --- | --- | :---: |
| 'Workspace.Lights.Low Poly Garden Lantern.Neon.PointLight' | 'ToTurnOn' | boolean | 14 | 13 | — | — | — | true | 14 |
| 'Workspace.Lights.Low Poly Lantern.Meshes/Booth42_Lantern2.PointLight' | 'ToTurnOn' | boolean | 4 | 3 | — | — | — | true | 4 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Desktop-1' | 'ColorContentDefaultColor3' | Color3 | 1 | 0 | — | — | — | Color3.new(0.8352940082550049, 0.8431370… | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Desktop-1' | 'ColorContentDefaultTransparency' | number | 1 | 0 | 0 | 0 | — | 0 | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Desktop-1' | 'ColorContentEmphasisColor3' | Color3 | 1 | 0 | — | — | — | Color3.new(0.9686269760131836, 0.9686269… | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Desktop-1' | 'ColorContentEmphasisTransparency' | number | 1 | 0 | 0 | 0 | — | 0 | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Desktop-1' | 'FontBodyLarge' | EnumItem | 1 | 0 | — | — | — | Enum.Font.BuilderSans | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Desktop-1' | 'PaddingLarge' | UDim | 1 | 0 | — | — | — | UDim.new(0, 16) | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Desktop-1' | 'PaddingMedium' | UDim | 1 | 0 | — | — | — | UDim.new(0, 12) | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Desktop-1' | 'PaddingXxsmall' | UDim | 1 | 0 | — | — | — | UDim.new(0, 2) | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Desktop-1' | 'RadiusCircle' | UDim | 1 | 0 | — | — | — | UDim.new(0, 9999) | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Desktop-1' | 'SizeFull' | UDim2 | 1 | 0 | — | — | — | UDim2.new(1, 0, 1, 0) | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Desktop-1' | 'TextPaddingBodyLarge' | UDim | 1 | 0 | — | — | — | UDim.new(0, 1) | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Desktop-1' | 'TextSizeBodyLarge' | number | 1 | 0 | 20 | 20 | — | 20 | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Phone-1' | 'ColorContentDefaultColor3' | Color3 | 1 | 0 | — | — | — | Color3.new(0.8352940082550049, 0.8431370… | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Phone-1' | 'ColorContentDefaultTransparency' | number | 1 | 0 | 0 | 0 | — | 0 | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Phone-1' | 'FontBodyLarge' | EnumItem | 1 | 0 | — | — | — | Enum.Font.BuilderSans | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Phone-1' | 'TextPaddingBodyLarge' | UDim | 1 | 0 | — | — | — | UDim.new(0, 1) | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Phone-1' | 'TextSizeBodyLarge' | number | 1 | 0 | 20 | 20 | — | 20 | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Unknown-1' | 'ColorContentDefaultColor3' | Color3 | 1 | 0 | — | — | — | Color3.new(0.8352940082550049, 0.8431370… | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Unknown-1' | 'ColorContentDefaultTransparency' | number | 1 | 0 | 0 | 0 | — | 0 | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Unknown-1' | 'FontBodyLarge' | EnumItem | 1 | 0 | — | — | — | Enum.Font.BuilderSans | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Unknown-1' | 'FontLabelSmall' | EnumItem | 1 | 0 | — | — | — | Enum.Font.BuilderSansMedium | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Unknown-1' | 'GapXsmall' | UDim | 1 | 0 | — | — | — | UDim.new(0, 4) | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Unknown-1' | 'PaddingSmall' | UDim | 1 | 0 | — | — | — | UDim.new(0, 8) | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Unknown-1' | 'Size0_Full' | UDim2 | 1 | 0 | — | — | — | UDim2.new(0, 0, 1, 0) | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Unknown-1' | 'SizeFull' | UDim2 | 1 | 0 | — | — | — | UDim2.new(1, 0, 1, 0) | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Unknown-1' | 'TextPaddingBodyLarge' | UDim | 1 | 0 | — | — | — | UDim.new(0, 1) | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Unknown-1' | 'TextPaddingLabelSmall' | UDim | 1 | 0 | — | — | — | UDim.new(0, -1) | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Unknown-1' | 'TextSizeBodyLarge' | number | 1 | 0 | 20 | 20 | — | 20 | 1 |
| 'CorePackages.Packages._Index.Foundation.Foundation.FoundationStyleSheets.Default-Dark-Unknown-1' | 'TextSizeLabelSmall' | number | 1 | 0 | 15 | 15 | — | 15 | 1 |
| 'Workspace.FFGAMING964.Accessory (defaultAccessory).Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.SYIRGI7.Accessory (Scene Extreme).Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.SeoulKD.8BitController.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.SeoulKD.Pal Hair.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.SeoulKD.Scarf.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.SeoulKD.WatermelonHat.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.Wisitrap09.BIPIHeadphones.Handle.HatAttachment' | 'RBXOriginalAttachmentRotation' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3745789… | 1 |
| 'Workspace.Wisitrap09.BIPIHeadphones.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.0399999… | 1 |
| 'Workspace.Wisitrap09.Books2Accessory.Handle.BodyFrontAttachment' | 'RBXOriginalAttachmentRotation' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -1.569… | 1 |
| 'Workspace.Wisitrap09.Books2Accessory.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.Wisitrap09.HandleAccessory.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.Wisitrap09.Pal Hair.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.Wisitrap09.Yama Cape.Handle.BodyBackAttachment' | 'RBXOriginalAttachmentRotation' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.000000… | 1 |
| 'Workspace.Wisitrap09.Yama Cape.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.kayulr7.LongStraightHair.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.pikachihuyyyyy.GoldCirclet.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.pikachihuyyyyy.GoldHorns.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.pikachihuyyyyy.LongStraightHair.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.pikachihuyyyyy.NerdGlasses.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.smoothie_0260.LongStraightHair.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.xxKoPiToPixx.LongStraightHair.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.xxKoPiToPixx.NerdGlasses.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |
| 'Workspace.xxKoPiToPixx.RobloxVisor2019.Handle' | 'RBXRefinementScale' | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1, 1]] | 1 |

## Value objects

| Instance | Class | Type | Observations | Changes | Min | Max | Direction | Last value |
| --- | --- | --- | :---: | :---: | :---: | :---: | --- | --- |
| 'Players.xxKoPiToPixx.leaderstats.Points' | IntValue | number | 2 | 1 | 2295 | 2321 | up 1 / down 0 | 2321 |
| 'CorePackages.Packages._Index.Resources.Resources..luaurc' | StringValue | string | 1 | 0 | — | — | — | "{\n\t\"languageMode\": \"strict\",\n\t\… |
| 'CorePackages.Packages._Index.Signals.Signals..luaurc' | StringValue | string | 1 | 0 | — | — | — | "{\n\t\"languageMode\": \"strict\",\n\t\… |
| 'CorePackages.Packages._Index.SignalsExperimental.SignalsExperimental..luaurc' | StringValue | string | 1 | 0 | — | — | — | "{\n\t\"languageMode\": \"strict\",\n\t\… |
| 'CorePackages.Packages._Index.SignalsReact.SignalsReact..luaurc' | StringValue | string | 1 | 0 | — | — | — | "{\n\t\"languageMode\": \"strict\",\n\t\… |
| 'CorePackages.Packages._Index.SignalsScheduler.SignalsScheduler..luaurc' | StringValue | string | 1 | 0 | — | — | — | "{\n\t\"languageMode\": \"strict\",\n\t\… |
| 'Players.FFGAMING964.leaderstats.Guesses' | IntValue | number | 1 | 0 | 19 | 19 | — | 19 |
| 'Players.FFGAMING964.leaderstats.Points' | IntValue | number | 1 | 0 | 1042 | 1042 | — | 1042 |
| 'Players.FFGAMING964.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.SYIRGI7.leaderstats.Guesses' | IntValue | number | 1 | 0 | 4 | 4 | — | 4 |
| 'Players.SYIRGI7.leaderstats.Points' | IntValue | number | 1 | 0 | 425 | 425 | — | 425 |
| 'Players.SYIRGI7.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.SeoulKD.PlayerScripts.PlayerModule.CameraModule.MouseLockController.BoundKeys' | StringValue | string | 1 | 0 | — | — | — | "LeftShift,RightShift" |
| 'Players.SeoulKD.leaderstats.Guesses' | IntValue | number | 1 | 0 | 199 | 199 | — | 199 |
| 'Players.SeoulKD.leaderstats.Points' | IntValue | number | 1 | 0 | 25750 | 25750 | — | 25750 |
| 'Players.SeoulKD.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.Wisitrap09.leaderstats.Guesses' | IntValue | number | 1 | 0 | 38 | 38 | — | 38 |
| 'Players.Wisitrap09.leaderstats.Points' | IntValue | number | 1 | 0 | 2172 | 2172 | — | 2172 |
| 'Players.Wisitrap09.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.kayulr7.leaderstats.Guesses' | IntValue | number | 1 | 0 | 24 | 24 | — | 24 |
| 'Players.kayulr7.leaderstats.Points' | IntValue | number | 1 | 0 | 1519 | 1519 | — | 1519 |
| 'Players.kayulr7.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.pikachihuyyyyy.leaderstats.Guesses' | IntValue | number | 1 | 0 | 63 | 63 | — | 63 |
| 'Players.pikachihuyyyyy.leaderstats.Points' | IntValue | number | 1 | 0 | 5704 | 5704 | — | 5704 |
| 'Players.pikachihuyyyyy.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.smoothie_0260.leaderstats.Guesses' | IntValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Players.smoothie_0260.leaderstats.Points' | IntValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Players.smoothie_0260.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Players.xxKoPiToPixx.leaderstats.Guesses' | IntValue | number | 1 | 0 | 31 | 31 | — | 31 |
| 'Players.xxKoPiToPixx.leaderstats.Points.Priority' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.BobuxDonation.AllowTitles' | BoolValue | boolean | 1 | 0 | — | — | — | true |
| 'Workspace.BobuxDonation.TitleColor' | Color3Value | Color3 | 1 | 0 | — | — | — | Color3.new(0.8274510502815247, 0.5764706… |
| 'Workspace.BobuxDonation.TitleOrder' | IntValue | number | 1 | 0 | -1 | -1 | — | -1 |
| 'Workspace.FFGAMING964.Accessory (defaultAccessory).Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.FFGAMING964.Accessory (defaultAccessory).Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0015411… |
| 'Workspace.FFGAMING964.Accessory (defaultAccessory).Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.1982409… |
| 'Workspace.FFGAMING964.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.FFGAMING964.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.FFGAMING964.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.FFGAMING964.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.FFGAMING964.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.FFGAMING964.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.FFGAMING964.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.FFGAMING964.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.FFGAMING964.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.FFGAMING964.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.FFGAMING964.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.FFGAMING964.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.FFGAMING964.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.FFGAMING964.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.FFGAMING964.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9921589… |
| 'Workspace.FFGAMING964.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.0895277… |
| 'Workspace.FFGAMING964.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.FFGAMING964.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.FFGAMING964.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3896427… |
| 'Workspace.FFGAMING964.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1978399… |
| 'Workspace.FFGAMING964.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.FFGAMING964.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.FFGAMING964.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.FFGAMING964.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.FFGAMING964.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.FFGAMING964.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.FFGAMING964.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.FFGAMING964.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.FFGAMING964.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.FFGAMING964.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.788139… |
| 'Workspace.FFGAMING964.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0182774… |
| 'Workspace.FFGAMING964.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.FFGAMING964.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.149… |
| 'Workspace.FFGAMING964.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004789… |
| 'Workspace.FFGAMING964.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.3001… |
| 'Workspace.FFGAMING964.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004786… |
| 'Workspace.FFGAMING964.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004786… |
| 'Workspace.FFGAMING964.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.0518… |
| 'Workspace.FFGAMING964.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.FFGAMING964.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9802322… |
| 'Workspace.FFGAMING964.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.FFGAMING964.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004792… |
| 'Workspace.FFGAMING964.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3841857… |
| 'Workspace.FFGAMING964.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5000003… |
| 'Workspace.FFGAMING964.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5000003… |
| 'Workspace.FFGAMING964.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1686… |
| 'Workspace.FFGAMING964.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.FFGAMING964.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.9406967… |
| 'Workspace.FFGAMING964.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.FFGAMING964.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.FFGAMING964.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 0.4001… |
| 'Workspace.FFGAMING964.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.4999998… |
| 'Workspace.FFGAMING964.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.FFGAMING964.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.464132… |
| 'Workspace.FFGAMING964.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -4.220008… |
| 'Workspace.FFGAMING964.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.322198… |
| 'Workspace.FFGAMING964.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.FFGAMING964.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.FFGAMING964.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.101… |
| 'Workspace.FFGAMING964.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.018277… |
| 'Workspace.FFGAMING964.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.3001… |
| 'Workspace.FFGAMING964.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.149… |
| 'Workspace.FFGAMING964.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.5762786… |
| 'Workspace.FFGAMING964.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.0518… |
| 'Workspace.FFGAMING964.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1920928… |
| 'Workspace.FFGAMING964.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1920928… |
| 'Workspace.FFGAMING964.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.FFGAMING964.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.54… |
| 'Workspace.FFGAMING964.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.379… |
| 'Workspace.FFGAMING964.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1686… |
| 'Workspace.FFGAMING964.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.FFGAMING964.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.344650… |
| 'Workspace.FFGAMING964.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.FFGAMING964.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.FFGAMING964.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.FFGAMING964.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.420… |
| 'Workspace.FFGAMING964.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.40… |
| 'Workspace.FFGAMING964.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.FFGAMING964.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.FFGAMING964.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.999999… |
| 'Workspace.FFGAMING964.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1, 0.563… |
| 'Workspace.FFGAMING964.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1, 0.563… |
| 'Workspace.FFGAMING964.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.058594… |
| 'Workspace.FFGAMING964.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.FFGAMING964.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 1.6000… |
| 'Workspace.FFGAMING964.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9999999… |
| 'Workspace.FFGAMING964.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9999999… |
| 'Workspace.FFGAMING964.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9999999… |
| 'Workspace.FFGAMING964.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.Pro Server Portal.MaxPoints' | IntValue | number | 1 | 0 | 10000 | 10000 | — | 10000 |
| 'Workspace.SYIRGI7.Accessory (Scene Extreme).Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SYIRGI7.Accessory (Scene Extreme).Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.1010262… |
| 'Workspace.SYIRGI7.Accessory (Scene Extreme).Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.9885280… |
| 'Workspace.SYIRGI7.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SYIRGI7.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SYIRGI7.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SYIRGI7.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SYIRGI7.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SYIRGI7.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SYIRGI7.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SYIRGI7.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SYIRGI7.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SYIRGI7.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SYIRGI7.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.SYIRGI7.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SYIRGI7.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SYIRGI7.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SYIRGI7.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9921589… |
| 'Workspace.SYIRGI7.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.0895277… |
| 'Workspace.SYIRGI7.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.SYIRGI7.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.SYIRGI7.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3896427… |
| 'Workspace.SYIRGI7.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1978399… |
| 'Workspace.SYIRGI7.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 0.8500000238418579 | 0.8500000238418579 | — | 0.8500000238418579 |
| 'Workspace.SYIRGI7.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 0.9399999976158142 | 0.9399999976158142 | — | 0.9399999976158142 |
| 'Workspace.SYIRGI7.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.SYIRGI7.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.SYIRGI7.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 0.699999988079071 | 0.699999988079071 | — | 0.699999988079071 |
| 'Workspace.SYIRGI7.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SYIRGI7.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.SYIRGI7.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.SYIRGI7.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.SYIRGI7.LC_PrettyImpressiveRightEyebrow_Accessory.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.4228824… |
| 'Workspace.SYIRGI7.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.788139… |
| 'Workspace.SYIRGI7.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0182774… |
| 'Workspace.SYIRGI7.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.SYIRGI7.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.149… |
| 'Workspace.SYIRGI7.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004789… |
| 'Workspace.SYIRGI7.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.3001… |
| 'Workspace.SYIRGI7.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004786… |
| 'Workspace.SYIRGI7.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004786… |
| 'Workspace.SYIRGI7.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.0518… |
| 'Workspace.SYIRGI7.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.SYIRGI7.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9802322… |
| 'Workspace.SYIRGI7.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.SYIRGI7.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0004792… |
| 'Workspace.SYIRGI7.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3841857… |
| 'Workspace.SYIRGI7.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5000003… |
| 'Workspace.SYIRGI7.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5000003… |
| 'Workspace.SYIRGI7.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1686… |
| 'Workspace.SYIRGI7.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.SYIRGI7.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.9406967… |
| 'Workspace.SYIRGI7.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.SYIRGI7.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.SYIRGI7.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 0.4001… |
| 'Workspace.SYIRGI7.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.4999998… |
| 'Workspace.SYIRGI7.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.SYIRGI7.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.464132… |
| 'Workspace.SYIRGI7.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -4.220008… |
| 'Workspace.SYIRGI7.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.322198… |
| 'Workspace.SYIRGI7.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.SYIRGI7.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.SYIRGI7.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.101… |
| 'Workspace.SYIRGI7.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.018277… |
| 'Workspace.SYIRGI7.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.3001… |
| 'Workspace.SYIRGI7.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.149… |
| 'Workspace.SYIRGI7.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.5762786… |
| 'Workspace.SYIRGI7.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.0518… |
| 'Workspace.SYIRGI7.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1920928… |
| 'Workspace.SYIRGI7.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1920928… |
| 'Workspace.SYIRGI7.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.SYIRGI7.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.54… |
| 'Workspace.SYIRGI7.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.379… |
| 'Workspace.SYIRGI7.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1686… |
| 'Workspace.SYIRGI7.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SYIRGI7.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.344650… |
| 'Workspace.SYIRGI7.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.SYIRGI7.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.SYIRGI7.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.SYIRGI7.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.420… |
| 'Workspace.SYIRGI7.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.40… |
| 'Workspace.SYIRGI7.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SYIRGI7.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SYIRGI7.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.999999… |
| 'Workspace.SYIRGI7.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1, 0.563… |
| 'Workspace.SYIRGI7.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1, 0.563… |
| 'Workspace.SYIRGI7.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.058594… |
| 'Workspace.SYIRGI7.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SYIRGI7.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 1.6000… |
| 'Workspace.SYIRGI7.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9999999… |
| 'Workspace.SYIRGI7.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9999999… |
| 'Workspace.SYIRGI7.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9999999… |
| 'Workspace.SYIRGI7.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SeoulKD.8BitController.Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.8BitController.Handle.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0325415… |
| 'Workspace.SeoulKD.8BitController.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.2784810… |
| 'Workspace.SeoulKD.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SeoulKD.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.SeoulKD.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.SeoulKD.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SeoulKD.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.pose' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.pose.RthroIdlePose.Weight' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.SeoulKD.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.SeoulKD.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9921589… |
| 'Workspace.SeoulKD.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.0895277… |
| 'Workspace.SeoulKD.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.SeoulKD.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.SeoulKD.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3896427… |
| 'Workspace.SeoulKD.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1978399… |
| 'Workspace.SeoulKD.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SeoulKD.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SeoulKD.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.SeoulKD.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.SeoulKD.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SeoulKD.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.SeoulKD.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.SeoulKD.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.SeoulKD.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.SeoulKD.LeftFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0044203… |
| 'Workspace.SeoulKD.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0044205… |
| 'Workspace.SeoulKD.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8361780… |
| 'Workspace.SeoulKD.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0777419… |
| 'Workspace.SeoulKD.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.054612… |
| 'Workspace.SeoulKD.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6933399… |
| 'Workspace.SeoulKD.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0791994… |
| 'Workspace.SeoulKD.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.127430… |
| 'Workspace.SeoulKD.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6270952… |
| 'Workspace.SeoulKD.LeftLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.002462… |
| 'Workspace.SeoulKD.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.005055… |
| 'Workspace.SeoulKD.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7419999… |
| 'Workspace.SeoulKD.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.038313… |
| 'Workspace.SeoulKD.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1471741… |
| 'Workspace.SeoulKD.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2811447… |
| 'Workspace.SeoulKD.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2811447… |
| 'Workspace.SeoulKD.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5698586… |
| 'Workspace.SeoulKD.LeftUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.075534… |
| 'Workspace.SeoulKD.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.026260… |
| 'Workspace.SeoulKD.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7596539… |
| 'Workspace.SeoulKD.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.500000… |
| 'Workspace.SeoulKD.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.6962258… |
| 'Workspace.SeoulKD.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.4999999… |
| 'Workspace.SeoulKD.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SeoulKD.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.680857… |
| 'Workspace.SeoulKD.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -3.623962… |
| 'Workspace.SeoulKD.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -7.261522… |
| 'Workspace.SeoulKD.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SeoulKD.Pal Hair.Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.6574800… |
| 'Workspace.SeoulKD.Pal Hair.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.7598299… |
| 'Workspace.SeoulKD.RightFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8361780… |
| 'Workspace.SeoulKD.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.004554… |
| 'Workspace.SeoulKD.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.004554… |
| 'Workspace.SeoulKD.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6933399… |
| 'Workspace.SeoulKD.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.077919… |
| 'Workspace.SeoulKD.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0540800… |
| 'Workspace.SeoulKD.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6270951… |
| 'Workspace.SeoulKD.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.080102… |
| 'Workspace.SeoulKD.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1268978… |
| 'Workspace.SeoulKD.RightLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7419999… |
| 'Workspace.SeoulKD.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0023289… |
| 'Workspace.SeoulKD.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0053289… |
| 'Workspace.SeoulKD.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5698585… |
| 'Workspace.SeoulKD.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0374107… |
| 'Workspace.SeoulKD.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.147589… |
| 'Workspace.SeoulKD.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.281589… |
| 'Workspace.SeoulKD.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.281589… |
| 'Workspace.SeoulKD.RightUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7596539… |
| 'Workspace.SeoulKD.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0755339… |
| 'Workspace.SeoulKD.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0265339… |
| 'Workspace.SeoulKD.Scarf.Handle.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.SeoulKD.Scarf.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.0313193… |
| 'Workspace.SeoulKD.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SeoulKD.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SeoulKD.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.757948… |
| 'Workspace.SeoulKD.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.911444… |
| 'Workspace.SeoulKD.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.911444… |
| 'Workspace.SeoulKD.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.058594… |
| 'Workspace.SeoulKD.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SeoulKD.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.8154158… |
| 'Workspace.SeoulKD.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7579999… |
| 'Workspace.SeoulKD.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9109999… |
| 'Workspace.SeoulKD.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.9109999… |
| 'Workspace.SeoulKD.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -5.960464… |
| 'Workspace.SeoulKD.WatermelonHat.Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.SeoulKD.WatermelonHat.Handle.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.SeoulKD.WatermelonHat.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.5820915… |
| 'Workspace.TopPoints.AllowTitles' | BoolValue | boolean | 1 | 0 | — | — | — | true |
| 'Workspace.TopPoints.TitleColor' | Color3Value | Color3 | 1 | 0 | — | — | — | Color3.new(0.5372549295425415, 0.7176470… |
| 'Workspace.TopPoints.TitleOrder' | IntValue | number | 1 | 0 | -2 | -2 | — | -2 |
| 'Workspace.Wisitrap09.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.Wisitrap09.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Wisitrap09.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Wisitrap09.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Wisitrap09.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Wisitrap09.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Wisitrap09.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Wisitrap09.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Wisitrap09.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Wisitrap09.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.Wisitrap09.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.Wisitrap09.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.Wisitrap09.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.Wisitrap09.BIPIHeadphones.Handle.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.6583895… |
| 'Workspace.Wisitrap09.BIPIHeadphones.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.6824784… |
| 'Workspace.Wisitrap09.Books2Accessory.Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.Books2Accessory.Handle.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0662202… |
| 'Workspace.Wisitrap09.Books2Accessory.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.0240592… |
| 'Workspace.Wisitrap09.HandleAccessory.Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.HandleAccessory.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 4.7344560… |
| 'Workspace.Wisitrap09.HandleAccessory.Handle.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.006088… |
| 'Workspace.Wisitrap09.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9921589… |
| 'Workspace.Wisitrap09.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.0895277… |
| 'Workspace.Wisitrap09.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.Wisitrap09.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.Wisitrap09.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3896427… |
| 'Workspace.Wisitrap09.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1978399… |
| 'Workspace.Wisitrap09.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.Wisitrap09.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.Wisitrap09.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.Wisitrap09.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.Wisitrap09.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.Wisitrap09.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.Wisitrap09.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.Wisitrap09.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.Wisitrap09.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.Wisitrap09.LeftFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000237… |
| 'Workspace.Wisitrap09.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000237… |
| 'Workspace.Wisitrap09.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8361780… |
| 'Workspace.Wisitrap09.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.117080… |
| 'Workspace.Wisitrap09.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.117080… |
| 'Workspace.Wisitrap09.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6933407… |
| 'Workspace.Wisitrap09.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.189898… |
| 'Workspace.Wisitrap09.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.189897… |
| 'Workspace.Wisitrap09.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6270949… |
| 'Workspace.Wisitrap09.LeftLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.007119… |
| 'Workspace.Wisitrap09.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.054328… |
| 'Workspace.Wisitrap09.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7419999… |
| 'Workspace.Wisitrap09.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.307411… |
| 'Workspace.Wisitrap09.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.307411… |
| 'Workspace.Wisitrap09.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1925883… |
| 'Workspace.Wisitrap09.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1925883… |
| 'Workspace.Wisitrap09.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5698601… |
| 'Workspace.Wisitrap09.LeftUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.075533… |
| 'Workspace.Wisitrap09.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.075534… |
| 'Workspace.Wisitrap09.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7596539… |
| 'Workspace.Wisitrap09.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.499999… |
| 'Workspace.Wisitrap09.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.6962258… |
| 'Workspace.Wisitrap09.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5000004… |
| 'Workspace.Wisitrap09.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 4.1723251… |
| 'Workspace.Wisitrap09.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.3042394… |
| 'Workspace.Wisitrap09.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.4836277… |
| 'Workspace.Wisitrap09.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.4461729… |
| 'Workspace.Wisitrap09.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.5762786… |
| 'Workspace.Wisitrap09.Pal Hair.Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.6574800… |
| 'Workspace.Wisitrap09.Pal Hair.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.7598299… |
| 'Workspace.Wisitrap09.RightFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.8361780… |
| 'Workspace.Wisitrap09.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0002370… |
| 'Workspace.Wisitrap09.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0002366… |
| 'Workspace.Wisitrap09.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6933391… |
| 'Workspace.Wisitrap09.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1170799… |
| 'Workspace.Wisitrap09.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1170797… |
| 'Workspace.Wisitrap09.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6270953… |
| 'Workspace.Wisitrap09.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1898980… |
| 'Workspace.Wisitrap09.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1898977… |
| 'Workspace.Wisitrap09.RightLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7419999… |
| 'Workspace.Wisitrap09.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0071202… |
| 'Workspace.Wisitrap09.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0543293… |
| 'Workspace.Wisitrap09.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5698581… |
| 'Workspace.Wisitrap09.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3074108… |
| 'Workspace.Wisitrap09.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3074109… |
| 'Workspace.Wisitrap09.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.192588… |
| 'Workspace.Wisitrap09.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.192588… |
| 'Workspace.Wisitrap09.RightUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7596539… |
| 'Workspace.Wisitrap09.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0755339… |
| 'Workspace.Wisitrap09.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0755341… |
| 'Workspace.Wisitrap09.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.Wisitrap09.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 9.5367431… |
| 'Workspace.Wisitrap09.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 9.5367431… |
| 'Workspace.Wisitrap09.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.999998… |
| 'Workspace.Wisitrap09.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.999998… |
| 'Workspace.Wisitrap09.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.999998… |
| 'Workspace.Wisitrap09.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 9.6269297… |
| 'Workspace.Wisitrap09.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 9.5367431… |
| 'Workspace.Wisitrap09.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.8154158… |
| 'Workspace.Wisitrap09.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.0000009… |
| 'Workspace.Wisitrap09.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.0000009… |
| 'Workspace.Wisitrap09.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.0000009… |
| 'Workspace.Wisitrap09.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 9.5367431… |
| 'Workspace.Wisitrap09.Yama Cape.Handle.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 1, -0.… |
| 'Workspace.Wisitrap09.Yama Cape.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.3628864… |
| 'Workspace.kayulr7.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.kayulr7.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.kayulr7.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.kayulr7.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.kayulr7.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.kayulr7.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.kayulr7.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.kayulr7.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.kayulr7.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.kayulr7.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.kayulr7.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.kayulr7.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.kayulr7.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.pose' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.pose.RthroIdlePose.Weight' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.kayulr7.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.kayulr7.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.kayulr7.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9921589… |
| 'Workspace.kayulr7.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.0895277… |
| 'Workspace.kayulr7.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.kayulr7.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.kayulr7.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3896427… |
| 'Workspace.kayulr7.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1978399… |
| 'Workspace.kayulr7.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 0.8500000238418579 | 0.8500000238418579 | — | 0.8500000238418579 |
| 'Workspace.kayulr7.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 0.8999999761581421 | 0.8999999761581421 | — | 0.8999999761581421 |
| 'Workspace.kayulr7.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.kayulr7.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.kayulr7.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 0.699999988079071 | 0.699999988079071 | — | 0.699999988079071 |
| 'Workspace.kayulr7.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 0.949999988079071 | 0.949999988079071 | — | 0.949999988079071 |
| 'Workspace.kayulr7.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.kayulr7.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.kayulr7.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.kayulr7.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.788139… |
| 'Workspace.kayulr7.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0182774… |
| 'Workspace.kayulr7.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.kayulr7.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.kayulr7.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.017243… |
| 'Workspace.kayulr7.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1085174… |
| 'Workspace.kayulr7.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459886… |
| 'Workspace.kayulr7.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.kayulr7.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1874169… |
| 'Workspace.kayulr7.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.174442… |
| 'Workspace.kayulr7.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623244… |
| 'Workspace.kayulr7.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.kayulr7.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9802322… |
| 'Workspace.kayulr7.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.kayulr7.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.kayulr7.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.160127… |
| 'Workspace.kayulr7.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.022783… |
| 'Workspace.kayulr7.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.kayulr7.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.kayulr7.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489318… |
| 'Workspace.kayulr7.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.kayulr7.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.9406967… |
| 'Workspace.kayulr7.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.kayulr7.LongStraightHair.Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.6583895… |
| 'Workspace.kayulr7.LongStraightHair.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.6520800… |
| 'Workspace.kayulr7.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.kayulr7.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.349282… |
| 'Workspace.kayulr7.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3261278… |
| 'Workspace.kayulr7.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3492811… |
| 'Workspace.kayulr7.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.kayulr7.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.212736… |
| 'Workspace.kayulr7.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000001… |
| 'Workspace.kayulr7.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.070802… |
| 'Workspace.kayulr7.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.kayulr7.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.kayulr7.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.101… |
| 'Workspace.kayulr7.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.018277… |
| 'Workspace.kayulr7.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.kayulr7.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459872… |
| 'Workspace.kayulr7.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0172429… |
| 'Workspace.kayulr7.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.090098… |
| 'Workspace.kayulr7.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.kayulr7.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623249… |
| 'Workspace.kayulr7.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.187417… |
| 'Workspace.kayulr7.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1928601… |
| 'Workspace.kayulr7.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.kayulr7.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.54… |
| 'Workspace.kayulr7.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.379… |
| 'Workspace.kayulr7.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.kayulr7.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489327… |
| 'Workspace.kayulr7.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1601286… |
| 'Workspace.kayulr7.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0227840… |
| 'Workspace.kayulr7.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.kayulr7.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.kayulr7.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.kayulr7.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.420… |
| 'Workspace.kayulr7.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.40… |
| 'Workspace.kayulr7.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.kayulr7.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.kayulr7.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.kayulr7.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.kayulr7.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.kayulr7.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.kayulr7.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.9644888… |
| 'Workspace.kayulr7.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.kayulr7.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3034231… |
| 'Workspace.kayulr7.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.kayulr7.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.kayulr7.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.kayulr7.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.pikachihuyyyyy.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.pikachihuyyyyy.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.pikachihuyyyyy.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.pikachihuyyyyy.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.pikachihuyyyyy.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.pikachihuyyyyy.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.pikachihuyyyyy.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.pikachihuyyyyy.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.pikachihuyyyyy.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.pikachihuyyyyy.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.pikachihuyyyyy.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.pikachihuyyyyy.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.pikachihuyyyyy.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.pikachihuyyyyy.GoldCirclet.Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.pikachihuyyyyy.GoldCirclet.Handle.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9802322… |
| 'Workspace.pikachihuyyyyy.GoldCirclet.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.7476518… |
| 'Workspace.pikachihuyyyyy.GoldHorns.Handle.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.pikachihuyyyyy.GoldHorns.Handle.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.1014279… |
| 'Workspace.pikachihuyyyyy.GoldHorns.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.6886639… |
| 'Workspace.pikachihuyyyyy.Head.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.pikachihuyyyyy.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9921589… |
| 'Workspace.pikachihuyyyyy.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.0895277… |
| 'Workspace.pikachihuyyyyy.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.pikachihuyyyyy.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8502382… |
| 'Workspace.pikachihuyyyyy.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.3896427… |
| 'Workspace.pikachihuyyyyy.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1978399… |
| 'Workspace.pikachihuyyyyy.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 0.9399999976158142 | 0.9399999976158142 | — | 0.9399999976158142 |
| 'Workspace.pikachihuyyyyy.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 0.8999999761581421 | 0.8999999761581421 | — | 0.8999999761581421 |
| 'Workspace.pikachihuyyyyy.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0.5 | 0.5 | — | 0.5 |
| 'Workspace.pikachihuyyyyy.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.pikachihuyyyyy.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 0.8899999856948853 | 0.8899999856948853 | — | 0.8899999856948853 |
| 'Workspace.pikachihuyyyyy.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.pikachihuyyyyy.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.pikachihuyyyyy.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.pikachihuyyyyy.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.pikachihuyyyyy.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.788139… |
| 'Workspace.pikachihuyyyyy.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0182774… |
| 'Workspace.pikachihuyyyyy.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.pikachihuyyyyy.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.pikachihuyyyyy.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.017243… |
| 'Workspace.pikachihuyyyyy.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1085174… |
| 'Workspace.pikachihuyyyyy.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459886… |
| 'Workspace.pikachihuyyyyy.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.pikachihuyyyyy.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1874169… |
| 'Workspace.pikachihuyyyyy.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.174442… |
| 'Workspace.pikachihuyyyyy.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623244… |
| 'Workspace.pikachihuyyyyy.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.pikachihuyyyyy.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9802322… |
| 'Workspace.pikachihuyyyyy.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.pikachihuyyyyy.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.pikachihuyyyyy.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.160127… |
| 'Workspace.pikachihuyyyyy.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.022783… |
| 'Workspace.pikachihuyyyyy.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.pikachihuyyyyy.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.pikachihuyyyyy.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489318… |
| 'Workspace.pikachihuyyyyy.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.pikachihuyyyyy.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.9406967… |
| 'Workspace.pikachihuyyyyy.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.pikachihuyyyyy.LongStraightHair.Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.6583895… |
| 'Workspace.pikachihuyyyyy.LongStraightHair.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.6520800… |
| 'Workspace.pikachihuyyyyy.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.pikachihuyyyyy.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.349282… |
| 'Workspace.pikachihuyyyyy.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3261278… |
| 'Workspace.pikachihuyyyyy.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3492811… |
| 'Workspace.pikachihuyyyyy.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.pikachihuyyyyy.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.212736… |
| 'Workspace.pikachihuyyyyy.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000001… |
| 'Workspace.pikachihuyyyyy.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.070802… |
| 'Workspace.pikachihuyyyyy.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.pikachihuyyyyy.NerdGlasses.Handle.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.9362930… |
| 'Workspace.pikachihuyyyyy.NerdGlasses.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3020100… |
| 'Workspace.pikachihuyyyyy.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.pikachihuyyyyy.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.101… |
| 'Workspace.pikachihuyyyyy.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.018277… |
| 'Workspace.pikachihuyyyyy.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.pikachihuyyyyy.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459872… |
| 'Workspace.pikachihuyyyyy.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0172429… |
| 'Workspace.pikachihuyyyyy.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.090098… |
| 'Workspace.pikachihuyyyyy.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.pikachihuyyyyy.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623249… |
| 'Workspace.pikachihuyyyyy.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.187417… |
| 'Workspace.pikachihuyyyyy.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1928601… |
| 'Workspace.pikachihuyyyyy.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.pikachihuyyyyy.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.54… |
| 'Workspace.pikachihuyyyyy.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.379… |
| 'Workspace.pikachihuyyyyy.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.pikachihuyyyyy.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489327… |
| 'Workspace.pikachihuyyyyy.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1601286… |
| 'Workspace.pikachihuyyyyy.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0227840… |
| 'Workspace.pikachihuyyyyy.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.pikachihuyyyyy.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.pikachihuyyyyy.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.pikachihuyyyyy.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.420… |
| 'Workspace.pikachihuyyyyy.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.40… |
| 'Workspace.pikachihuyyyyy.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.pikachihuyyyyy.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.pikachihuyyyyy.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.pikachihuyyyyy.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.pikachihuyyyyy.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.pikachihuyyyyy.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.pikachihuyyyyy.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.9644888… |
| 'Workspace.pikachihuyyyyy.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.pikachihuyyyyy.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3034231… |
| 'Workspace.pikachihuyyyyy.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.pikachihuyyyyy.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.pikachihuyyyyy.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.pikachihuyyyyy.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.smoothie_0260.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.smoothie_0260.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.smoothie_0260.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.smoothie_0260.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.smoothie_0260.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.smoothie_0260.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.smoothie_0260.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.smoothie_0260.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.smoothie_0260.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.smoothie_0260.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.smoothie_0260.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.smoothie_0260.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.smoothie_0260.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.smoothie_0260.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.093… |
| 'Workspace.smoothie_0260.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, -0.… |
| 'Workspace.smoothie_0260.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0.6000… |
| 'Workspace.smoothie_0260.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0.6000… |
| 'Workspace.smoothie_0260.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.586… |
| 'Workspace.smoothie_0260.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1961951… |
| 'Workspace.smoothie_0260.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.smoothie_0260.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.smoothie_0260.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0.009999999776482582 | 0.009999999776482582 | — | 0.009999999776482582 |
| 'Workspace.smoothie_0260.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.smoothie_0260.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.smoothie_0260.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.smoothie_0260.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.smoothie_0260.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.smoothie_0260.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.smoothie_0260.LeftFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0036838… |
| 'Workspace.smoothie_0260.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0036840… |
| 'Workspace.smoothie_0260.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6061512… |
| 'Workspace.smoothie_0260.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.017243… |
| 'Workspace.smoothie_0260.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1085174… |
| 'Workspace.smoothie_0260.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459886… |
| 'Workspace.smoothie_0260.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1874169… |
| 'Workspace.smoothie_0260.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.174442… |
| 'Workspace.smoothie_0260.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623244… |
| 'Workspace.smoothie_0260.LeftLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0036814… |
| 'Workspace.smoothie_0260.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0036818… |
| 'Workspace.smoothie_0260.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6061464… |
| 'Workspace.smoothie_0260.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.160127… |
| 'Workspace.smoothie_0260.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.022783… |
| 'Workspace.smoothie_0260.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.smoothie_0260.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.smoothie_0260.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489318… |
| 'Workspace.smoothie_0260.LeftUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.021264… |
| 'Workspace.smoothie_0260.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.021264… |
| 'Workspace.smoothie_0260.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6560385… |
| 'Workspace.smoothie_0260.LongStraightHair.Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.6583895… |
| 'Workspace.smoothie_0260.LongStraightHair.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.6520800… |
| 'Workspace.smoothie_0260.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.349282… |
| 'Workspace.smoothie_0260.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3261278… |
| 'Workspace.smoothie_0260.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3492811… |
| 'Workspace.smoothie_0260.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.smoothie_0260.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.212736… |
| 'Workspace.smoothie_0260.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000001… |
| 'Workspace.smoothie_0260.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.070802… |
| 'Workspace.smoothie_0260.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.smoothie_0260.RightFoot.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6061524… |
| 'Workspace.smoothie_0260.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.003683… |
| 'Workspace.smoothie_0260.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.003683… |
| 'Workspace.smoothie_0260.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459872… |
| 'Workspace.smoothie_0260.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0172429… |
| 'Workspace.smoothie_0260.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.090098… |
| 'Workspace.smoothie_0260.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623249… |
| 'Workspace.smoothie_0260.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.187417… |
| 'Workspace.smoothie_0260.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1928601… |
| 'Workspace.smoothie_0260.RightLowerLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6061464… |
| 'Workspace.smoothie_0260.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.003681… |
| 'Workspace.smoothie_0260.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.003681… |
| 'Workspace.smoothie_0260.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489327… |
| 'Workspace.smoothie_0260.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1601286… |
| 'Workspace.smoothie_0260.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0227840… |
| 'Workspace.smoothie_0260.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.smoothie_0260.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.smoothie_0260.RightUpperLeg.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6560385… |
| 'Workspace.smoothie_0260.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0212647… |
| 'Workspace.smoothie_0260.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0212645… |
| 'Workspace.smoothie_0260.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.smoothie_0260.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.smoothie_0260.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.smoothie_0260.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.smoothie_0260.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.smoothie_0260.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.smoothie_0260.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.9644888… |
| 'Workspace.smoothie_0260.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.smoothie_0260.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3034231… |
| 'Workspace.smoothie_0260.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.smoothie_0260.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.smoothie_0260.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.smoothie_0260.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.xxKoPiToPixx.Animate.ScaleDampeningPercent' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.xxKoPiToPixx.Animate.cheer' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.climb' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.dance' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.dance.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.xxKoPiToPixx.Animate.dance.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.xxKoPiToPixx.Animate.dance.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.xxKoPiToPixx.Animate.dance2' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.dance2.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.xxKoPiToPixx.Animate.dance2.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.xxKoPiToPixx.Animate.dance2.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.xxKoPiToPixx.Animate.dance3' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.dance3.Animation1.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.xxKoPiToPixx.Animate.dance3.Animation2.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.xxKoPiToPixx.Animate.dance3.Animation3.Weight' | NumberValue | number | 1 | 0 | 10 | 10 | — | 10 |
| 'Workspace.xxKoPiToPixx.Animate.fall' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.idle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.idle.Animation1.Weight' | NumberValue | number | 1 | 0 | 9 | 9 | — | 9 |
| 'Workspace.xxKoPiToPixx.Animate.idle.Animation2.Weight' | NumberValue | number | 1 | 0 | 1 | 1 | — | 1 |
| 'Workspace.xxKoPiToPixx.Animate.jump' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.laugh' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.mood' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.point' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.run' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.sit' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.swim' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.swimidle' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.toollunge' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.toolnone' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.toolslash' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.walk' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Animate.wave' | StringValue | string | 1 | 0 | — | — | — | "" |
| 'Workspace.xxKoPiToPixx.Head.FaceCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.093… |
| 'Workspace.xxKoPiToPixx.Head.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, -0.… |
| 'Workspace.xxKoPiToPixx.Head.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0.6000… |
| 'Workspace.xxKoPiToPixx.Head.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0.6000… |
| 'Workspace.xxKoPiToPixx.Head.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.586… |
| 'Workspace.xxKoPiToPixx.Head.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.1961951… |
| 'Workspace.xxKoPiToPixx.Humanoid.BodyDepthScale' | NumberValue | number | 1 | 0 | 0.8500000238418579 | 0.8500000238418579 | — | 0.8500000238418579 |
| 'Workspace.xxKoPiToPixx.Humanoid.BodyHeightScale' | NumberValue | number | 1 | 0 | 0.8999999761581421 | 0.8999999761581421 | — | 0.8999999761581421 |
| 'Workspace.xxKoPiToPixx.Humanoid.BodyProportionScale' | NumberValue | number | 1 | 0 | 0.5 | 0.5 | — | 0.5 |
| 'Workspace.xxKoPiToPixx.Humanoid.BodyTypeScale' | NumberValue | number | 1 | 0 | 0 | 0 | — | 0 |
| 'Workspace.xxKoPiToPixx.Humanoid.BodyWidthScale' | NumberValue | number | 1 | 0 | 0.699999988079071 | 0.699999988079071 | — | 0.699999988079071 |
| 'Workspace.xxKoPiToPixx.Humanoid.HeadScale' | NumberValue | number | 1 | 0 | 0.949999988079071 | 0.949999988079071 | — | 0.949999988079071 |
| 'Workspace.xxKoPiToPixx.HumanoidRootPart.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2, 2, 1]] |
| 'Workspace.xxKoPiToPixx.HumanoidRootPart.RootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, 0, 0]] |
| 'Workspace.xxKoPiToPixx.HumanoidRootPart.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0, -0.349… |
| 'Workspace.xxKoPiToPixx.LeftFoot.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.788139… |
| 'Workspace.xxKoPiToPixx.LeftFoot.LeftFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0182774… |
| 'Workspace.xxKoPiToPixx.LeftFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.xxKoPiToPixx.LeftHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.xxKoPiToPixx.LeftHand.LeftGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.017243… |
| 'Workspace.xxKoPiToPixx.LeftHand.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1085174… |
| 'Workspace.xxKoPiToPixx.LeftHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459886… |
| 'Workspace.xxKoPiToPixx.LeftLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.xxKoPiToPixx.LeftLowerArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1874169… |
| 'Workspace.xxKoPiToPixx.LeftLowerArm.LeftWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.174442… |
| 'Workspace.xxKoPiToPixx.LeftLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623244… |
| 'Workspace.xxKoPiToPixx.LeftLowerLeg.LeftAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -1.192092… |
| 'Workspace.xxKoPiToPixx.LeftLowerLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 2.9802322… |
| 'Workspace.xxKoPiToPixx.LeftLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.xxKoPiToPixx.LeftUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.xxKoPiToPixx.LeftUpperArm.LeftElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.160127… |
| 'Workspace.xxKoPiToPixx.LeftUpperArm.LeftShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.022783… |
| 'Workspace.xxKoPiToPixx.LeftUpperArm.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.xxKoPiToPixx.LeftUpperArm.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.2390074… |
| 'Workspace.xxKoPiToPixx.LeftUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489318… |
| 'Workspace.xxKoPiToPixx.LeftUpperLeg.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 5.9604644… |
| 'Workspace.xxKoPiToPixx.LeftUpperLeg.LeftKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.9406967… |
| 'Workspace.xxKoPiToPixx.LeftUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.xxKoPiToPixx.LongStraightHair.Handle.HairAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.6583895… |
| 'Workspace.xxKoPiToPixx.LongStraightHair.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.6520800… |
| 'Workspace.xxKoPiToPixx.LowerTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.xxKoPiToPixx.LowerTorso.LeftHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.349282… |
| 'Workspace.xxKoPiToPixx.LowerTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3261278… |
| 'Workspace.xxKoPiToPixx.LowerTorso.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3492811… |
| 'Workspace.xxKoPiToPixx.LowerTorso.RootRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.xxKoPiToPixx.LowerTorso.WaistBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.212736… |
| 'Workspace.xxKoPiToPixx.LowerTorso.WaistCenterAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.000001… |
| 'Workspace.xxKoPiToPixx.LowerTorso.WaistFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -9.070802… |
| 'Workspace.xxKoPiToPixx.LowerTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -8.940696… |
| 'Workspace.xxKoPiToPixx.NerdGlasses.Handle.FaceFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.9362930… |
| 'Workspace.xxKoPiToPixx.NerdGlasses.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3020100… |
| 'Workspace.xxKoPiToPixx.RightFoot.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 0.2999… |
| 'Workspace.xxKoPiToPixx.RightFoot.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.101… |
| 'Workspace.xxKoPiToPixx.RightFoot.RightFootAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.018277… |
| 'Workspace.xxKoPiToPixx.RightHand.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.xxKoPiToPixx.RightHand.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.5459872… |
| 'Workspace.xxKoPiToPixx.RightHand.RightGripAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0172429… |
| 'Workspace.xxKoPiToPixx.RightHand.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.090098… |
| 'Workspace.xxKoPiToPixx.RightLowerArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.xxKoPiToPixx.RightLowerArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6623249… |
| 'Workspace.xxKoPiToPixx.RightLowerArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.187417… |
| 'Workspace.xxKoPiToPixx.RightLowerArm.RightWristRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1928601… |
| 'Workspace.xxKoPiToPixx.RightLowerLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.1930… |
| 'Workspace.xxKoPiToPixx.RightLowerLeg.RightAnkleRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.54… |
| 'Workspace.xxKoPiToPixx.RightLowerLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.379… |
| 'Workspace.xxKoPiToPixx.RightUpperArm.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.xxKoPiToPixx.RightUpperArm.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.7489327… |
| 'Workspace.xxKoPiToPixx.RightUpperArm.RightElbowRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.1601286… |
| 'Workspace.xxKoPiToPixx.RightUpperArm.RightShoulderAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.0227840… |
| 'Workspace.xxKoPiToPixx.RightUpperArm.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.xxKoPiToPixx.RightUpperArm.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.239006… |
| 'Workspace.xxKoPiToPixx.RightUpperLeg.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1, 1.2166… |
| 'Workspace.xxKoPiToPixx.RightUpperLeg.RightHipRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, 0.420… |
| 'Workspace.xxKoPiToPixx.RightUpperLeg.RightKneeRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0, -0.40… |
| 'Workspace.xxKoPiToPixx.RobloxVisor2019.Handle.HatAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 8.6583904… |
| 'Workspace.xxKoPiToPixx.RobloxVisor2019.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.2879335… |
| 'Workspace.xxKoPiToPixx.Shoes-Sneakers_2-White_Left.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3192195… |
| 'Workspace.xxKoPiToPixx.Shoes-Sneakers_2-White_Right.Handle.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.3192195… |
| 'Workspace.xxKoPiToPixx.UpperTorso.AvatarPartScaleType' | StringValue | string | 1 | 0 | — | — | — | "Classic" |
| 'Workspace.xxKoPiToPixx.UpperTorso.BodyBackAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.xxKoPiToPixx.UpperTorso.BodyFrontAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.xxKoPiToPixx.UpperTorso.LeftCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.xxKoPiToPixx.UpperTorso.LeftShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.xxKoPiToPixx.UpperTorso.LeftShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: -0.613244… |
| 'Workspace.xxKoPiToPixx.UpperTorso.NeckAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.9644888… |
| 'Workspace.xxKoPiToPixx.UpperTorso.NeckRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |
| 'Workspace.xxKoPiToPixx.UpperTorso.OriginalSize' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 1.3034231… |
| 'Workspace.xxKoPiToPixx.UpperTorso.RightCollarAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.xxKoPiToPixx.UpperTorso.RightShoulderRigAttachment.JointRotation.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.xxKoPiToPixx.UpperTorso.RightShoulderRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 0.6132453… |
| 'Workspace.xxKoPiToPixx.UpperTorso.WaistRigAttachment.OriginalPosition' | Vector3Value | Vector3 | 1 | 0 | — | — | — | nil --[[unserialisable vector: 3.8743019… |

## Numeric argument positions

- Every numeric argument position observed on any remote, with its
- observed range and how often the value moved up or down.

No numeric argument position was observed.

