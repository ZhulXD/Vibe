# AIDump documentation set

---

## What this is

- Game: Ugc (PlaceId 3281073759)
- JobId: d18d0970-ae3d-4d41-9264-033d794322a0
- Executor: Delta 1.1.740.931
- Attached: 2026-10-04T11:33:29Z
- Exports written: 2, last at 2026-10-04T11:34:10Z

## How to read this set

- Every statement in these files is a measurement taken during
- this session. Nothing here interprets, explains or guesses.
- Counts marked exact remain exact even where sample lists are
- truncated; truncation is always stated next to the list.
- Absence from a document is not evidence of absence in the game.
- 07-COVERAGE.md lists what was not observed. Read it before
- concluding that something does not exist.

## Coverage totals

| Measure | Count |
| --- | --- |
| Remotes discovered | 9 |
| Remotes with observed traffic | 0 |
| Remotes never observed | 9 |
| Outgoing calls recorded | 0 |
| Incoming calls recorded | 0 |
| Scripts found | 4000 |
| Scripts readable by the client | 3991 |
| Attributes tracked | 54 |
| Value objects tracked | 1020 |
| State transitions recorded | 1 |

## Recommended reading order

- 01-ENVIRONMENT.md - what this client can see, and what it cannot.
- 07-COVERAGE.md - the limits of this run. Read first.
- 03-REMOTES.md then the 04-REMOTE-*.md files - the protocol.
- 05-SCRIPTS.md - which code sends and receives each call.
- 06-STATES.md - the numbers that moved.
- --[[ AIDump: line withheld as unverified assertion (because) ]]

## File manifest

| File | Contents | Size |
| --- | --- | :---: |
| '01-ENVIRONMENT.md' | Place metadata, executor capability probe, reflection source | 2506 bytes |
| '02-STRUCTURE.md' | Instance tree with properties and attributes | 573635 bytes |
| '03-REMOTES.md' | One row per remote with argument schema and traffic counts | 1656 bytes |
| '05-SCRIPTS.md' | Script inventory, decompilation method, call-site cross-reference | 452204 bytes |
| '06-STATES.md' | Attributes, value objects and numeric argument positions | 156237 bytes |
| '07-COVERAGE.md' | What was not observed and what could not be observed | 3366 bytes |
| 'raw/coverage.json' | Machine-readable limits and capability report | 4171 bytes |
| 'raw/instances.json' | Full instance tree with all readable properties | 4837438 bytes |
| 'raw/remotes.json' | Full remote aggregates, samples and timelines | 5221 bytes |
| 'raw/scripts.json' | Script inventory with decompilation metadata | 978545 bytes |
| 'raw/states.json' | Attribute and value-object observation records | 314147 bytes |

