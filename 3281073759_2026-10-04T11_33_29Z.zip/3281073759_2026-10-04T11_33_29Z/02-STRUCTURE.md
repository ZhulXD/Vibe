# 02 - Structure

---

Instances walked: 8000 of at most 8000 (budget).
Nil-parented instances included: 0.

- `?` after a property value means no default is known for that
- property, so equality with the default could not be checked.

## Instance tree

```text

```
`- Ugc (DataModel)
      Archivable = true  ?
      Capabilities = nil --[[unserialisable userdata: ]]  ?
      ClassName = "DataModel"  ?
      CreatorId = 38617013  ?
      CreatorType = Enum.CreatorType.User  ?
      DataCost = 235600  ?
      Environment = ""  ?
      GameId = 1182609799  ?
      GearGenreSetting = Enum.GearGenreSetting.AllGenres  ?
      Genre = Enum.Genre.All  ?
      IsPioneerBuild = false  ?
      IsSFFlagsLoaded = true  ?
      JobId = "d18d0970-ae3d-4d41-9264-033d794322a0"  ?
      MatchmakingType = Enum.MatchmakingType.Default  ?
      Name = "Ugc"  *
      PioneerSource = Enum.PioneerSource.Roblox  ?
      PlaceId = 3281073759  ?
      PlaceVersion = 169  ?
      RunService = :GetService("Run Service")game  ?
      Sandboxed = false  ?
      SourceAssetId = -1  ?
      UniqueId = "00000000-0000-0000-0000-000000000000"  ?
      VIPServerId = ""  ?
      VIPServerOwnerId = 0  ?
      Workspace = workspace  ?
      archivable = true  ?
      className = "DataModel"  ?
      lighting = :GetService("Lighting")game  ?
      workspace = workspace  ?
  |- Workspace (Workspace)
        AirDensity = 0.0012000000569969416  ?
        AirTurbulenceIntensity = 0  ?
        AllowThirdPartySales = false  ?
        Archivable = true  ?
        AuthorityMode = Enum.AuthorityMode.Automatic  ?
        AutoSimulate = true  ?
        Capabilities = nil --[[unserialisable userdata: ]]  ?
        ClassName = "Workspace"  ?
        ClientAnimatorThrottling = Enum.ClientAnimatorThrottlingMode.Default  ?
        DataCost = 75690  ?
        DistributedGameTime = 18.887501071207225  ?
        FallHeightEnabled = true  ?
        FallenPartsDestroyHeight = -500  ?
        FilteringEnabled = true  ?
        GlobalWind = nil --[[unserialisable vector: 3, 0, 6]]  ?
        Gravity = 196.1999969482422  *
        GravityDirection = nil --[[unserialisable vector: 0, -1, 0]]  ?
        InsertPoint = nil --[[unserialisable vector: 0, 0, 0]]  ?
        InterpolationThrottling = Enum.InterpolationThrottlingMode.Default  ?
        LevelOfDetail = Enum.ModelLevelOfDetail.Automatic  ?
        LuauTypeCheckMode = Enum.LuauTypeCheckMode.Default  ?
        ModelStreamingMode = Enum.ModelStreamingMode.Default  ?
        Name = "Workspace"
        PhysicsStepTime = 0.00045121199218556285  ?
        Retargeting = Enum.AnimatorRetargetingMode.Default  ?
        Sandboxed = false  ?
        SimulationRate = 1  ?
        SourceAssetId = -1  ?
        StreamingAdaptiveRadius = false  ?
        StreamingEnabled = false  ?
        Terrain = .Terrainworkspace  ?
        UniqueId = "00000000-0000-0000-0000-000000000000"  ?
        Wind = 0  ?
        WindDirection = nil --[[unserialisable vector: 0, 0, 0]]  ?
        WorldPivot = CFrame.new(0, 0, 0)  ?
        archivable = true  ?
        className = "Workspace"  ?
    |- Camera (Camera)
          Archivable = true  ?
          CFrame = CFrame.new(21.515865325927734, 3.325441360473633, -47.89488220214844) * CFrame.fromEulerAn…  ?
          CameraSubject = .SeoulKD.Humanoidworkspace  ?
          CameraType = Enum.CameraType.Custom  ?
          Capabilities = nil --[[unserialisable userdata: ]]  ?
          ClassName = "Camera"  ?
          CoordinateFrame = CFrame.new(21.515865325927734, 3.325441360473633, -47.89488220214844) * CFrame.fromEulerAn…  ?
          DataCost = 10  ?
          DiagonalFieldOfView = 127.76887512207031  ?
          FieldOfView = 70
          FieldOfViewMode = Enum.FieldOfViewMode.Vertical  ?
          Focus = CFrame.new(13.41475772857666, 1.9075193405151367, -57.30825424194336)  ?
          HeadLocked = true  ?
          HeadScale = 1  ?
          MaxAxisFieldOfView = 102.44786071777344  ?
          Name = "Camera"
          NearPlaneZ = -0.10000000149011612  ?
          Sandboxed = false  ?
          SourceAssetId = -1  ?
          UniqueId = "00000000-0000-0000-0000-000000000000"  ?
          VRTiltAndRollEnabled = false  ?
          ViewportSize = Vector2.new(640, 360)  ?
          archivable = true  ?
          className = "Camera"  ?
          focus = CFrame.new(13.41475772857666, 1.9075193405151367, -57.30825424194336)  ?
    |- Bench (Model)
          Archivable = true  ?
          Capabilities = nil --[[unserialisable userdata: ]]  ?
          ClassName = "Model"  ?
          DataCost = 130  ?
          LevelOfDetail = Enum.ModelLevelOfDetail.Automatic  ?
          ModelStreamingMode = Enum.ModelStreamingMode.Default  ?
          Name = "Bench"  *
          Sandboxed = false  ?
          SourceAssetId = -1  ?
          UniqueId = "00000000-0000-0000-0000-000000000000"  ?
          WorldPivot = CFrame.new(15.753108978271484, -0.4301837384700775, -38.02384948730469) * CFrame.fromEuler…  ?
          archivable = true  ?
          className = "Model"  ?
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.5110021829605103, -37.09556579589844]…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.035workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Brown")  ?
            CFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.043838173151016235, -37.7354087829589…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.012workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.5616705417633057, 2.9712491035461426, 5.651474475860596]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Plane.041 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753124237060547, -0.2367452085018158, -37.87491989135742…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.041workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Red flip/flop")  ?
            CFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5607843399047852, 0.40784314274787903, 0.3019607961177826)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.025498867034912, 1.810612678527832, 6.8691325187683105]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.039 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753120422363281, -1.9036458730697632, -38.08940505981445…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.039workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.0139994621276855, 1.7927329540252686, 5.509213924407959]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 14.01852798461914, -0.7212995290756226, -38.637672424316406…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[1] --[[Seat is 1 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 17.46857452392578, -0.7212995290756226, -38.6375732421875]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[2] --[[Seat is 2 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            CastShadow = true  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(92.71578979492188, 22.88751220703125, -63.40143966674805) * CFrame.fromEulerAng…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontSurfaceInput = Enum.InputType.NoInput  ?
            HasJointOffset = false  ?
            JointOffset = nil --[[unserialisable vector: 0, 0, 0]]  ?
            LeftParamA = -0.5  ?
            LeftParamB = 0.5  ?
            LeftSurface = Enum.SurfaceType.Smooth  ?
            LeftSurfaceInput = Enum.InputType.NoInput  ?
            LocalTransparencyModifier = 0  ?
            Locked = false  ?
            Mass = 24.030519485473633  ?
            Massless = false  ?
            Material = Enum.Material.SmoothPlastic  ?
            MaterialVariant = ""  ?
            MeshSize = nil --[[unserialisable vector: 1.1217865943908691, 1.8323338031768799, 4.405322074890137]]  ?
            Name = "Meshes/Bench_Plane.035"  ?
            Orientation = nil --[[unserialisable vector: 0, -21.613000869750977, 0]]  ?
            Position = nil --[[unserialisable vector: 92.71578979492188, 22.88751220703125, -63.40143966674805]]  ?
            --[[ 21 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      `- Seat (Seat)
    |- Bench (Model)
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.5110021829605103, -37.09556579589844]…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.035workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Brown")  ?
            CFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.043838173151016235, -37.7354087829589…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.012workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.5616705417633057, 2.9712491035461426, 5.651474475860596]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Plane.041 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753124237060547, -0.2367452085018158, -37.87491989135742…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.041workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Red flip/flop")  ?
            CFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5607843399047852, 0.40784314274787903, 0.3019607961177826)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.025498867034912, 1.810612678527832, 6.8691325187683105]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.039 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753120422363281, -1.9036458730697632, -38.08940505981445…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.039workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.0139994621276855, 1.7927329540252686, 5.509213924407959]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 14.01852798461914, -0.7212995290756226, -38.637672424316406…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[1] --[[Seat is 1 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 17.46857452392578, -0.7212995290756226, -38.6375732421875]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[2] --[[Seat is 2 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            CastShadow = true  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(92.71578979492188, 22.88751220703125, -63.40143966674805) * CFrame.fromEulerAng…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontSurfaceInput = Enum.InputType.NoInput  ?
            HasJointOffset = false  ?
            JointOffset = nil --[[unserialisable vector: 0, 0, 0]]  ?
            LeftParamA = -0.5  ?
            LeftParamB = 0.5  ?
            LeftSurface = Enum.SurfaceType.Smooth  ?
            LeftSurfaceInput = Enum.InputType.NoInput  ?
            LocalTransparencyModifier = 0  ?
            Locked = false  ?
            Mass = 24.030519485473633  ?
            Massless = false  ?
            Material = Enum.Material.SmoothPlastic  ?
            MaterialVariant = ""  ?
            MeshSize = nil --[[unserialisable vector: 1.1217865943908691, 1.8323338031768799, 4.405322074890137]]  ?
            Name = "Meshes/Bench_Plane.035"  ?
            Orientation = nil --[[unserialisable vector: 0, -21.613000869750977, 0]]  ?
            Position = nil --[[unserialisable vector: 92.71578979492188, 22.88751220703125, -63.40143966674805]]  ?
            --[[ 21 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      `- Seat (Seat)
    |- Bench (Model)
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.5110021829605103, -37.09556579589844]…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.035workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Brown")  ?
            CFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.043838173151016235, -37.7354087829589…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.012workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.5616705417633057, 2.9712491035461426, 5.651474475860596]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Plane.041 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753124237060547, -0.2367452085018158, -37.87491989135742…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.041workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Red flip/flop")  ?
            CFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5607843399047852, 0.40784314274787903, 0.3019607961177826)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.025498867034912, 1.810612678527832, 6.8691325187683105]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.039 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753120422363281, -1.9036458730697632, -38.08940505981445…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.039workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.0139994621276855, 1.7927329540252686, 5.509213924407959]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 14.01852798461914, -0.7212995290756226, -38.637672424316406…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[1] --[[Seat is 1 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 17.46857452392578, -0.7212995290756226, -38.6375732421875]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[2] --[[Seat is 2 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            CastShadow = true  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(92.71578979492188, 22.88751220703125, -63.40143966674805) * CFrame.fromEulerAng…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontSurfaceInput = Enum.InputType.NoInput  ?
            HasJointOffset = false  ?
            JointOffset = nil --[[unserialisable vector: 0, 0, 0]]  ?
            LeftParamA = -0.5  ?
            LeftParamB = 0.5  ?
            LeftSurface = Enum.SurfaceType.Smooth  ?
            LeftSurfaceInput = Enum.InputType.NoInput  ?
            LocalTransparencyModifier = 0  ?
            Locked = false  ?
            Mass = 24.030519485473633  ?
            Massless = false  ?
            Material = Enum.Material.SmoothPlastic  ?
            MaterialVariant = ""  ?
            MeshSize = nil --[[unserialisable vector: 1.1217865943908691, 1.8323338031768799, 4.405322074890137]]  ?
            Name = "Meshes/Bench_Plane.035"  ?
            Orientation = nil --[[unserialisable vector: 0, -21.613000869750977, 0]]  ?
            Position = nil --[[unserialisable vector: 92.71578979492188, 22.88751220703125, -63.40143966674805]]  ?
            --[[ 21 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      `- Seat (Seat)
    |- Bench (Model)
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.5110021829605103, -37.09556579589844]…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.035workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Brown")  ?
            CFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.043838173151016235, -37.7354087829589…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.012workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.5616705417633057, 2.9712491035461426, 5.651474475860596]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Plane.041 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753124237060547, -0.2367452085018158, -37.87491989135742…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.041workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Red flip/flop")  ?
            CFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5607843399047852, 0.40784314274787903, 0.3019607961177826)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.025498867034912, 1.810612678527832, 6.8691325187683105]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.039 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753120422363281, -1.9036458730697632, -38.08940505981445…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.039workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.0139994621276855, 1.7927329540252686, 5.509213924407959]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 14.01852798461914, -0.7212995290756226, -38.637672424316406…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[1] --[[Seat is 1 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 17.46857452392578, -0.7212995290756226, -38.6375732421875]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[2] --[[Seat is 2 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            CastShadow = true  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(92.71578979492188, 22.88751220703125, -63.40143966674805) * CFrame.fromEulerAng…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontSurfaceInput = Enum.InputType.NoInput  ?
            HasJointOffset = false  ?
            JointOffset = nil --[[unserialisable vector: 0, 0, 0]]  ?
            LeftParamA = -0.5  ?
            LeftParamB = 0.5  ?
            LeftSurface = Enum.SurfaceType.Smooth  ?
            LeftSurfaceInput = Enum.InputType.NoInput  ?
            LocalTransparencyModifier = 0  ?
            Locked = false  ?
            Mass = 24.030519485473633  ?
            Massless = false  ?
            Material = Enum.Material.SmoothPlastic  ?
            MaterialVariant = ""  ?
            MeshSize = nil --[[unserialisable vector: 1.1217865943908691, 1.8323338031768799, 4.405322074890137]]  ?
            Name = "Meshes/Bench_Plane.035"  ?
            Orientation = nil --[[unserialisable vector: 0, -21.613000869750977, 0]]  ?
            Position = nil --[[unserialisable vector: 92.71578979492188, 22.88751220703125, -63.40143966674805]]  ?
            --[[ 21 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      `- Seat (Seat)
    |- Bench (Model)
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.5110021829605103, -37.09556579589844]…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.035workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Brown")  ?
            CFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.043838173151016235, -37.7354087829589…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.012workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.5616705417633057, 2.9712491035461426, 5.651474475860596]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Plane.041 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753124237060547, -0.2367452085018158, -37.87491989135742…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.041workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Red flip/flop")  ?
            CFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5607843399047852, 0.40784314274787903, 0.3019607961177826)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.025498867034912, 1.810612678527832, 6.8691325187683105]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.039 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753120422363281, -1.9036458730697632, -38.08940505981445…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.039workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.0139994621276855, 1.7927329540252686, 5.509213924407959]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 14.01852798461914, -0.7212995290756226, -38.637672424316406…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[1] --[[Seat is 1 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 17.46857452392578, -0.7212995290756226, -38.6375732421875]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[2] --[[Seat is 2 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            CastShadow = true  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(92.71578979492188, 22.88751220703125, -63.40143966674805) * CFrame.fromEulerAng…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontSurfaceInput = Enum.InputType.NoInput  ?
            HasJointOffset = false  ?
            JointOffset = nil --[[unserialisable vector: 0, 0, 0]]  ?
            LeftParamA = -0.5  ?
            LeftParamB = 0.5  ?
            LeftSurface = Enum.SurfaceType.Smooth  ?
            LeftSurfaceInput = Enum.InputType.NoInput  ?
            LocalTransparencyModifier = 0  ?
            Locked = false  ?
            Mass = 24.030519485473633  ?
            Massless = false  ?
            Material = Enum.Material.SmoothPlastic  ?
            MaterialVariant = ""  ?
            MeshSize = nil --[[unserialisable vector: 1.1217865943908691, 1.8323338031768799, 4.405322074890137]]  ?
            Name = "Meshes/Bench_Plane.035"  ?
            Orientation = nil --[[unserialisable vector: 0, -21.613000869750977, 0]]  ?
            Position = nil --[[unserialisable vector: 92.71578979492188, 22.88751220703125, -63.40143966674805]]  ?
            --[[ 21 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      `- Seat (Seat)
    |- Bench (Model)
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.5110021829605103, -37.09556579589844]…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.035workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Brown")  ?
            CFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.043838173151016235, -37.7354087829589…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.012workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.5616705417633057, 2.9712491035461426, 5.651474475860596]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Plane.041 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753124237060547, -0.2367452085018158, -37.87491989135742…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.041workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Red flip/flop")  ?
            CFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5607843399047852, 0.40784314274787903, 0.3019607961177826)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.025498867034912, 1.810612678527832, 6.8691325187683105]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.039 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753120422363281, -1.9036458730697632, -38.08940505981445…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.039workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.0139994621276855, 1.7927329540252686, 5.509213924407959]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 14.01852798461914, -0.7212995290756226, -38.637672424316406…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[1] --[[Seat is 1 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 17.46857452392578, -0.7212995290756226, -38.6375732421875]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[2] --[[Seat is 2 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            CastShadow = true  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(92.71578979492188, 22.88751220703125, -63.40143966674805) * CFrame.fromEulerAng…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontSurfaceInput = Enum.InputType.NoInput  ?
            HasJointOffset = false  ?
            JointOffset = nil --[[unserialisable vector: 0, 0, 0]]  ?
            LeftParamA = -0.5  ?
            LeftParamB = 0.5  ?
            LeftSurface = Enum.SurfaceType.Smooth  ?
            LeftSurfaceInput = Enum.InputType.NoInput  ?
            LocalTransparencyModifier = 0  ?
            Locked = false  ?
            Mass = 24.030519485473633  ?
            Massless = false  ?
            Material = Enum.Material.SmoothPlastic  ?
            MaterialVariant = ""  ?
            MeshSize = nil --[[unserialisable vector: 1.1217865943908691, 1.8323338031768799, 4.405322074890137]]  ?
            Name = "Meshes/Bench_Plane.035"  ?
            Orientation = nil --[[unserialisable vector: 0, -21.613000869750977, 0]]  ?
            Position = nil --[[unserialisable vector: 92.71578979492188, 22.88751220703125, -63.40143966674805]]  ?
            --[[ 21 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      `- Seat (Seat)
    |- Bench (Model)
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.5110021829605103, -37.09556579589844]…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.035workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Brown")  ?
            CFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.5110021829605103, -37.09556579589844) * CFrame.fromEulerA…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753135681152344, 0.043838173151016235, -37.7354087829589…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.012workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753135681152344, 0.043838173151016235, -37.735408782958984) * CFrame.fromEul…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.5616705417633057, 2.9712491035461426, 5.651474475860596]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Plane.041 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753124237060547, -0.2367452085018158, -37.87491989135742…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Plane.041workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Red flip/flop")  ?
            CFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            CanCollide = true
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.5607843399047852, 0.40784314274787903, 0.3019607961177826)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753124237060547, -0.2367452085018158, -37.87491989135742) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.025498867034912, 1.810612678527832, 6.8691325187683105]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Meshes/Bench_Cube.039 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 15.753120422363281, -1.9036458730697632, -38.08940505981445…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench.Meshes/Bench_Cube.039workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Dark taupe")  ?
            CFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            CanCollide = false  *
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "MeshPart"  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            CollisionPrecision = 0  ?
            Color = Color3.new(0.3529411852359772, 0.2980392277240753, 0.25882354378700256)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(15.753120422363281, -1.9036458730697632, -38.08940505981445) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 3.0139994621276855, 1.7927329540252686, 5.509213924407959]]  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            --[[ 56 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 14.01852798461914, -0.7212995290756226, -38.637672424316406…  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[1] --[[Seat is 1 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(14.01852798461914, -0.7212995290756226, -38.637672424316406) * CFrame.fromEuler…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Seat (Seat)
            Anchored = true  ?
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyCenterOfMass = nil --[[unserialisable vector: 17.46857452392578, -0.7212995290756226, -38.6375732421875]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AssemblyRootPart = .Bench:GetChildren()[2] --[[Seat is 2 of 2]]workspace  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackParamB = 0.5  ?
            BackSurface = Enum.SurfaceType.Smooth  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomParamA = -0.5  ?
            BottomParamB = 0.5  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            BottomSurfaceInput = Enum.InputType.NoInput  ?
            BrickColor = BrickColor.new("Black")  ?
            CFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            CanCollide = true  ?
            CanQuery = true  ?
            CanTouch = true  ?
            Capabilities = nil --[[unserialisable userdata: ]]  ?
            CastShadow = true  ?
            CenterOfMass = nil --[[unserialisable vector: 0, 0, 0]]  ?
            ClassName = "Seat"  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.10588235408067703, 0.16470588743686676, 0.2078431397676468)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DataCost = 20  ?
            Disabled = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(17.46857452392578, -0.7212995290756226, -38.6375732421875) * CFrame.fromEulerAn…  ?
            ExtentsSize = nil --[[unserialisable vector: 2.299999952316284, 0.25, 2.9000000953674316]]  ?
            FormFactor = Enum.FormFactor.Brick  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontParamB = 0.5  ?
            FrontSurface = Enum.SurfaceType.Smooth  ?
            --[[ 44 more property/properties not shown ]]
      |- Meshes/Bench_Plane.035 (MeshPart)
            Anchored = true  *
            Archivable = true  ?
            AssemblyAngularVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyLinearVelocity = nil --[[unserialisable vector: 0, 0, 0]]  ?
            AssemblyMass = math.huge  ?
            AudioCanCollide = true  ?
            BackParamA = -0.5  ?
            BackSurfaceInput = Enum.InputType.NoInput  ?
            BottomSurface = Enum.SurfaceType.Smooth  ?
            CastShadow = true  ?
            CollisionFidelity = Enum.CollisionFidelity.Box  ?
            CollisionGroup = "Default"  ?
            CollisionGroupId = 0  ?
            Color = Color3.new(0.49803921580314636, 0.3607843220233917, 0.2666666805744171)  ?
            CurrentPhysicalProperties = nil --[[unserialisable userdata: 0.699999988, 0.200000003, 0.5, 1, 1, 0.200000003]]  ?
            DoubleSided = false  ?
            Elasticity = 0.5  ?
            EnableFluidForces = true  ?
            ExtentsCFrame = CFrame.new(92.71578979492188, 22.88751220703125, -63.40143966674805) * CFrame.fromEulerAng…  ?
            ExtentsSize = nil --[[unserialisable vector: 1.7491798400878906, 2.8571221828460693, 6.8691325187683105]…  ?
            FluidFidelity = Enum.FluidFidelity.Automatic  ?
            Friction = 0.30000001192092896  ?
            FrontParamA = -0.5  ?
            FrontSurfaceInput = Enum.InputType.NoInput  ?
            HasJointOffset = false  ?
            JointOffset = nil --[[unserialisable vector: 0, 0, 0]]  ?
            LeftParamA = -0.5  ?
            LeftParamB = 0.5  ?
            LeftSurface = Enum.SurfaceType.Smooth  ?
            LeftSurfaceInput = Enum.InputType.NoInput  ?
            LocalTransparencyModifier = 0  ?
            Locked = false  ?
            Mass = 24.030519485473633  ?
            Massless = false  ?
            Material = Enum.Material.SmoothPlastic  ?
            MaterialVariant = ""  ?
            MeshSize = nil --[[unserialisable vector: 1.1217865943908691, 1.8323338031768799, 4.405322074890137]]  ?
            Name = "Meshes/Bench_Plane.035"  ?
            Orientation = nil --[[unserialisable vector: 0, -21.613000869750977, 0]]  ?
            Position = nil --[[unserialisable vector: 92.71578979492188, 22.88751220703125, -63.40143966674805]]  ?
            --[[ 21 more property/properties not shown ]]
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      |- Seat (Seat)
      |- Meshes/Bench_Plane.035 (MeshPart)
      |- Meshes/Bench_Cube.012 (MeshPart)
      |- Meshes/Bench_Plane.041 (MeshPart)
      |- Meshes/Bench_Cube.039 (MeshPart)
      |- Seat (Seat)
      `- Seat (Seat)
    |- Flowers (Folder)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- Flower (Model)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh47 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh45 (MeshPart)
        |- Meshes/_doge_simulator_props_Mesh46 (MeshPart)
        `- Meshes/_doge_simulator_props_Mesh35 (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      |- FloorFlower (MeshPart)
      `- FloorFlower (MeshPart)
    |- Path (Model)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Model (Model)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        |- Part (Part)
        `- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Wedge (WedgePart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Part (Part)
      |- Part (Part)
      |- Part (Part)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      |- Pebble (MeshPart)
      `- Pebble (MeshPart)
    |- normalCanvas (Model)
      |- canvasFrame (Part)
      |- canvasFrame (Part)
      |- canvasFrame (Part)
      `- canvasFrame (Part)
    |- Pro Server Portal (Model)
      |- LocalScript (Script)
      |- Script (Script)
      |- Portal (Model)
        |- Teleport (Part)
          |- ParticleEmitter (ParticleEmitter)
          `- TouchInterest (TouchTransmitter)
        `- Part (Part)
      |- Frame (Model)
        |- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
        `- Model (Model)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          |- Part (Part)
          `- Part (Part)
      |- MaxPoints (IntValue)
      |- TeleportRemote (RemoteEvent)
      `- ProText (Model)
        |- uni0050 (MeshPart)
        |- uni0072 (MeshPart)
        |- uni006F (MeshPart)
        |- uni0053 (MeshPart)
        |- uni0065 (MeshPart)
        |- uni0072 (MeshPart)
        |- uni0076 (MeshPart)
        |- uni0065 (MeshPart)
        `- uni0072 (MeshPart)
    |- Lights (Model)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        `- Glass (MeshPart)
      |- Low Poly Garden Lantern (Model)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          `- PointLight (PointLight)
                [attr] ToTurnOn = true
        |- Glass (MeshPart)
        |- Base (MeshPart)
        |- Neon (MeshPart)
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
          |- PointLight (PointLight)
                [attr] ToTurnOn = true
--[[ TRUNCATED: instance or line budget reached; see 07-COVERAGE.md ]]
```text

```

## Instance census

| Class | Count | Share |
| --- | :---: | :---: |
| 'Accessory' | 23 | 0.3% |
| 'AccessoryDescription' | 23 | 0.3% |
| 'Animation' | 218 | 2.7% |
| 'AnimationClipProvider' | 1 | 0% |
| 'AnimationConstraint' | 120 | 1.5% |
| 'Animator' | 8 | 0.1% |
| 'Attachment' | 449 | 5.6% |
| 'Backpack' | 8 | 0.1% |
| 'BallSocketConstraint' | 112 | 1.4% |
| 'BindableFunction' | 8 | 0.1% |
| 'BodyColors' | 8 | 0.1% |
| 'BodyPartDescription' | 48 | 0.6% |
| 'BoolValue' | 2 | 0% |
| 'BubbleChatConfiguration' | 1 | 0% |
| 'CSGDictionaryService' | 1 | 0% |
| 'Camera' | 1 | 0% |
| 'CanvasGroup' | 11 | 0.1% |
| 'ChannelTabsConfiguration' | 1 | 0% |
| 'Chat' | 1 | 0% |
| 'ChatInputBarConfiguration' | 1 | 0% |
| 'ChatWindowConfiguration' | 1 | 0% |
| 'Color3Value' | 2 | 0% |
| 'ContentProvider' | 1 | 0% |
| 'CorePackages' | 1 | 0% |
| 'DataModel' | 1 | 0% |
| 'Decal' | 6 | 0.1% |
| 'FaceControls' | 8 | 0.1% |
| 'Folder' | 56 | 0.7% |
| 'Frame' | 272 | 3.4% |
| 'GuiService' | 1 | 0% |
| 'Highlight' | 1 | 0% |
| 'HttpRbxApiService' | 1 | 0% |
| 'Humanoid' | 8 | 0.1% |
| 'HumanoidDescription' | 8 | 0.1% |
| 'ImageButton' | 2 | 0% |
| 'ImageLabel' | 230 | 2.9% |
| 'IntValue' | 19 | 0.2% |
| 'KeyframeSequenceProvider' | 1 | 0% |
| 'LocalScript' | 13 | 0.2% |
| 'LogService' | 1 | 0% |
| 'MarketplaceService' | 1 | 0% |
| 'MaterialService' | 1 | 0% |
| 'MeshPart' | 606 | 7.6% |
| 'MicroProfilerService' | 1 | 0% |
| 'Model' | 136 | 1.7% |
| 'ModuleScript' | 804 | 10.1% |
| 'NoCollisionConstraint' | 152 | 1.9% |
| 'NonReplicatedCSGDictionaryService' | 1 | 0% |
| 'NotificationService' | 1 | 0% |
| 'NumberValue' | 154 | 1.9% |
| 'Pants' | 8 | 0.1% |
| 'Part' | 379 | 4.7% |
| 'ParticleEmitter' | 13 | 0.2% |
| 'Player' | 8 | 0.1% |
| 'PlayerEmulatorService' | 1 | 0% |
| 'PlayerGui' | 1 | 0% |
| 'PlayerScripts' | 1 | 0% |
| 'Players' | 1 | 0% |
| 'PointLight' | 21 | 0.3% |
| 'PointsService' | 1 | 0% |
| 'RemoteEvent' | 1 | 0% |
| 'ReplicatedFirst' | 1 | 0% |
| 'RigidConstraint' | 23 | 0.3% |
| 'RunService' | 1 | 0% |
| 'RunningAverageItemDouble' | 2 | 0% |
| 'RunningAverageItemInt' | 42 | 0.5% |
| 'ScreenGui' | 13 | 0.2% |
| 'ScreenshotHud' | 1 | 0% |
| 'Script' | 10 | 0.1% |
| 'ScrollingFrame' | 4 | 0.1% |
| 'Seat' | 14 | 0.2% |
| 'Shirt' | 8 | 0.1% |
| 'ShirtGraphic' | 1 | 0% |
| 'Sound' | 72 | 0.9% |
| 'SoundService' | 1 | 0% |
| 'SpawnLocation' | 6 | 0.1% |
| 'StarterGear' | 8 | 0.1% |
| 'Stats' | 1 | 0% |
| 'StatsItem' | 1136 | 14.2% |
| 'Status' | 8 | 0.1% |
| 'StringValue' | 243 | 3% |
| 'SurfaceAppearance' | 2 | 0% |
| 'SurfaceGui' | 4 | 0.1% |
| 'SurfaceLight' | 1 | 0% |
| 'Terrain' | 1 | 0% |
| 'TextBox' | 1 | 0% |
| 'TextButton' | 74 | 0.9% |
| 'TextChannel' | 2 | 0% |
| 'TextChatCommand' | 9 | 0.1% |
| 'TextChatService' | 1 | 0% |
| 'TextLabel' | 892 | 11.2% |
| 'TextService' | 1 | 0% |
| 'TextSource' | 16 | 0.2% |
| 'TimerService' | 1 | 0% |
| 'TotalCountTimeIntervalItem' | 36 | 0.5% |
| 'TouchTransmitter' | 1 | 0% |
| 'TweenService' | 1 | 0% |
| 'UIAspectRatioConstraint' | 220 | 2.8% |
| 'UICorner' | 313 | 3.9% |
| 'UIGradient' | 3 | 0% |
| 'UIGridLayout' | 2 | 0% |
| 'UIListLayout' | 20 | 0.3% |
| 'UIPadding' | 18 | 0.2% |
| 'UISizeConstraint' | 5 | 0.1% |
| 'UIStroke' | 11 | 0.1% |
| 'Vector3Value' | 595 | 7.4% |
| 'VideoCaptureService' | 1 | 0% |
| 'WedgePart' | 80 | 1% |
| 'Workspace' | 1 | 0% |
| 'WrapLayer' | 3 | 0% |
| 'WrapTarget' | 120 | 1.5% |

